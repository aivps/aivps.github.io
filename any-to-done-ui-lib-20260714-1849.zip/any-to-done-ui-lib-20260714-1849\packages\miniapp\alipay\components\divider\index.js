Component({
  properties: {
    type: { type: String, value: 'horizontal' },
    text: { type: String, value: '' },
    dashed: { type: Boolean, value: false },
  },
  data: {},
  methods: {},
});
