package com.uilib.components.bath

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 包厢 - bath industry (Compose) */
@Composable
fun RoomStatusCard(
    roomNo: String = "",
    type: String = "",
    capacity: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "包厢",
        status = status.ifBlank { null },
        fields = listOf(
            "包厢号" to roomNo,
            "类型" to type,
            "容量" to capacity,
        ),
        modifier = modifier,
    )
}