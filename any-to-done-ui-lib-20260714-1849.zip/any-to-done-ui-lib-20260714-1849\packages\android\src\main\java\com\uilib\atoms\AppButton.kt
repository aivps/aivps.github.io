package com.uilib.atoms

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.uilib.tokens.AppMotion
import com.uilib.tokens.AppSpacing
import com.uilib.tokens.AppTypography
import com.uilib.tokens.uiColors

/** React-canonical variants. Legacy: Outline→Secondary, Link→Text. */
enum class ButtonVariant {
    Primary,
    Secondary,
    Text,
    Danger,
    Ghost,
    /** @deprecated maps to Secondary with outline stroke */
    Outline,
    /** @deprecated maps to Text */
    Link,
}

enum class ButtonSize {
    Xs, Sm, Md, Lg,
}

/**
 * AppButton — shallow API aligned to React Button.
 * @param variant canonical primary|secondary|text|danger|ghost (+ legacy outline|link)
 * @param circle circular button (React-aligned)
 * @param error error ring state
 * @param primary legacy boolean (only used when variant stays Primary)
 */
@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: ButtonVariant = ButtonVariant.Primary,
    size: ButtonSize = ButtonSize.Md,
    enabled: Boolean = true,
    loading: Boolean = false,
    circle: Boolean = false,
    error: Boolean = false,
    block: Boolean = false,
    /** @deprecated prefer [variant] */
    primary: Boolean = true,
) {
    val colors = uiColors
    val isDisabled = !enabled || loading
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed && !isDisabled) AppMotion.pressScale else 1f,
        animationSpec = tween(AppMotion.durationFastMs),
        label = "buttonPressScale",
    )

    val effectiveVariant = when {
        variant == ButtonVariant.Outline -> ButtonVariant.Secondary
        variant == ButtonVariant.Link -> ButtonVariant.Text
        variant == ButtonVariant.Primary && !primary -> ButtonVariant.Secondary
        else -> variant
    }
    val outlineLegacy = variant == ButtonVariant.Outline

    val height: Dp = when (size) {
        ButtonSize.Xs -> 24.dp
        ButtonSize.Sm -> 32.dp
        ButtonSize.Md -> 40.dp
        ButtonSize.Lg -> 48.dp
    }
    val hPad: Dp = when (size) {
        ButtonSize.Xs -> 8.dp
        ButtonSize.Sm -> 12.dp
        ButtonSize.Md -> 16.dp
        ButtonSize.Lg -> 24.dp
    }

    val bg: Color
    val fg: Color
    val borderColor: Color
    when {
        isDisabled -> {
            bg = colors.gray200
            fg = colors.muted
            borderColor = colors.border
        }
        effectiveVariant == ButtonVariant.Primary -> {
            bg = colors.primary
            fg = Color.White
            borderColor = colors.primary
        }
        effectiveVariant == ButtonVariant.Danger -> {
            bg = colors.danger
            fg = Color.White
            borderColor = colors.danger
        }
        effectiveVariant == ButtonVariant.Secondary && outlineLegacy -> {
            bg = Color.Transparent
            fg = colors.foreground
            borderColor = colors.border
        }
        effectiveVariant == ButtonVariant.Secondary -> {
            bg = colors.surface
            fg = colors.primary
            borderColor = colors.primary
        }
        effectiveVariant == ButtonVariant.Ghost -> {
            bg = Color.Transparent
            fg = colors.foreground
            borderColor = colors.border
        }
        else -> {
            // Text
            bg = Color.Transparent
            fg = colors.primary
            borderColor = Color.Transparent
        }
    }

    val shape = if (circle) CircleShape else RoundedCornerShape(AppSpacing.radiusMd)
    val needsBorder = borderColor != Color.Transparent &&
        (effectiveVariant == ButtonVariant.Secondary ||
            effectiveVariant == ButtonVariant.Ghost ||
            outlineLegacy ||
            error)

    Box(
        modifier = modifier
            .scale(scale)
            .then(if (block) Modifier.fillMaxWidth() else Modifier)
            .then(if (circle) Modifier.size(height) else Modifier.height(height))
            .clip(shape)
            .background(bg)
            .then(
                if (needsBorder) {
                    Modifier.border(
                        if (error) 2.dp else 1.dp,
                        if (error) colors.danger else borderColor,
                        shape,
                    )
                } else if (error) {
                    Modifier.border(2.dp, colors.danger, shape)
                } else Modifier
            )
            .pointerInput(isDisabled) {
                if (isDisabled) return@pointerInput
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClick() },
                )
            }
            .then(if (circle) Modifier else Modifier.padding(horizontal = hPad)),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (loading) {
                CircularProgressIndicator(
                    modifier = Modifier
                        .padding(end = 6.dp)
                        .size(14.dp),
                    color = fg,
                    strokeWidth = 2.dp,
                )
            }
            Text(text = text, style = AppTypography.body, color = fg)
        }
    }
}

@Composable
fun AppTag(
    text: String,
    modifier: Modifier = Modifier,
    color: Color? = null,
    background: Color? = null,
    /** React-aligned semantic tone: default|primary|success|warning|danger|info */
    tone: String = "primary",
    size: ButtonSize = ButtonSize.Md,
    checked: Boolean = false,
    closable: Boolean = false,
    onClose: (() -> Unit)? = null,
) {
    val colors = uiColors
    val (defaultFg, defaultBg) = when (tone) {
        "success" -> colors.success to colors.primaryBg
        "warning" -> colors.warning to colors.primaryBg
        "danger" -> colors.danger to colors.primaryBg
        "info" -> colors.cyan to colors.primaryBg
        "default" -> colors.muted to colors.gray100
        else -> colors.primary to colors.primaryBg
    }
    val resolvedFg = color ?: defaultFg
    val resolvedBg = background ?: defaultBg
    val hPad = when (size) {
        ButtonSize.Lg -> AppSpacing.md
        else -> AppSpacing.sm
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(AppSpacing.radiusSm))
            .background(resolvedBg)
            .then(
                if (checked) Modifier.border(1.dp, colors.primary, RoundedCornerShape(AppSpacing.radiusSm))
                else Modifier
            )
            .padding(horizontal = hPad, vertical = 2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = text,
                style = AppTypography.caption,
                color = resolvedFg,
                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
            )
            if (closable) {
                Text(
                    text = " ×",
                    style = AppTypography.caption,
                    color = resolvedFg,
                    modifier = Modifier.pointerInput(Unit) {
                        detectTapGestures(onTap = { onClose?.invoke() })
                    },
                )
            }
        }
    }
}

@Composable
fun AppBadge(
    modifier: Modifier = Modifier,
    count: Int? = null,
    text: String? = null,
    color: String = "danger",
    size: ButtonSize = ButtonSize.Md,
    dot: Boolean = false,
    overflowCount: Int = 99,
) {
    val colors = uiColors
    val bg = when (color) {
        "primary" -> colors.primary
        "success" -> colors.success
        "warning" -> colors.warning
        "info" -> colors.cyan
        "default" -> colors.muted
        else -> colors.danger
    }
    val display = when {
        text != null -> text
        count == null -> ""
        count > overflowCount -> "$overflowCount+"
        else -> count.toString()
    }
    val dim = when (size) {
        ButtonSize.Sm, ButtonSize.Xs -> if (dot) 6.dp else 16.dp
        ButtonSize.Lg -> if (dot) 10.dp else 24.dp
        else -> if (dot) 8.dp else 20.dp
    }
    Box(
        modifier = modifier
            .then(if (dot) Modifier.size(dim) else Modifier)
            .clip(CircleShape)
            .background(bg)
            .then(if (!dot) Modifier.padding(horizontal = 4.dp, vertical = 1.dp) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        if (!dot && display.isNotEmpty()) {
            Text(text = display, color = Color.White, style = AppTypography.caption)
        }
    }
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    extra: String? = null,
    bordered: Boolean = true,
    loading: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val colors = uiColors
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed && onClick != null) AppMotion.pressScale else 1f,
        animationSpec = tween(AppMotion.durationFastMs),
        label = "cardPress",
    )
    Box(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(AppSpacing.radiusLg))
            .background(colors.surface)
            .then(
                if (bordered) Modifier.border(1.dp, colors.border, RoundedCornerShape(AppSpacing.radiusLg))
                else Modifier
            )
            .then(
                if (onClick != null) Modifier.pointerInput(Unit) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onTap = { onClick() },
                    )
                } else Modifier
            )
            .padding(AppSpacing.lg)
    ) {
        Column {
            if (title != null || extra != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = AppSpacing.sm),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    if (title != null) {
                        Text(title, style = AppTypography.h3, color = colors.foreground)
                    }
                    if (extra != null) {
                        Text(extra, style = AppTypography.caption, color = colors.primary)
                    }
                }
            }
            if (loading) {
                Text("加载中…", color = colors.muted, style = AppTypography.caption)
            } else {
                content()
            }
        }
    }
}

@Composable
fun AppInput(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    label: String? = null,
    variant: String = "outlined",
    size: ButtonSize = ButtonSize.Md,
    status: String = "default",
    errorMessage: String? = null,
    helperText: String? = null,
    disabled: Boolean = false,
    readOnly: Boolean = false,
    loading: Boolean = false,
) {
    val colors = uiColors
    val effectiveStatus = if (!errorMessage.isNullOrEmpty()) "error" else status
    val borderColor = when (effectiveStatus) {
        "error" -> colors.danger
        "success" -> colors.success
        "warning" -> colors.warning
        else -> colors.border
    }
    val height = when (size) {
        ButtonSize.Sm, ButtonSize.Xs -> 32.dp
        ButtonSize.Lg -> 48.dp
        else -> 40.dp
    }
    val bg = when (variant) {
        "filled" -> colors.gray100
        "borderless" -> Color.Transparent
        else -> colors.surface
    }
    val textStyle = TextStyle(
        fontSize = AppTypography.body.fontSize,
        fontWeight = AppTypography.body.fontWeight,
        color = if (disabled) colors.muted else colors.foreground,
    )
    Column(modifier = modifier) {
        if (label != null) {
            Text(label, style = AppTypography.caption, color = colors.foreground)
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .clip(RoundedCornerShape(AppSpacing.radiusMd))
                .background(bg)
                .then(
                    if (variant != "borderless") {
                        Modifier.border(1.dp, borderColor, RoundedCornerShape(AppSpacing.radiusMd))
                    } else Modifier
                )
                .padding(horizontal = AppSpacing.md),
            contentAlignment = Alignment.CenterStart,
        ) {
            BasicTextField(
                value = value,
                onValueChange = { if (!disabled && !readOnly && !loading) onValueChange(it) },
                enabled = !disabled && !loading,
                readOnly = readOnly,
                textStyle = textStyle,
                decorationBox = { inner ->
                    Box {
                        if (value.isEmpty() && placeholder.isNotEmpty()) {
                            Text(placeholder, style = AppTypography.body, color = colors.muted)
                        }
                        inner()
                    }
                },
            )
        }
        val msg = errorMessage ?: helperText
        if (!msg.isNullOrEmpty()) {
            Text(
                msg,
                style = AppTypography.caption,
                color = if (effectiveStatus == "error") colors.danger else colors.muted,
            )
        }
    }
}
