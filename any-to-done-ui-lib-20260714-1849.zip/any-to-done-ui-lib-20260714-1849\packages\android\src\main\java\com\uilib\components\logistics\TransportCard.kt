package com.uilib.components.logistics

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 运输 - field-deep aligned shell (Compose) */
@Composable
fun TransportCard(
    routeName: String = "",
    carrier: String = "",
    status: String = "",
    vehicleNo: String = "",
    origin: String = "",
    destination: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "运输",
        status = status.ifBlank { null },
        fields = listOf(
            "线路" to routeName,
            "承运商" to carrier,
            "车号" to vehicleNo,
            "起点" to origin,
            "终点" to destination,
        ),
        modifier = modifier,
    )
}