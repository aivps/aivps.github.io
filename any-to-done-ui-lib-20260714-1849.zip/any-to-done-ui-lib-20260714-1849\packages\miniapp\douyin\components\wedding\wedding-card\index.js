/** 婚礼 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'couple': { type: String, value: '' },
    'date': { type: String, value: '' },
    'venue': { type: String, value: '' },
    'guestCount': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
