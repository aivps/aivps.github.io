import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// FitnessCourseCard — field-deep aligned to React fitness CourseCard.
/// Canonical: name, coach, time, duration, capacity, enrolled, category.
/// Package export name FitnessCourseCard to avoid education CourseCard clash.
class FitnessCourseCard extends StatelessWidget {
  final String name;
  final String coach;
  final String time;
  final String duration;
  final int capacity;
  final int enrolled;
  final String? category;
  final String? room;
  final String? level;
  final VoidCallback? onTap;
  final VoidCallback? onBook;
  final bool disabled;

  /// @deprecated use name
  final String? title;

  const FitnessCourseCard({
    super.key,
    this.name = '',
    required this.coach,
    required this.time,
    this.duration = '',
    required this.capacity,
    required this.enrolled,
    this.category,
    this.room,
    this.level,
    this.onTap,
    this.onBook,
    this.disabled = false,
    this.title,
  });

  String get _name => name.isNotEmpty ? name : (title ?? '');
  bool get _isFull => capacity > 0 && enrolled >= capacity;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final full = _isFull;
    final pct = capacity > 0 ? (enrolled / capacity).clamp(0.0, 1.0) : 0.0;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
            border: Border(
              left: BorderSide(color: colors.primary, width: 4),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(child: Text(_name, style: AppTypography.h3)),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: (full ? colors.warning : colors.success)
                          .withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      full ? '已满' : '可预约',
                      style: AppTypography.caption.copyWith(
                        color: full ? colors.warning : colors.success,
                      ),
                    ),
                  ),
                ],
              ),
              Text('教练: $coach', style: AppTypography.body),
              if (category != null || level != null)
                Text(category ?? level!, style: AppTypography.caption),
              const SizedBox(height: 8),
              Text(
                [
                  time,
                  if (duration.isNotEmpty) duration,
                  if (room != null) room!,
                ].join(' · '),
                style: AppTypography.caption,
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('报名 $enrolled / $capacity', style: AppTypography.body),
                  Text(
                    full ? '已满' : '可约',
                    style: AppTypography.caption.copyWith(
                      color: full ? colors.danger : colors.success,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              LinearProgressIndicator(
                value: pct,
                backgroundColor: colors.border,
                color: full ? colors.danger : colors.primary,
              ),
              if (onBook != null && !full) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: disabled ? null : onBook,
                    child: const Text('立即预约'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// Alias matching RN export name CourseCard within fitness package path.
typedef CourseCard = FitnessCourseCard;
