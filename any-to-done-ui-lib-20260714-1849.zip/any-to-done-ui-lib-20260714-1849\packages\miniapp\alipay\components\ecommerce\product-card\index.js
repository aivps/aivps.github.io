/** 商品 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'price': { type: String, value: '' },
    'originalPrice': { type: String, value: '' },
    'sales': { type: String, value: '' },
    'image': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
