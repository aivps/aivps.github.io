/** KPIBoard - WeChat Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'title': { type: String, value: '' },
    'value': { type: String, value: '' },
    'unit': { type: String, value: '' },
    'trend': { type: String, value: '' },
    'trendValue': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});