// medical industry exports
export 'patient_card.dart';
export 'medical_record_card.dart';
