import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ChildPatientCardProps {
  id?: string;
  name?: string;
  age?: string;
  gender?: string;
  department?: string;
  guardian?: string;
  status?: string;
  chiefComplaint?: string;
  onClick?: () => void;
}

/** ChildPatientCard - Electron shell (field keys aligned to React) */
export const ChildPatientCard: React.FC<ChildPatientCardProps> = (props) => (
  <IndustryCardShell title="ChildPatientCard" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.age ? <div className="row"><span className="label">age</span><span>{props.age}</span></div> : null}
      {props.gender ? <div className="row"><span className="label">gender</span><span>{props.gender}</span></div> : null}
      {props.department ? <div className="row"><span className="label">department</span><span>{props.department}</span></div> : null}
      {props.guardian ? <div className="row"><span className="label">guardian</span><span>{props.guardian}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.chiefComplaint ? <div className="row"><span className="label">chiefComplaint</span><span>{props.chiefComplaint}</span></div> : null}
  </IndustryCardShell>
);

export default ChildPatientCard;
