import SwiftUI

/// 播放器 - video industry (SwiftUI)
public struct VideoPlayer: View {
    public var title: String = ""
    public var src: String = ""
    public var duration: String = ""
    public var status: String = ""

    public init(title: String = "", src: String = "", duration: String = "", status: String = "") {
        self.title = title
        self.src = src
        self.duration = duration
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "播放器",
            status: status.isEmpty ? nil : status,
            fields: [
            ("标题", title),
            ("源地址", src),
            ("时长", duration),
            ]
        )
    }
}