package com.uilib.tokens

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember

/**
 * UiLib theme root — provides [LocalUiColors] for light / dark.
 */
@Composable
fun UiLibTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = remember(darkTheme) {
        if (darkTheme) DarkColorScheme else LightColorScheme
    }
    CompositionLocalProvider(LocalUiColors provides colors) {
        content()
    }
}
