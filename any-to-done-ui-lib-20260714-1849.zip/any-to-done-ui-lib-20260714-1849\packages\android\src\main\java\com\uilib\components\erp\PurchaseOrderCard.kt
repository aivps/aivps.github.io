﻿package com.uilib.components.erp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 采购单 - field-deep aligned shell (Compose) */
@Composable
fun PurchaseOrderCard(
    id: String = "",
    orderNumber: String = "",
    supplier: String = "",
    totalAmount: String = "",
    status: String = "",
    orderDate: String = "",
    expectedDate: String = "",
    buyer: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "采购单",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "订单号" to orderNumber,
            "供应商" to supplier,
            "金额" to totalAmount,
            "下单日期" to orderDate,
            "预计到货" to expectedDate,
            "采购员" to buyer,
        ),
        modifier = modifier,
    )
}
