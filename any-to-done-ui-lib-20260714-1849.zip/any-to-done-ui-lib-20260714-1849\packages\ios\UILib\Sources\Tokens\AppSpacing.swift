import SwiftUI

public enum AppSpacing {
    public static let xs: CGFloat = 4
    public static let sm: CGFloat = 8
    public static let md: CGFloat = 12
    public static let lg: CGFloat = 16
    public static let xl: CGFloat = 20
    public static let xxl: CGFloat = 24
    public static let radiusSm: CGFloat = 4
    public static let radiusMd: CGFloat = 8
    public static let radiusLg: CGFloat = 12
    public static let radiusXl: CGFloat = 16
}