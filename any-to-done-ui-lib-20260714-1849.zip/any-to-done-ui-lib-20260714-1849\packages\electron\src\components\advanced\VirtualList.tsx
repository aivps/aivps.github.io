import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface VirtualListProps {
  itemCount?: string | number;
  itemHeight?: string | number;
  overscan?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 虚拟列表 - advanced industry (Electron / desktop) */
export const VirtualList: React.FC<VirtualListProps> = ({
  itemCount,
  itemHeight,
  overscan,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="虚拟列表"
    
    fields={[
    { label: '条目数', value: itemCount },
    { label: '条目高度', value: itemHeight },
    { label: '预渲染', value: overscan },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default VirtualList;