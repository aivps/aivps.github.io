import SwiftUI

/// 服务器 - monitor industry (SwiftUI)
public struct ServerStatus: View {
    public var hostname: String = ""
    public var cpu: String = ""
    public var memory: String = ""
    public var disk: String = ""
    public var status: String = ""

    public init(hostname: String = "", cpu: String = "", memory: String = "", disk: String = "", status: String = "") {
        self.hostname = hostname
        self.cpu = cpu
        self.memory = memory
        self.disk = disk
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "服务器",
            status: status.isEmpty ? nil : status,
            fields: [
            ("主机名", hostname),
            ("CPU", cpu),
            ("内存", memory),
            ("磁盘", disk),
            ]
        )
    }
}