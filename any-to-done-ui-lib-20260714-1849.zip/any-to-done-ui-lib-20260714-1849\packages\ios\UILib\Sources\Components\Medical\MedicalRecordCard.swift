﻿import SwiftUI

/// 病历 - industry (SwiftUI, field-deep aligned)
public struct MedicalRecordCard: View {
    public var recordId: String = ""
    public var patientName: String = ""
    public var patientId: String = ""
    public var recordType: String = ""
    public var date: String = ""
    public var department: String = ""
    public var doctor: String = ""
    public var diagnosis: String = ""
    public var status: String = ""

    public init(recordId: String = "", patientName: String = "", patientId: String = "", recordType: String = "", date: String = "", department: String = "", doctor: String = "", diagnosis: String = "", status: String = "") {
        self.recordId = recordId
        self.patientName = patientName
        self.patientId = patientId
        self.recordType = recordType
        self.date = date
        self.department = department
        self.doctor = doctor
        self.diagnosis = diagnosis
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "病历",
            status: status.isEmpty ? nil : status,
            fields: [
            ("记录ID", recordId),
            ("患者", patientName),
            ("患者ID", patientId),
            ("类型", recordType),
            ("日期", date),
            ("科室", department),
            ("医生", doctor),
            ("诊断", diagnosis),
            ]
        )
    }
}
