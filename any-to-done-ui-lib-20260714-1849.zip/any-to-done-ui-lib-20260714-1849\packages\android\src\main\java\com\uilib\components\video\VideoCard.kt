package com.uilib.components.video

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 视频 - video industry (Compose) */
@Composable
fun VideoCard(
    title: String = "",
    duration: String = "",
    views: String = "",
    author: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "视频",
        status = status.ifBlank { null },
        fields = listOf(
            "标题" to title,
            "时长" to duration,
            "播放量" to views,
            "作者" to author,
        ),
        modifier = modifier,
    )
}