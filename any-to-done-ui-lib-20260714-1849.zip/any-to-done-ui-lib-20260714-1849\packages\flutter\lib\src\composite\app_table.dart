import 'package:flutter/material.dart';
class AppTable extends StatelessWidget {
  final List<TableColumn> columns;
  final List<Map<String, dynamic>> dataSource;
  final bool bordered;
  final bool striped;
  final bool loading;
  final Widget? emptyWidget;
  final ValueChanged<Map<String, dynamic>>? onRowTap;

  const AppTable({
    super.key,
    required this.columns,
    required this.dataSource,
    this.bordered = true,
    this.striped = false,
    this.loading = false,
    this.emptyWidget,
    this.onRowTap,
  });

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: Padding(
        padding: EdgeInsets.all(40), child: CircularProgressIndicator()));
    }
    if (dataSource.isEmpty) {
      return emptyWidget ?? Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Text('暂无数据', style: TextStyle(color: Colors.grey[500])),
        ),
      );
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
        decoration: BoxDecoration(
          border: bordered ? Border.all(color: Colors.grey[300]!) : null,
          borderRadius: BorderRadius.circular(8),
        ),
        child: DataTable(
          headingRowColor: WidgetStateProperty.all(Colors.grey[50]),
          dataRowColor: null,
          columns: columns.map((c) => DataColumn(
            label: Text(c.title, style: const TextStyle(fontWeight: FontWeight.w600)),
          )).toList(),
          rows: dataSource.asMap().entries.map((e) {
            final row = e.value;
            final i = e.key;
            return DataRow(
            color: striped && i.isOdd ? WidgetStateProperty.all(Colors.grey[50]) : null,
            onSelectChanged: onRowTap != null ? (_) => onRowTap!(row) : null,
            cells: columns.map((c) => DataCell(
              Text('${row[c.key] ?? ''}'),
            )).toList(),
          );
          }).toList(),
        ),
      ),
    );
  }
}

class TableColumn {
  final String key;
  final String title;
  final double? width;
  final bool sortable;

  const TableColumn({required this.key, required this.title, this.width, this.sortable = false});
}
