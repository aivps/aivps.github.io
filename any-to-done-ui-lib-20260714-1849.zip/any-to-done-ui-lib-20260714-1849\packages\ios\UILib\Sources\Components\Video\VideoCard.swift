import SwiftUI

/// 视频 - video industry (SwiftUI)
public struct VideoCard: View {
    public var title: String = ""
    public var duration: String = ""
    public var views: String = ""
    public var author: String = ""
    public var status: String = ""

    public init(title: String = "", duration: String = "", views: String = "", author: String = "", status: String = "") {
        self.title = title
        self.duration = duration
        self.views = views
        self.author = author
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "视频",
            status: status.isEmpty ? nil : status,
            fields: [
            ("标题", title),
            ("时长", duration),
            ("播放量", views),
            ("作者", author),
            ]
        )
    }
}