import SwiftUI

/// 工单状态 - workflow industry (SwiftUI)
public struct TicketStatus: View {
    public var ticketNo: String = ""
    public var type: String = ""
    public var assignee: String = ""
    public var updatedAt: String = ""
    public var status: String = ""

    public init(ticketNo: String = "", type: String = "", assignee: String = "", updatedAt: String = "", status: String = "") {
        self.ticketNo = ticketNo
        self.type = type
        self.assignee = assignee
        self.updatedAt = updatedAt
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "工单状态",
            status: status.isEmpty ? nil : status,
            fields: [
            ("工单号", ticketNo),
            ("类型", type),
            ("处理人", assignee),
            ("更新时间", updatedAt),
            ]
        )
    }
}