import SwiftUI

/// 广告活动 - advertising industry (SwiftUI)
public struct CampaignCard: View {
    public var name: String = ""
    public var budget: String = ""
    public var spent: String = ""
    public var impressions: String = ""
    public var status: String = ""

    public init(name: String = "", budget: String = "", spent: String = "", impressions: String = "", status: String = "") {
        self.name = name
        self.budget = budget
        self.spent = spent
        self.impressions = impressions
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "广告活动",
            status: status.isEmpty ? nil : status,
            fields: [
            ("名称", name),
            ("预算", budget),
            ("已花费", spent),
            ("曝光量", impressions),
            ]
        )
    }
}