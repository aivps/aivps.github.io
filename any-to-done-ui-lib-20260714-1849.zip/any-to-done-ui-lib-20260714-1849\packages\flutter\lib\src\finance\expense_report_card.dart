import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// ExpenseReportCard — field-deep aligned to React ExpenseReportCard.
class ExpenseReportCard extends StatelessWidget {
  final String reportId;
  final String reportName;
  final String applicant;
  final String department;
  final String submitDate;
  final double totalAmount;
  final String status; // draft | submitted | reviewing | approved | rejected | paid
  final String? approver;
  final String? approveDate;
  final String? rejectReason;
  final VoidCallback? onTap;
  final VoidCallback? onSubmit;
  final VoidCallback? onApprove;
  final VoidCallback? onReject;
  final VoidCallback? onViewDetail;
  final bool disabled;

  /// @deprecated
  final String? reportNo;
  final double? amount;
  final String? date;

  const ExpenseReportCard({
    super.key,
    this.reportId = '',
    this.reportName = '',
    required this.applicant,
    required this.department,
    this.submitDate = '',
    this.totalAmount = 0,
    required this.status,
    this.approver,
    this.approveDate,
    this.rejectReason,
    this.onTap,
    this.onSubmit,
    this.onApprove,
    this.onReject,
    this.onViewDetail,
    this.disabled = false,
    this.reportNo,
    this.amount,
    this.date,
  });

  String get _reportId => reportId.isNotEmpty ? reportId : (reportNo ?? '');
  String get _submitDate =>
      submitDate.isNotEmpty ? submitDate : (date ?? '');
  double get _total => totalAmount > 0 ? totalAmount : (amount ?? 0);

  static const _statusLabels = {
    'draft': '草稿',
    'submitted': '已提交',
    'reviewing': '审批中',
    'approved': '已通过',
    'rejected': '已驳回',
    'paid': '已付款',
    '草稿': '草稿',
    '审批中': '审批中',
    '已通过': '已通过',
    '已驳回': '已驳回',
    '已打款': '已付款',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'draft':
      case '草稿':
        return colors.muted;
      case 'submitted':
        return colors.primary;
      case 'reviewing':
      case '审批中':
        return colors.warning;
      case 'approved':
      case 'paid':
      case '已通过':
      case '已打款':
        return colors.success;
      case 'rejected':
      case '已驳回':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onViewDetail?.call();
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          reportName.isNotEmpty ? reportName : _reportId,
                          style: AppTypography.body
                              .copyWith(fontWeight: FontWeight.w600),
                        ),
                        Text(
                          '$_reportId · $_submitDate',
                          style: AppTypography.caption,
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style: AppTypography.caption.copyWith(color: sc),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                '¥${_total.toStringAsFixed(2)}',
                style: AppTypography.h3,
              ),
              const SizedBox(height: 8),
              Text(
                '$applicant · $department',
                style: AppTypography.caption
                    .copyWith(color: colors.textSecondary),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
