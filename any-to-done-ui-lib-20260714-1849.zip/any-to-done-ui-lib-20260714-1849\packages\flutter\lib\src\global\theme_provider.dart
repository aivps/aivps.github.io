/// ThemeProvider - 主题切换容器
/// 支持浅色/暗黑模式 + 六色系切换

import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';

enum ThemeMode { light, dark }

enum ThemePalette { blue, red, green, purple, cyan, orange }

class ThemeProvider extends InheritedWidget {
  final ThemeMode mode;
  final ThemePalette palette;
  final ValueChanged<ThemeMode> onModeChanged;
  final ValueChanged<ThemePalette> onPaletteChanged;

  const ThemeProvider({
    Key? key,
    required Widget child,
    required this.mode,
    required this.palette,
    required this.onModeChanged,
    required this.onPaletteChanged,
  }) : super(key: key, child: child);

  static ThemeProvider? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ThemeProvider>();
  }

  ThemeData get lightTheme => _buildTheme(ThemeMode.light, palette);
  ThemeData get darkTheme => _buildTheme(ThemeMode.dark, palette);

  ThemeData get currentTheme =>
      mode == ThemeMode.dark ? darkTheme : lightTheme;

  AppThemeColors get colors =>
      mode == ThemeMode.dark ? AppThemeColors.dark : AppThemeColors.light;

  static ThemeData _buildTheme(ThemeMode mode, ThemePalette palette) {
    final bool isDark = mode == ThemeMode.dark;
    final Color primaryColor = _getPrimaryColor(palette);
    final tokens = isDark ? AppThemeColors.dark : AppThemeColors.light;

    return ThemeData(
      useMaterial3: true,
      brightness: isDark ? Brightness.dark : Brightness.light,
      colorSchemeSeed: primaryColor,
      scaffoldBackgroundColor: tokens.bgPage,
      cardTheme: CardThemeData(
        color: tokens.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: tokens.border),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: tokens.surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: BorderSide(color: tokens.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: BorderSide(color: tokens.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(4),
          borderSide: BorderSide(color: primaryColor, width: 2),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryColor,
          foregroundColor: Colors.white,
          minimumSize: const Size(0, 40),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        ),
      ),
    );
  }

  static Color _getPrimaryColor(ThemePalette palette) {
    switch (palette) {
      case ThemePalette.blue:
        return PaletteColors.bluePrimary;
      case ThemePalette.red:
        return PaletteColors.redPrimary;
      case ThemePalette.green:
        return PaletteColors.greenPrimary;
      case ThemePalette.purple:
        return PaletteColors.purplePrimary;
      case ThemePalette.cyan:
        return PaletteColors.cyanPrimary;
      case ThemePalette.orange:
        return PaletteColors.orangePrimary;
    }
  }

  @override
  bool updateShouldNotify(ThemeProvider oldWidget) {
    return mode != oldWidget.mode || palette != oldWidget.palette;
  }
}
