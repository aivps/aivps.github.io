/** ServiceMenuCard - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'name': { type: String, value: '' },
    'price': { type: String, value: '' },
    'duration': { type: String, value: '' },
    'category': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});