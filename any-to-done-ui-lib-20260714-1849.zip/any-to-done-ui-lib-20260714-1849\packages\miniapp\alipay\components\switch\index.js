/**
 * 开关组件
 */
Component({
  options: {
    addGlobalClass: true,
  },

  properties: {
    // 是否选中
    checked: {
      type: Boolean,
      value: false,
    },
    // 是否禁用
    disabled: {
      type: Boolean,
      value: false,
    },
    // 开关尺寸
    size: {
      type: String,
      value: 'md', // sm, md, lg
    },
    // 选中颜色
    activeColor: {
      type: String,
      value: '#1677FF',
    },
  },

  methods: {
    onChange(e) {
      if (this.properties.disabled) return;
      this.triggerEvent('change', { checked: e.detail.value });
    },
  },
});
