import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface PlayerListCardProps {
  nickname?: string | number;
  level?: string | number;
  coins?: string | number;
  status?: string;
  /** @deprecated use nickname */
  name?: string | number;
  /** @deprecated use coins */
  score?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 玩家 - field-deep aligned shell (single-row) */
export const PlayerListCard: React.FC<PlayerListCardProps> = ({
  nickname,
  level,
  coins,
  status,
  name,
  score,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="玩家"
    status={status}
    fields={[
      { label: '昵称', value: nickname ?? name },
      { label: '等级', value: level },
      { label: '金币', value: coins ?? score },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default PlayerListCard;
