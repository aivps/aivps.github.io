package com.uilib.components.finance

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 发票 - field-deep aligned shell (Compose) */
@Composable
fun InvoiceCard(
    id: String = "",
    invoiceNumber: String = "",
    type: String = "",
    client: String = "",
    amount: String = "",
    tax: String = "",
    total: String = "",
    status: String = "",
    issueDate: String = "",
    dueDate: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "发票",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "发票号" to invoiceNumber,
            "类型" to type,
            "客户" to client,
            "金额" to amount,
            "税额" to tax,
            "合计" to total,
            "开票日期" to issueDate,
            "到期日" to dueDate,
        ),
        modifier = modifier,
    )
}