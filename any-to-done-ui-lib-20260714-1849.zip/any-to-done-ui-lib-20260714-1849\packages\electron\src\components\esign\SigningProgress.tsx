import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface SigningProgressProps {
  contractId?: string | number;
  contractTitle?: string | number;
  progress?: string | number;
  signed?: string | number;
  total?: string | number;
  status?: string;
  /** @deprecated use contractId */
  contractNo?: string | number;
  /** @deprecated use status */
  overallStatus?: string;
  currentSigner?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 签署进度 - field-deep aligned shell */
export const SigningProgress: React.FC<SigningProgressProps> = ({
  contractId,
  contractTitle,
  progress,
  signed,
  total,
  status,
  contractNo,
  overallStatus,
  currentSigner,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="签署进度"
    status={status ?? overallStatus}
    fields={[
      { label: '合同 ID', value: contractId ?? contractNo },
      { label: '合同标题', value: contractTitle },
      { label: '进度%', value: progress },
      { label: '已签', value: signed },
      { label: '合计', value: total },
      { label: '当前签署人', value: currentSigner },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default SigningProgress;
