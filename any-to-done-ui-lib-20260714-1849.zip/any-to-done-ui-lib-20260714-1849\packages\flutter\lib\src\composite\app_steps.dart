import 'package:flutter/material.dart';
import '../tokens/colors.dart';

class AppSteps extends StatelessWidget {
  final int current;
  final List<StepItem> steps;
  final Axis direction;

  const AppSteps({
    super.key,
    required this.current,
    required this.steps,
    this.direction = Axis.horizontal,
  });

  @override
  Widget build(BuildContext context) {
    if (direction == Axis.vertical) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(steps.length, (i) {
          final status = _getStatus(i);
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(children: [
                _buildIcon(status),
                if (i < steps.length - 1)
                  Container(width: 2, height: 32, color: status == 'done' ? AppColors.primary : Colors.grey[300]),
              ]),
              const SizedBox(width: 12),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(steps[i].title,
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500,
                              color: status == 'wait' ? Colors.grey : null)),
                      if (steps[i].description != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(steps[i].description!, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          );
        }),
      );
    }

    return Row(
      children: List.generate(steps.length, (i) {
        final status = _getStatus(i);
        return Expanded(
          child: Row(
            children: [
              _buildIcon(status),
              if (i < steps.length - 1)
                Expanded(
                  child: Container(height: 2, color: status == 'done' ? AppColors.primary : Colors.grey[300]),
                ),
            ],
          ),
        );
      }),
    );
  }

  String _getStatus(int i) {
    if (i < current) return 'done';
    if (i == current) return 'process';
    return 'wait';
  }

  Widget _buildIcon(String status) {
    final bg = status == 'done'
        ? AppColors.primary
        : status == 'process'
            ? Colors.white
            : Colors.white;
    final border = status == 'done'
        ? AppColors.primary
        : status == 'process'
            ? AppColors.primary
            : Colors.grey[300]!;
    final fg = status == 'done' ? Colors.white : status == 'process' ? AppColors.primary : Colors.grey[400]!;

    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(color: bg, shape: BoxShape.circle, border: Border.all(color: border, width: 2)),
      alignment: Alignment.center,
      child: status == 'done'
          ? const Icon(Icons.check, size: 16, color: Colors.white)
          : Text('${status == 'process' ? current + 1 : ''}', style: TextStyle(color: fg, fontWeight: FontWeight.w600)),
    );
  }
}

class StepItem {
  final String title;
  final String? description;
  const StepItem({required this.title, this.description});
}
