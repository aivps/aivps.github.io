package com.uilib.components.logistics

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 库存 - field-deep aligned shell (Compose) */
@Composable
fun InventoryCard(
    id: String = "",
    name: String = "",
    sku: String = "",
    quantity: String = "",
    unit: String = "",
    location: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "库存",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "名称" to name,
            "SKU" to sku,
            "数量" to quantity,
            "单位" to unit,
            "库位" to location,
        ),
        modifier = modifier,
    )
}