import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';
/// KpiItem KPI 指标项
class KpiItem {
  final String label;
  final String value;
  final String? delta;
  final bool? positive;

  const KpiItem({
    required this.label,
    required this.value,
    this.delta,
    this.positive,
  });
}

/// KPIBoard KPI 看板
class KPIBoard extends StatelessWidget {
  final String title;
  final List<KpiItem> items;
  final VoidCallback? onTap;

  const KPIBoard({
    super.key,
    required this.title,
    required this.items,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: AppSpacing.lg,
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: AppSpacing.borderRadiusLg,
          boxShadow: AppShadows.sm,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: AppTypography.h3),
            const SizedBox(height: 12),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: items.map((item) {
                final deltaColor = item.positive == null
                    ? colors.muted
                    : (item.positive! ? colors.success : colors.danger);
                return SizedBox(
                  width: 140,
                  child: Container(
                    padding: AppSpacing.md,
                    decoration: BoxDecoration(
                      color: colors.bgPage,
                      borderRadius: AppSpacing.borderRadiusMd,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.label, style: AppTypography.caption),
                        Text(item.value, style: AppTypography.h2),
                        if (item.delta != null)
                          Text(item.delta!, style: AppTypography.caption.copyWith(color: deltaColor)),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}