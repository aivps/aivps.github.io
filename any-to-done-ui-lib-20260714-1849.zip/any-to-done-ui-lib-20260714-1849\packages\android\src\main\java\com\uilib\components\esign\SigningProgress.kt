package com.uilib.components.esign

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 签署进度 - field-deep aligned shell (Compose) */
@Composable
fun SigningProgress(
    contractId: String = "",
    contractTitle: String = "",
    progress: String = "",
    signed: String = "",
    total: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "签署进度",
        status = status.ifBlank { null },
        fields = listOf(
            "合同 ID" to contractId,
            "合同标题" to contractTitle,
            "进度%" to progress,
            "已签" to signed,
            "合计" to total,
        ),
        modifier = modifier,
    )
}
