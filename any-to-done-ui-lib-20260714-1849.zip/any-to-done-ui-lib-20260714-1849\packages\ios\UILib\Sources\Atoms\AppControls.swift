import SwiftUI

// MARK: - Button (React-aligned shallow API)

/// Canonical variants. Legacy: outline→secondary, link→text.
public enum AppButtonVariant: String, Sendable {
    case primary
    case secondary
    case text
    case danger
    case ghost
    /// - Warning: maps to secondary with outline stroke
    case outline
    /// - Warning: maps to text
    case link
}

public enum AppButtonSize: String, Sendable {
    case xs, sm, md, lg
}

public struct AppButton: View {
    public let title: String
    public var variant: AppButtonVariant
    public var size: AppButtonSize
    public var enabled: Bool
    public var loading: Bool
    public var circle: Bool
    public var error: Bool
    public var block: Bool
    /// Legacy boolean — only used when variant is `.primary`
    public var primary: Bool
    public let action: () -> Void

    @Environment(\.uiColors) private var uiColors
    @State private var pressed = false

    public init(
        _ title: String,
        variant: AppButtonVariant = .primary,
        size: AppButtonSize = .md,
        enabled: Bool = true,
        loading: Bool = false,
        circle: Bool = false,
        error: Bool = false,
        block: Bool = false,
        primary: Bool = true,
        action: @escaping () -> Void
    ) {
        self.title = title
        self.variant = variant
        self.size = size
        self.enabled = enabled
        self.loading = loading
        self.circle = circle
        self.error = error
        self.block = block
        self.primary = primary
        self.action = action
    }

    /// Legacy convenience: `AppButton("OK", primary: true) { }`
    public init(_ title: String, enabled: Bool = true, primary: Bool = true, action: @escaping () -> Void) {
        self.init(title, variant: .primary, enabled: enabled, primary: primary, action: action)
    }

    private var resolved: AppButtonVariant {
        switch variant {
        case .outline: return .secondary
        case .link: return .text
        case .primary where !primary: return .secondary
        default: return variant
        }
    }

    private var isOutlineLegacy: Bool { variant == .outline }
    private var isDisabled: Bool { !enabled || loading }

    private var height: CGFloat {
        switch size {
        case .xs: return 24
        case .sm: return 32
        case .md: return 40
        case .lg: return 48
        }
    }

    private var hPad: CGFloat {
        switch size {
        case .xs: return 8
        case .sm: return 12
        case .md: return 16
        case .lg: return 24
        }
    }

    private var bg: Color {
        if isDisabled { return uiColors.gray200 }
        switch resolved {
        case .primary: return uiColors.primary
        case .danger: return uiColors.red
        case .secondary where isOutlineLegacy: return .clear
        case .secondary: return uiColors.surface
        case .ghost, .text, .outline, .link: return .clear
        }
    }

    private var fg: Color {
        if isDisabled { return uiColors.muted }
        switch resolved {
        case .primary, .danger: return .white
        case .secondary where isOutlineLegacy: return uiColors.foreground
        case .secondary: return uiColors.primary
        case .ghost: return uiColors.foreground
        case .text, .outline, .link: return uiColors.primary
        }
    }

    private var stroke: Color {
        if error { return uiColors.red }
        switch resolved {
        case .secondary where isOutlineLegacy: return uiColors.border
        case .secondary: return uiColors.primary
        case .ghost: return uiColors.border
        default: return .clear
        }
    }

    public var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if loading {
                    ProgressView()
                        .scaleEffect(0.7)
                        .tint(fg)
                }
                Text(title)
                    .font(AppTypography.body)
                    .foregroundColor(fg)
            }
            .frame(maxWidth: block ? .infinity : nil)
            .frame(width: circle ? height : nil, height: height)
            .padding(.horizontal, circle ? 0 : hPad)
            .background(bg)
            .overlay(
                RoundedRectangle(cornerRadius: circle ? height / 2 : AppSpacing.radiusMd)
                    .stroke(stroke, lineWidth: error ? 2 : 1)
            )
            .cornerRadius(circle ? height / 2 : AppSpacing.radiusMd)
        }
        .disabled(isDisabled)
        .opacity(isDisabled && !loading ? 0.5 : 1)
        .scaleEffect(pressed && !isDisabled ? AppMotion.pressScale : 1)
        .animation(.easeOut(duration: AppMotion.durationFast), value: pressed)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in if !isDisabled { pressed = true } }
                .onEnded { _ in pressed = false }
        )
        .buttonStyle(.plain)
    }
}

// MARK: - Tag

public enum AppTagTone: String, Sendable {
    case `default`, primary, success, warning, danger, info
}

public struct AppTag: View {
    public let text: String
    public var tone: AppTagTone
    public var color: Color?
    public var background: Color?
    public var checked: Bool
    public var closable: Bool
    public var onClose: (() -> Void)?

    @Environment(\.uiColors) private var uiColors

    public init(
        text: String,
        tone: AppTagTone = .primary,
        color: Color? = nil,
        background: Color? = nil,
        checked: Bool = false,
        closable: Bool = false,
        onClose: (() -> Void)? = nil
    ) {
        self.text = text
        self.tone = tone
        self.color = color
        self.background = background
        self.checked = checked
        self.closable = closable
        self.onClose = onClose
    }

    /// Legacy convenience
    public init(text: String, color: Color? = nil, background: Color? = nil) {
        self.init(text: text, tone: .primary, color: color, background: background)
    }

    private var fg: Color {
        if let color { return color }
        switch tone {
        case .default: return uiColors.muted
        case .primary: return uiColors.primary
        case .success: return uiColors.green
        case .warning: return uiColors.orange
        case .danger: return uiColors.red
        case .info: return uiColors.cyan
        }
    }

    private var bg: Color {
        background ?? uiColors.primaryBg
    }

    public var body: some View {
        HStack(spacing: 2) {
            Text(text)
                .font(AppTypography.caption)
                .fontWeight(.semibold)
                .foregroundColor(fg)
            if closable {
                Text("×")
                    .font(AppTypography.caption)
                    .foregroundColor(fg)
                    .onTapGesture { onClose?() }
            }
        }
        .padding(.horizontal, AppSpacing.sm)
        .padding(.vertical, 2)
        .background(bg)
        .cornerRadius(AppSpacing.radiusSm)
        .overlay(
            RoundedRectangle(cornerRadius: AppSpacing.radiusSm)
                .stroke(checked ? uiColors.primary : Color.clear, lineWidth: 1)
        )
    }
}

// MARK: - Badge

public struct AppBadge: View {
    public var count: Int?
    public var text: String?
    public var color: AppTagTone
    public var size: AppButtonSize
    public var dot: Bool
    public var overflowCount: Int

    @Environment(\.uiColors) private var uiColors

    public init(
        count: Int? = nil,
        text: String? = nil,
        color: AppTagTone = .danger,
        size: AppButtonSize = .md,
        dot: Bool = false,
        overflowCount: Int = 99
    ) {
        self.count = count
        self.text = text
        self.color = color
        self.size = size
        self.dot = dot
        self.overflowCount = overflowCount
    }

    private var bg: Color {
        switch color {
        case .default: return uiColors.muted
        case .primary: return uiColors.primary
        case .success: return uiColors.green
        case .warning: return uiColors.orange
        case .danger: return uiColors.red
        case .info: return uiColors.cyan
        }
    }

    private var display: String {
        if let text { return text }
        guard let count else { return "" }
        return count > overflowCount ? "\(overflowCount)+" : "\(count)"
    }

    private var dim: CGFloat {
        if dot {
            switch size {
            case .xs, .sm: return 6
            case .lg: return 10
            case .md: return 8
            }
        }
        switch size {
        case .xs, .sm: return 16
        case .lg: return 24
        case .md: return 20
        }
    }

    public var body: some View {
        Group {
            if dot {
                Circle().fill(bg).frame(width: dim, height: dim)
            } else {
                Text(display)
                    .font(AppTypography.caption)
                    .foregroundColor(.white)
                    .padding(.horizontal, 4)
                    .frame(minWidth: dim, minHeight: dim)
                    .background(bg)
                    .clipShape(Capsule())
            }
        }
    }
}

// MARK: - Card

public struct AppCard<Content: View>: View {
    public var title: String?
    public var extra: String?
    public var bordered: Bool
    public var loading: Bool
    public var onTap: (() -> Void)?
    public let content: Content

    @Environment(\.uiColors) private var uiColors
    @State private var pressed = false

    public init(
        title: String? = nil,
        extra: String? = nil,
        bordered: Bool = true,
        loading: Bool = false,
        onTap: (() -> Void)? = nil,
        @ViewBuilder content: () -> Content
    ) {
        self.title = title
        self.extra = extra
        self.bordered = bordered
        self.loading = loading
        self.onTap = onTap
        self.content = content()
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: AppSpacing.sm) {
            if title != nil || extra != nil {
                HStack {
                    if let title {
                        Text(title).font(AppTypography.h3).foregroundColor(uiColors.foreground)
                    }
                    Spacer()
                    if let extra {
                        Text(extra).font(AppTypography.caption).foregroundColor(uiColors.primary)
                    }
                }
            }
            if loading {
                Text("加载中…").font(AppTypography.caption).foregroundColor(uiColors.muted)
            } else {
                content
            }
        }
        .padding(.horizontal, AppSpacing.xl)
        .padding(.vertical, AppSpacing.lg)
        .background(uiColors.surface)
        .cornerRadius(AppSpacing.radiusLg)
        .overlay(
            RoundedRectangle(cornerRadius: AppSpacing.radiusLg)
                .stroke(bordered ? uiColors.border : Color.clear, lineWidth: 1)
        )
        .scaleEffect(pressed && onTap != nil ? AppMotion.pressScale : 1)
        .animation(.easeOut(duration: AppMotion.durationFast), value: pressed)
        .contentShape(Rectangle())
        .onTapGesture { onTap?() }
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in if onTap != nil { pressed = true } }
                .onEnded { _ in pressed = false }
        )
    }
}

// MARK: - Input

public enum AppInputVariant: String, Sendable {
    case outlined, filled, borderless
}

public enum AppInputStatus: String, Sendable {
    case `default`, error, success, warning
}

public struct AppInput: View {
    @Binding public var text: String
    public var placeholder: String
    public var label: String?
    public var variant: AppInputVariant
    public var status: AppInputStatus
    public var errorMessage: String?
    public var helperText: String?
    public var disabled: Bool
    public var readOnly: Bool
    public var loading: Bool

    @Environment(\.uiColors) private var uiColors

    public init(
        text: Binding<String>,
        placeholder: String = "",
        label: String? = nil,
        variant: AppInputVariant = .outlined,
        status: AppInputStatus = .default,
        errorMessage: String? = nil,
        helperText: String? = nil,
        disabled: Bool = false,
        readOnly: Bool = false,
        loading: Bool = false
    ) {
        self._text = text
        self.placeholder = placeholder
        self.label = label
        self.variant = variant
        self.status = status
        self.errorMessage = errorMessage
        self.helperText = helperText
        self.disabled = disabled
        self.readOnly = readOnly
        self.loading = loading
    }

    private var effectiveStatus: AppInputStatus {
        if errorMessage != nil && !(errorMessage?.isEmpty ?? true) { return .error }
        return status
    }

    private var borderColor: Color {
        switch effectiveStatus {
        case .error: return uiColors.red
        case .success: return uiColors.green
        case .warning: return uiColors.orange
        case .default: return uiColors.border
        }
    }

    private var bg: Color {
        switch variant {
        case .filled: return uiColors.gray100
        case .borderless: return .clear
        case .outlined: return uiColors.surface
        }
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            if let label {
                Text(label).font(AppTypography.caption).foregroundColor(uiColors.foreground)
            }
            HStack {
                TextField(placeholder, text: $text)
                    .font(AppTypography.body)
                    .foregroundColor(disabled ? uiColors.muted : uiColors.foreground)
                    .disabled(disabled || loading || readOnly)
                if loading {
                    ProgressView().scaleEffect(0.7)
                }
            }
            .padding(.horizontal, AppSpacing.md)
            .frame(height: 40)
            .background(bg)
            .cornerRadius(AppSpacing.radiusMd)
            .overlay(
                RoundedRectangle(cornerRadius: AppSpacing.radiusMd)
                    .stroke(variant == .borderless ? Color.clear : borderColor, lineWidth: 1)
            )
            if let msg = errorMessage ?? helperText, !msg.isEmpty {
                Text(msg)
                    .font(AppTypography.caption)
                    .foregroundColor(effectiveStatus == .error ? uiColors.red : uiColors.muted)
            }
        }
    }
}

// MARK: - Industry shell (unchanged behaviour, uses theme)

public struct IndustryCardShell: View {
    public let title: String
    public var status: String?
    public let fields: [(String, String)]
    public var onTap: (() -> Void)?

    @Environment(\.uiColors) private var uiColors
    @Environment(\.colorScheme) private var colorScheme
    @State private var pressed = false

    public init(
        title: String,
        status: String? = nil,
        fields: [(String, String)],
        onTap: (() -> Void)? = nil
    ) {
        self.title = title
        self.status = status
        self.fields = fields
        self.onTap = onTap
    }

    public var body: some View {
        let colors = uiColors
        VStack(alignment: .leading, spacing: AppSpacing.sm) {
            HStack {
                Text(title)
                    .font(AppTypography.h3)
                    .foregroundColor(colors.foreground)
                Spacer()
                if let status, !status.isEmpty {
                    AppTag(text: status)
                }
            }
            ForEach(Array(fields.filter { !$0.1.isEmpty }.enumerated()), id: \.offset) { _, item in
                HStack {
                    Text(item.0)
                        .font(AppTypography.caption)
                        .foregroundColor(colors.muted)
                    Spacer()
                    Text(item.1)
                        .font(AppTypography.body)
                        .foregroundColor(colors.gray700)
                        .multilineTextAlignment(.trailing)
                }
            }
        }
        .padding(.horizontal, AppSpacing.xl)
        .padding(.vertical, AppSpacing.lg)
        .background(colors.surface)
        .cornerRadius(AppSpacing.radiusLg)
        .overlay(
            RoundedRectangle(cornerRadius: AppSpacing.radiusLg)
                .stroke(pressed ? colors.primary : colors.border, lineWidth: 1)
        )
        .shadow(
            color: Color.black.opacity(colorScheme == .dark ? 0.35 : 0.06),
            radius: pressed ? 6 : 3,
            x: 0,
            y: pressed ? 2 : 1
        )
        .scaleEffect(pressed ? AppMotion.pressScale : 1)
        .animation(.easeOut(duration: AppMotion.durationFast), value: pressed)
        .contentShape(Rectangle())
        .onTapGesture { onTap?() }
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in if onTap != nil { pressed = true } }
                .onEnded { _ in pressed = false }
        )
        .modifier(SystemThemeBridge())
    }
}

private struct SystemThemeBridge: ViewModifier {
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.uiColors) private var uiColors

    func body(content: Content) -> some View {
        content.environment(
            \.uiColors,
            colorScheme == .dark && uiColors == .light ? .dark : uiColors
        )
    }
}
