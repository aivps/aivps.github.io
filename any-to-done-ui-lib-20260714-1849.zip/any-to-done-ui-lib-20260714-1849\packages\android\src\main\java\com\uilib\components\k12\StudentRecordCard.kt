package com.uilib.components.k12

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 学籍 - k12 industry (Compose) */
@Composable
fun StudentRecordCard(
    name: String = "",
    studentId: String = "",
    grade: String = "",
    className: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "学籍",
        status = status.ifBlank { null },
        fields = listOf(
            "名称" to name,
            "学号" to studentId,
            "年级" to grade,
            "班级" to className,
        ),
        modifier = modifier,
    )
}