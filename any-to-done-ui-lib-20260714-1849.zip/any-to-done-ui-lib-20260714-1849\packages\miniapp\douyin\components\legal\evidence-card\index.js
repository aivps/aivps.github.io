/** 证据 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'caseId': { type: String, value: '' },
    'name': { type: String, value: '' },
    'type': { type: String, value: '' },
    'uploadDate': { type: String, value: '' },
    'size': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});