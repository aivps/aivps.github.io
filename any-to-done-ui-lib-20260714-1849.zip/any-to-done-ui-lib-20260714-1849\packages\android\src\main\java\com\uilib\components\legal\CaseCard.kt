package com.uilib.components.legal

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 案件 - field-deep aligned shell (Compose) */
@Composable
fun CaseCard(
    id: String = "",
    caseNumber: String = "",
    caseType: String = "",
    title: String = "",
    client: String = "",
    lawyer: String = "",
    filingDate: String = "",
    courtDate: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "案件",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "案号" to caseNumber,
            "类型" to caseType,
            "标题" to title,
            "当事人" to client,
            "律师" to lawyer,
            "立案日期" to filingDate,
            "开庭日期" to courtDate,
        ),
        modifier = modifier,
    )
}