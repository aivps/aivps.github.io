import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface InvoiceCardProps {
  id?: string | number;
  invoiceNumber?: string | number;
  type?: string | number;
  client?: string | number;
  amount?: string | number;
  tax?: string | number;
  total?: string | number;
  status?: string;
  issueDate?: string | number;
  dueDate?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 发票 - field-deep aligned shell */
export const InvoiceCard: React.FC<InvoiceCardProps> = ({
  id,
  invoiceNumber,
  type,
  client,
  amount,
  tax,
  total,
  status,
  issueDate,
  dueDate,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="发票"
    status={status}
    fields={[
    { label: 'ID', value: id },
    { label: '发票号', value: invoiceNumber },
    { label: '类型', value: type },
    { label: '客户', value: client },
    { label: '金额', value: amount },
    { label: '税额', value: tax },
    { label: '合计', value: total },
    { label: '开票日期', value: issueDate },
    { label: '到期日', value: dueDate },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default InvoiceCard;