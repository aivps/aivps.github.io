package com.uilib.components.portrait

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 画像列表 - portrait industry (Compose) */
@Composable
fun PortraitList(
    title: String = "",
    count: String = "",
    segment: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "画像列表",
        status = status.ifBlank { null },
        fields = listOf(
            "标题" to title,
            "数量" to count,
            "分群" to segment,
        ),
        modifier = modifier,
    )
}