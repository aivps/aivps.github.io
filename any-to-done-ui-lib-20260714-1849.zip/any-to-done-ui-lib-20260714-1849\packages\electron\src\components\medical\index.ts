export { PatientCard } from './PatientCard';
export type { PatientCardProps } from './PatientCard';
export { MedicalRecordCard } from './MedicalRecordCard';
export type { MedicalRecordCardProps } from './MedicalRecordCard';