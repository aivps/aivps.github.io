import 'package:flutter/material.dart';

/// Design Tokens - Typography
/// Size scale + semantic aliases (h1/h2/h3/body) used by industry cards
class AppTypography {
  AppTypography._();

  static const String displayFont = 'system-ui';
  static const String bodyFont = 'system-ui';
  static const String monoFont = 'monospace';

  static const double xs = 12;
  static const double sm = 14;
  static const double base = 16;
  static const double lg = 18;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 30;
  static const double xxxxl = 36;
  static const double xxxxxl = 48;

  static const TextStyle displayLarge = TextStyle(
    fontSize: xxxxxl,
    fontWeight: FontWeight.w700,
    height: 1.2,
  );

  static const TextStyle displayMedium = TextStyle(
    fontSize: xxxxl,
    fontWeight: FontWeight.w700,
    height: 1.2,
  );

  static const TextStyle displaySmall = TextStyle(
    fontSize: xxxl,
    fontWeight: FontWeight.w600,
    height: 1.2,
  );

  static const TextStyle headingLarge = TextStyle(
    fontSize: xxl,
    fontWeight: FontWeight.w600,
    height: 1.3,
  );

  static const TextStyle headingMedium = TextStyle(
    fontSize: xl,
    fontWeight: FontWeight.w600,
    height: 1.3,
  );

  static const TextStyle headingSmall = TextStyle(
    fontSize: lg,
    fontWeight: FontWeight.w500,
    height: 1.4,
  );

  static const TextStyle bodyLarge = TextStyle(
    fontSize: lg,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontSize: base,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );

  static const TextStyle bodySmall = TextStyle(
    fontSize: sm,
    fontWeight: FontWeight.w400,
    height: 1.5,
  );

  static const TextStyle caption = TextStyle(
    fontSize: xs,
    fontWeight: FontWeight.w400,
    height: 1.5,
    color: Color(0xFF8D939D),
  );

  static const TextStyle code = TextStyle(
    fontSize: sm,
    fontWeight: FontWeight.w400,
    height: 1.5,
    fontFamily: 'monospace',
  );

  // Semantic aliases for industry cards
  static const TextStyle h1 = headingLarge;
  static const TextStyle h2 = headingMedium;
  static const TextStyle h3 = headingSmall;
  static const TextStyle body = bodyMedium;
}
