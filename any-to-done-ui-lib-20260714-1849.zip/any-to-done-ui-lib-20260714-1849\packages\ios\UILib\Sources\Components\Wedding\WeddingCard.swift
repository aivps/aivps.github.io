import SwiftUI

/// 婚礼 - field-deep aligned shell (SwiftUI)
public struct WeddingCard: View {
    public var id: String = ""
    public var couple: String = ""
    public var date: String = ""
    public var venue: String = ""
    public var guestCount: String = ""
    public var status: String = ""

    public init(id: String = "", couple: String = "", date: String = "", venue: String = "", guestCount: String = "", status: String = "") {
        self.id = id
        self.couple = couple
        self.date = date
        self.venue = venue
        self.guestCount = guestCount
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "婚礼",
            status: status.isEmpty ? nil : status,
            fields: [
                ("ID", id),
                ("新人", couple),
                ("日期", date),
                ("场地", venue),
                ("宾客数", guestCount),
            ]
        )
    }
}
