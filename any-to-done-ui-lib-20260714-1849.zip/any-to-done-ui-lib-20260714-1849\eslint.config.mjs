import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';
import jsxA11y from 'eslint-plugin-jsx-a11y';
import security from 'eslint-plugin-security';
import sonarjs from 'eslint-plugin-sonarjs';
import globals from 'globals';

function asWarn(rules = {}) {
  const out = {};
  for (const [k, v] of Object.entries(rules)) {
    if (v === 'off' || v === 0) {
      out[k] = v;
      continue;
    }
    if (Array.isArray(v)) {
      out[k] = ['warn', ...v.slice(1)];
    } else {
      out[k] = 'warn';
    }
  }
  return out;
}

const a11yRules = jsxA11y.flatConfigs?.recommended?.rules ?? {};
const securityRules = security.configs?.recommended?.rules ?? {};
const sonarRules = sonarjs.configs?.recommended?.rules ?? {};

/** Rules that fire heavily on design-system style maps / card shells. */
const designSystemNoise = {
  'sonarjs/no-nested-conditional': 'off',
  'sonarjs/no-nested-template-literals': 'off',
  'sonarjs/cognitive-complexity': 'off',
  'sonarjs/pseudo-random': 'off',
  'sonarjs/use-type-alias': 'off',
  'sonarjs/todo-tag': 'off',
  'sonarjs/no-commented-code': 'off',
  'sonarjs/no-unused-vars': 'off',
  'sonarjs/no-dead-store': 'off',
  'security/detect-object-injection': 'off',
  // Card shells use clickable surfaces; a11y enforced in atoms via native controls.
  'jsx-a11y/click-events-have-key-events': 'off',
  'jsx-a11y/no-static-element-interactions': 'off',
  'jsx-a11y/no-noninteractive-element-interactions': 'off',
  'jsx-a11y/no-noninteractive-tabindex': 'off',
  'jsx-a11y/control-has-associated-label': 'off',
  'jsx-a11y/media-has-caption': 'off',
  'jsx-a11y/no-redundant-roles': 'off',
  'jsx-a11y/interactive-supports-focus': 'off',
  'jsx-a11y/role-supports-aria-props': 'off',
  'jsx-a11y/role-has-required-aria-props': 'off',
  'jsx-a11y/no-autofocus': 'off',
};

export default tseslint.config(
  {
    ignores: [
      'dist/**',
      'node_modules/**',
      'packages/**/dist/**',
      '**/visual-out/**',
      '${APPDATA}/**',
      'coverage/**',
    ],
  },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    files: ['src/**/*.{ts,tsx}'],
    languageOptions: {
      ecmaVersion: 2020,
      globals: { ...globals.browser, ...globals.es2020 },
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    plugins: {
      'react-hooks': reactHooks,
      'react-refresh': reactRefresh,
      'jsx-a11y': jsxA11y,
      security,
      sonarjs,
    },
    rules: {
      ...reactHooks.configs.recommended.rules,
      ...asWarn(a11yRules),
      ...asWarn(securityRules),
      ...asWarn(sonarRules),
      ...designSystemNoise,
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-unused-vars': [
        'error',
        { argsIgnorePattern: '^_', varsIgnorePattern: '^_' },
      ],
      'no-empty': ['error', { allowEmptyCatch: true }],
      'prefer-const': 'error',
      'no-undef': 'off',
    },
  },
  // Atoms: keep a11y on for native controls; still allow theme ternaries.
  {
    files: ['src/atoms/**/*.{ts,tsx}'],
    rules: {
      'jsx-a11y/click-events-have-key-events': 'error',
      'jsx-a11y/no-static-element-interactions': 'error',
      'jsx-a11y/no-noninteractive-element-interactions': 'error',
      'jsx-a11y/control-has-associated-label': 'warn',
      'jsx-a11y/no-autofocus': 'warn',
    },
  },
);
