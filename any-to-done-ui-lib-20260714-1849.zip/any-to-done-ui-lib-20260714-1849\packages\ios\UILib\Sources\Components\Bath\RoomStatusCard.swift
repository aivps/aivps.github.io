import SwiftUI

/// 包厢 - bath industry (SwiftUI)
public struct RoomStatusCard: View {
    public var roomNo: String = ""
    public var type: String = ""
    public var capacity: String = ""
    public var status: String = ""

    public init(roomNo: String = "", type: String = "", capacity: String = "", status: String = "") {
        self.roomNo = roomNo
        self.type = type
        self.capacity = capacity
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "包厢",
            status: status.isEmpty ? nil : status,
            fields: [
            ("包厢号", roomNo),
            ("类型", type),
            ("容量", capacity),
            ]
        )
    }
}