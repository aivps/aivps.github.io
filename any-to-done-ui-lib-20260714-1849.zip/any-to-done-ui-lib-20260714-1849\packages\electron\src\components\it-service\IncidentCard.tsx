import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface IncidentCardProps {
  incidentId?: string | number;
  title?: string | number;
  level?: string | number;
  status?: string;
  assignee?: string | number;
  createdAt?: string | number;
  /** @deprecated use level */
  severity?: string | number;
  /** @deprecated use createdAt */
  startedAt?: string | number;
  impact?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 故障 - field-deep aligned shell */
export const IncidentCard: React.FC<IncidentCardProps> = ({
  incidentId,
  title,
  level,
  status,
  assignee,
  createdAt,
  severity,
  startedAt,
  impact,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="故障"
    status={status}
    fields={[
      { label: 'ID', value: incidentId },
      { label: '标题', value: title },
      { label: '等级', value: level ?? severity },
      { label: '处理人', value: assignee },
      { label: '开始时间', value: createdAt ?? startedAt },
      { label: '影响', value: impact },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default IncidentCard;
