Component({
  properties: {
    items: { type: Array, value: [] },
    active: { type: Number, value: 0 },
    type: { type: String, value: 'line' },
  },
  methods: {
    onTap(e) {
      const index = e.currentTarget.dataset.index;
      this.triggerEvent('change', { index });
    },
  },
});
