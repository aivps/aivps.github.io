import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface RoomStatusCardProps {
  id?: string;
  roomNumber?: string;
  roomType?: string;
  status?: string;
  guestName?: string;
  checkInTime?: string;
  amount?: string;
  onClick?: () => void;
}

/** RoomStatusCard - Electron shell (field keys aligned to React) */
export const RoomStatusCard: React.FC<RoomStatusCardProps> = (props) => (
  <IndustryCardShell title="RoomStatusCard" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.roomNumber ? <div className="row"><span className="label">roomNumber</span><span>{props.roomNumber}</span></div> : null}
      {props.roomType ? <div className="row"><span className="label">roomType</span><span>{props.roomType}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.guestName ? <div className="row"><span className="label">guestName</span><span>{props.guestName}</span></div> : null}
      {props.checkInTime ? <div className="row"><span className="label">checkInTime</span><span>{props.checkInTime}</span></div> : null}
      {props.amount ? <div className="row"><span className="label">amount</span><span>{props.amount}</span></div> : null}
  </IndustryCardShell>
);

export default RoomStatusCard;
