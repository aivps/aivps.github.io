import SwiftUI

/// 画像KPI - portrait industry (SwiftUI)
public struct PortraitKPI: View {
    public var label: String = ""
    public var value: String = ""
    public var delta: String = ""
    public var unit: String = ""

    public init(label: String = "", value: String = "", delta: String = "", unit: String = "") {
        self.label = label
        self.value = value
        self.delta = delta
        self.unit = unit
    }

    public var body: some View {
        IndustryCardShell(
            title: "画像KPI",
            status: nil,
            fields: [
            ("标签", label),
            ("数值", value),
            ("变化", delta),
            ("单位", unit),
            ]
        )
    }
}