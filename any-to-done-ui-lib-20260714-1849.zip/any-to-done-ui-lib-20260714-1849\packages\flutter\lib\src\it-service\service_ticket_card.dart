import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// ServiceTicketCard - IT service ticket shell (UTF-8 safe).
class ServiceTicketCard extends StatelessWidget {
  final String id;
  final String title;
  final String status;
  final String? requester;
  final String? priority;
  final VoidCallback? onTap;
  final bool disabled;

  const ServiceTicketCard({
    super.key,
    this.id = '',
    this.title = '',
    required this.status,
    this.requester,
    this.priority,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      title.isNotEmpty ? title : id,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: colors.foreground),
                    ),
                  ),
                  Text(status, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: colors.primary)),
                ],
              ),
              if (requester != null || priority != null) ...[
                const SizedBox(height: 8),
                Text(
                  [
                    if (requester != null && requester!.isNotEmpty) 'Requester: $requester',
                    if (priority != null && priority!.isNotEmpty) 'Priority: $priority',
                  ].join('  ·  '),
                  style: TextStyle(fontSize: 13, color: colors.muted),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
