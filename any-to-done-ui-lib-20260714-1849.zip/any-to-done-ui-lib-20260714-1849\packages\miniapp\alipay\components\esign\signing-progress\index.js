/** 签署进度 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'contractId': { type: String, value: '' },
    'contractTitle': { type: String, value: '' },
    'progress': { type: String, value: '' },
    'signed': { type: String, value: '' },
    'total': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
