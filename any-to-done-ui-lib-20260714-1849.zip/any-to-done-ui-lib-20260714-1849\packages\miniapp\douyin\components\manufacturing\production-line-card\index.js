/** 产线 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'lineId': { type: String, value: '' },
    'lineName': { type: String, value: '' },
    'product': { type: String, value: '' },
    'target': { type: String, value: '' },
    'actual': { type: String, value: '' },
    'status': { type: String, value: '' },
    'shift': { type: String, value: '' },
    'efficiency': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
