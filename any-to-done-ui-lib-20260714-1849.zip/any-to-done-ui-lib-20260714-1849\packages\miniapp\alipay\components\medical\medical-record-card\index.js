/** 病历 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'recordId': { type: String, value: '' },
    'patientName': { type: String, value: '' },
    'patientId': { type: String, value: '' },
    'recordType': { type: String, value: '' },
    'date': { type: String, value: '' },
    'department': { type: String, value: '' },
    'doctor': { type: String, value: '' },
    'diagnosis': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
