/** 服务单 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'ticketNumber': { type: String, value: '' },
    'title': { type: String, value: '' },
    'priority': { type: String, value: '' },
    'assignee': { type: String, value: '' },
    'status': { type: String, value: '' },
    'client': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
