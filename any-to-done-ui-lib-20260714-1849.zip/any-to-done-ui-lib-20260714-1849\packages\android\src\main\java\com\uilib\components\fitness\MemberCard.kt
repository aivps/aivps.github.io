package com.uilib.components.fitness

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 会员 - field-deep aligned shell (Compose) */
@Composable
fun MemberCard(
    id: String = "",
    name: String = "",
    phone: String = "",
    cardType: String = "",
    expireDate: String = "",
    remainingSessions: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "会员",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "名称" to name,
            "电话" to phone,
            "卡类型" to cardType,
            "到期日" to expireDate,
            "剩余次数" to remainingSessions,
        ),
        modifier = modifier,
    )
}
