import SwiftUI

/// 合同 - field-deep aligned shell (SwiftUI)
public struct ContractCard: View {
    public var id: String = ""
    public var contractNumber: String = ""
    public var title: String = ""
    public var parties: String = ""
    public var amount: String = ""
    public var status: String = ""
    public var createdAt: String = ""

    public init(id: String = "", contractNumber: String = "", title: String = "", parties: String = "", amount: String = "", status: String = "", createdAt: String = "") {
        self.id = id
        self.contractNumber = contractNumber
        self.title = title
        self.parties = parties
        self.amount = amount
        self.status = status
        self.createdAt = createdAt
    }

    public var body: some View {
        IndustryCardShell(
            title: "合同",
            status: status.isEmpty ? nil : status,
            fields: [
                ("ID", id),
                ("合同号", contractNumber),
                ("标题", title),
                ("签署方", parties),
                ("金额", amount),
                ("创建日期", createdAt),
            ]
        )
    }
}
