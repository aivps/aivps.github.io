﻿# any to done -> any to done design | Any to Done Design - UI lib handoff pack

1. Read OPENCLAW.md first
2. Run docs/OPENCLAW-UI-UNIFY-PROMPT.md section 8
3. Low-token route: docs/LLM.md; visual: demo.html / preview.html
4. Install: pnpm install (Node 18+)
5. QA: pnpm smoke / pnpm visual / pnpm interact / pnpm qa

Pack mode: FULL
Packed at: 2026-07-14 18:49:22
