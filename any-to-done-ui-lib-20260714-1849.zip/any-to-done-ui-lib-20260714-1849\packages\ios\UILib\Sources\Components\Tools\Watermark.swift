import SwiftUI

/// 水印 - tools industry (SwiftUI)
public struct Watermark: View {
    public var text: String = ""
    public var opacity: String = ""
    public var angle: String = ""

    public init(text: String = "", opacity: String = "", angle: String = "") {
        self.text = text
        self.opacity = opacity
        self.angle = angle
    }

    public var body: some View {
        IndustryCardShell(
            title: "水印",
            status: nil,
            fields: [
            ("文本", text),
            ("透明度", opacity),
            ("角度", angle),
            ]
        )
    }
}