# 企业级跨端 UI 组件库 — 开发交接文档

> **用途**：给人类与 AI 代理（Grok / Claude / 其他 LLM）续写本仓库时的单一交接入口。  
> **更新日期**：2026-07-13  
> **React 权威源**：根目录 `src/`（`packages/react` 仅 re-export）  
> **低 Token 路由**：优先读 `docs/LLM.md`，不要先吞规划全文。

---

## 一、项目一句话

统一 Design Token 的企业级跨端 UI 组件库：Web（React / Vue3 / WC）、移动（RN / Flutter）、小程序（微信 / 支付宝 / 抖音）、桌面（Electron）、原生（iOS SwiftUI / Android Compose）。

---

## 二、当前状态（2026-07-13）

### 2.1 平台 parity

| 平台 | 路径 | 状态 |
|------|------|------|
| React TSX | `src/` | ✅ 权威完整（28 行业域 + tokens + hooks + tools） |
| Vue3 | `packages/vue/src/` | ✅ 行业卡 phase6 扁平 + **ecommerce…hardware + monitor/bi/portrait/tools/advanced/global 高交互加深** |
| React Native | `packages/react-native/src/` | ✅ 每行业 ≥2；剩余行业已字段深对齐骨架 |
| Flutter | `packages/flutter/lib/src/` | ✅ 每行业 ≥2；剩余行业已字段深对齐骨架 |
| 微信小程序 | `packages/miniapp/weixin/` | ✅ 行业卡 shell + 字段 key 对齐 |
| 支付宝小程序 | `packages/miniapp/alipay/` | ✅ 自微信同步（axml/acss） |
| 抖音小程序 | `packages/miniapp/douyin/` | ✅ 自微信同步（ttml/ttss） |
| Web Components | `packages/wc/src/` | ✅ 行业卡 shell 字段对齐 |
| Electron | `packages/electron/` | ✅ 行业卡 shell |
| Android Compose | `packages/android/` | ✅ Phase 6 骨架 |
| iOS SwiftUI | `packages/ios/` | ✅ Phase 6 骨架 |
| 硬件规范 | `packages/hardware/` | 📄 文档交付 |

### 2.2 字段深对齐（契约）

- **单一真相源**：`docs/api-contract-industry-cards.md`
- **原子浅对齐**：`docs/api-contract-atoms.md`
- **phase6 字段表**：`scripts/phase6-industries.json`
- 已完成医疗 / 电商 / 财务 / 法务 / 教育 / 物流 / ERP / 制造 / 物业 / IT / 电签 / 健身 / 棋牌 / 婚庆 等批次手写深改。
- 剩余行业：hardware / video / advertising / children / k12 / monitor / workflow / bath / bi / portrait / tools（phase6 + RN/Flutter/壳/Vue 骨架）。
- **Vue 高交互**：
  - ecommerce：`ProductCard`（`product` 嵌套）、`CartItem`（`item`）、`SKUSelector`
  - workflow：`ApprovalFlow`（`nodes[]`）、`TicketStatus`（`ticket`）、`PermissionTree`（`data[]`）
  - medical：`PatientCard`（可选 `patient` 嵌套 + 叫号/完成）、`MedicalRecordCard`（附件下载）
  - finance：`InvoiceCard`（发送/标记已付）、`ExpenseReportCard`（提交/通过/驳回）
  - erp：`PurchaseOrderCard`（审批/收货/取消）、`SalesOrderCard`（发货/开票）
  - logistics：`TransportCard`（`transport` + routes）、`InventoryCard`（补货）
  - manufacturing：`ProductionLineCard`（启停/报工）、`ProductionPanel`（工位/告警）
  - legal：`CaseCard`（详情/更新进度）、`EvidenceCard`（上传/列表）
  - property：`PropertyCard`（`property` 嵌套 + 点击）、`RepairTicketCard`（派工/完成）
  - education：`CourseCard`（`course` 嵌套）、`ClassSchedule`（课表 + `@class-click`）
  - fitness：`MemberCard`（预约/续费）、`FitnessCourseCard`（团课报名）
  - it-service：`IncidentCard`（处理）、`ServiceTicketCard`（接单/解决）
  - esign：`ContractCard`（发送/签署）、`SigningProgress`（催签/进度）
  - gaming：`GameRoomCard`（加入/关闭）、`PlayerListCard`（点击/封禁）
  - wedding：`WeddingCard`（确认档期）、`GuestListCard`（RSVP 确认）
  - video：`VideoCard`（发布/删除）、`VideoPlayer`（播放/进度 mock）
  - advertising：`CampaignCard`（暂停/恢复）、`AdScheduleCard`（开始/暂停/删除）
  - bath：`RoomStatusCard`（开单/结算/清洁）、`ServiceMenuCard`（点选服务）
  - children：`ChildPatientCard`（叫号）、`StudentCard`（点击）
  - k12：`HomeworkCard`（提交/批改演示）、`StudentRecordCard`（学籍详情）
  - hardware：`ChargingStation`（启停充电）、`DeviceStatusCard`（详情/控制）
  - monitor：`ServerStatus`（`servers[]` + 点击）、`DeviceStatus`（指标条 + `@click`/`@control`）
  - bi：`KPIBoard`（`items[]` + `@item-click`）、`Gauge`（SVG 半环）
  - portrait：`PortraitKPI`（竖屏 KPI）、`PortraitList`（列表选中）
  - tools：`ClipboardField`（复制反馈）、`Watermark`（slot + SVG pattern）
  - advanced：`VirtualList`（虚拟滚动 + 行 slot / `@item-click`）、`SplitPane`（拖拽分栏 + `#left`/`#right`）
  - global：`ThemeProvider`（mode/palette + CSS 变量 / `useTheme`）、`BreakpointDetector`（设备断点 / `useBreakpoint`）、`EmptyState`、`GlobalLoading`、`ErrorBoundary`、`PortalContainer`（`usePortal`）
  - 均保留 phase6 扁平 props 作 legacy 输入；中文枚举可 normalize。
- **React 卫生**：`src/` 内误用 `react-native` 的文件已恢复 Web 权威实现。

### 2.3 可见演示（心理有底）

| 文件 | 说明 |
|------|------|
| **`demo.html`** | 行业卡演示；**医疗 / 电商 / 财务 / ERP / 物流 / 制造 / 法务 / 物业 / 教育 / 健身 / IT / 电签 / 棋牌 / 婚庆 / 视频 / 广告 / 硬件 / 洗浴 / 儿童 / K12 / 审批 / 运维 / BI / 竖屏 / 工具 / 高阶 / 全局可点击交互** |
| **`preview.html`** | 原子 / 复合组件交互预览 |
| **小程序冒烟宿主** | `packages/miniapp/weixin`（首页行业卡 + 目录页）、`alipay`、`douyin` — DevTools 直接导入 |

浏览器直接打开 `demo.html` / `preview.html`，无需 `npm install`。

### 2.4 冒烟基建（2026-07-13）

| 项 | 说明 |
|----|------|
| 命令 | `pnpm smoke` → `scripts/smoke-check.ps1` |
| 报告 | `scripts/smoke-report.latest.md` |
| 人工清单 | `docs/smoke-checklist.md`（微信/支付宝/抖音 DevTools + Android Studio + Xcode） |
| 自动记录 | `pnpm smoke` 写 `scripts/smoke-checklist.latest.md`（静态 PASS/FAIL；工具链探测写真实 PASS/FAIL 否则 SKIP；小程序静态 host + visual-host 代理记 PASS；附 visual/interact 报告 verdict） |
| 静态覆盖 | 三端小程序 host 文件 + phase6 **52** 叶子组件四文件齐全；Android/iOS/Flutter/RN 文件存在性；smoke 页 `usingComponents` 路径 |
| 本机实测 | **SMOKE PASSED (static)**；checklist 已写真实 PASS（静态 + 小程序 proxy + visual/interact 报告）；Android/iOS/Flutter 无工具链 → SKIP（预期）；真机 DevTools 仍须人工 |

### 2.5 截图验收流水线（2026-07-13）

| 项 | 说明 |
|----|------|
| 命令 | `pnpm visual` / `pnpm visual:update` → `scripts/visual-check.ps1` |
| 目标 | `scripts/visual-targets.json`（**60** 帧：demo 全可交互行业 light + 可交互行业 dark 含 **children/k12/tools** 收尾 + preview + 小程序三端 proxy） |
| 基线 | `visual-baselines/*.png` + `visual-baselines/manual/{weixin,alipay,douyin}_home.png`；实际图 `scripts/visual-out/actual/` |
| 报告 | `scripts/visual-report.latest.md` |
| 取景 | harness 注入 `window.__OD_VISUAL__`；手测可用 `?visual=` / `#visual=` |
| 小程序 | **代理壳** `packages/miniapp/visual-host.html`（390×844）自动截图入库 manual/；DevTools 真图可覆盖同路径 |
| 对比 | 整图 SHA256；`data-visual` 下关闭 animation/transition；支持 per-target `viewport` / `baselineSubdir` |
| 本机实测 | **VISUAL PASSED**（Targets=60，FAIL=0，WARN=0；dark 含 children/k12/tools 收尾） |
| 附带修复 | `demo.html` 顶层 `const` 重名导致整页 JS 无法解析（`invSt`/`stCfg`/…）已消歧 |

### 2.5b demo 交互冒烟（2026-07-13）

| 项 | 说明 |
|----|------|
| 命令 | `pnpm interact` → `scripts/interact-check.ps1` |
| 场景 | `scripts/interact-targets.json`（**38**：主路径 25 + 次要 5 + 第三链 5 + 再补 3：故障工位复位 / 产线停→启 / 儿童叫号→检查） |
| 机制 | Edge/Chrome headless `--dump-dom` + harness 注入点击 runner；断言 toast / DOM 文案 |
| 报告 | `scripts/interact-report.latest.md` |
| 串联 | `pnpm qa` → `scripts/qa.ps1`（smoke + visual + interact） |
| 本机实测 | **INTERACT PASSED**（Scenarios=38，FAIL=0） |
| 边界 | 只覆盖 `demo.html` 直播按钮，不是 Playwright 全站 E2E，也不是 Vue 单测 |

### 2.6 已知限制

- 本环境通常 **不能** 完成 Gradle / Xcode / 各小程序 DevTools 真机编译；静态 smoke 通过 ≠ 模拟器/真机已跑通。
- 截图验收依赖本机 **Edge/Chrome headless**；字体/DPI 跨机可能无业务改动也 FAIL。
- 小程序 **代理壳** 可无人值守截图；真实 DevTools/真机仍需人工（可覆盖 `manual/*_home.png`）。
- Shell 端是字段级对齐，不是 React 一对一完整移植。
- Flutter `VideoPlayer` 等为 UI 壳；部分行业卡为可运行骨架 + 契约 props。
- Vue：**ecommerce…hardware + monitor / bi / portrait / tools / advanced / global 为高交互加深**（phase6 主卡 + VirtualList/SplitPane + Theme/Breakpoint/Empty/Loading/Error/Portal 已齐）。
- phase6 命名别名：RN `FitnessCourseCard` / `ClipboardField`；Flutter `fitness_course_card.dart`（实现仍可在 `CourseCard` / `Clipboard` / `course_card.dart`）。

---

## 三、目录结构（浓缩）

```
src/                          # React 唯一权威实现
packages/react/               # re-export
packages/vue|react-native|flutter|wc|electron|android|ios/
packages/miniapp/weixin|alipay|douyin/
docs/LLM.md                   # LLM 最短路径
docs/api-contract-*.md        # 字段契约
scripts/phase6-industries.json
demo.html / preview.html
component-index.md
DEVELOPMENT-HANDOFF.md        # 本文件
```

---

## 四、Design Token

| 色系 | 主色 | 场景 |
|------|------|------|
| 蓝 | `#1677FF` | 默认 / 品牌 |
| 红 | `#F53F3F` | 危险 / 错误 |
| 绿 | `#00B42A` | 成功 / 在线 |
| 紫 | `#722ED1` | 权限 / 高级 |
| 青 | `#13C2C2` | 科技 / 工业 |
| 橙 | `#FA8C16` | 警告 / 营销 |

双主题：浅色 + 暗色。断点：手机 / 平板 / PC / 大屏。

---

## 五、建议后续（可选）

1. **人工真机**：按 `docs/smoke-checklist.md` 在已装工具链的机器上跑 DevTools / Android Studio / Xcode（`smoke-checklist.latest.md` 仍为静态 SKIP 项）。  
2. **小程序人工截图入库**：用 DevTools 真图覆盖 `visual-baselines/manual/{weixin,alipay,douyin}_home.png`（proxy 已有基线）。  
3. 改 demo 视觉后 `pnpm visual`；发版前 `pnpm qa`。  
4. 可选：dark 再抽剩余 light-only（children / k12 / tools）；interact 可再补故障单双击、产线停→启、儿童叫号链等。

---

## 六、给下一个 Agent 的开场白

```
先读 docs/LLM.md，再读 DEVELOPMENT-HANDOFF.md 第二节状态表。
改字段只碰 docs/api-contract-industry-cards.md + 对应平台文件。
权威实现永远是 src/。演示用 demo.html。
```
