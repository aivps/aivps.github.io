import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface PortraitKPIProps {
  label?: string;
  value?: string;
  delta?: string;
  unit?: string;
  status?: string;
  onClick?: () => void;
}

/** PortraitKPI - Electron shell (field keys aligned to React) */
export const PortraitKPI: React.FC<PortraitKPIProps> = (props) => (
  <IndustryCardShell title="PortraitKPI" status={props.status} onClick={props.onClick}>
      {props.label ? <div className="row"><span className="label">label</span><span>{props.label}</span></div> : null}
      {props.value ? <div className="row"><span className="label">value</span><span>{props.value}</span></div> : null}
      {props.delta ? <div className="row"><span className="label">delta</span><span>{props.delta}</span></div> : null}
      {props.unit ? <div className="row"><span className="label">unit</span><span>{props.unit}</span></div> : null}
  </IndustryCardShell>
);

export default PortraitKPI;