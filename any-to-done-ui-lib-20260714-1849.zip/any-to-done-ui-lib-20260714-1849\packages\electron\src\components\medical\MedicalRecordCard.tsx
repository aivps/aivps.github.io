import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface MedicalRecordCardProps {
  recordId?: string | number;
  patientName?: string | number;
  patientId?: string | number;
  recordType?: string | number;
  date?: string | number;
  department?: string | number;
  doctor?: string | number;
  diagnosis?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 病历 - medical/ecommerce (Electron, field-deep aligned) */
export const MedicalRecordCard: React.FC<MedicalRecordCardProps> = ({
  recordId,
  patientName,
  patientId,
  recordType,
  date,
  department,
  doctor,
  diagnosis,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="病历"
    status={status}
    fields={[
    { label: '记录ID', value: recordId },
    { label: '患者', value: patientName },
    { label: '患者ID', value: patientId },
    { label: '类型', value: recordType },
    { label: '日期', value: date },
    { label: '科室', value: department },
    { label: '医生', value: doctor },
    { label: '诊断', value: diagnosis },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default MedicalRecordCard;
