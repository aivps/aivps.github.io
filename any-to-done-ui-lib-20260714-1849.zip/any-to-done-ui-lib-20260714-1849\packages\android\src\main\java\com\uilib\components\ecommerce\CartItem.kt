package com.uilib.components.ecommerce

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 购物车项 - industry (Compose, field-deep aligned) */
@Composable
fun CartItem(
    id: String = "",
    name: String = "",
    price: String = "",
    quantity: String = "",
    sku: String = "",
    selected: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "购物车项",
        status = null,
        fields = listOf(
            "ID" to id,
            "名称" to name,
            "价格" to price,
            "数量" to quantity,
            "SKU" to sku,
            "已选" to selected,
        ),
        modifier = modifier,
    )
}
