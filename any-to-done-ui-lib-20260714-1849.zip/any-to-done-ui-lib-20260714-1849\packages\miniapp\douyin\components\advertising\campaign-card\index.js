/** CampaignCard - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'platform': { type: String, value: '' },
    'budget': { type: String, value: '' },
    'spent': { type: String, value: '' },
    'impressions': { type: String, value: '' },
    'clicks': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});