export { KPIBoard } from './KPIBoard';
export type { KPIBoardProps } from './KPIBoard';
export { Gauge } from './Gauge';
export type { GaugeProps } from './Gauge';