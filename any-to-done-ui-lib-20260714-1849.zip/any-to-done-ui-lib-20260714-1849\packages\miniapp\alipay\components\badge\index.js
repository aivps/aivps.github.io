/**
 * Badge — shallow API aligned to React atoms.
 * Canonical: color + size + count + overflowCount + text + dot + standalone.
 * Legacy: status → color; max → overflowCount.
 */
Component({
  options: {
    addGlobalClass: true,
    multipleSlots: true,
  },

  properties: {
    color: {
      type: String,
      value: '',
    },
    size: {
      type: String,
      value: 'md',
    },
    count: {
      type: Number,
      value: -1,
    },
    text: {
      type: String,
      value: '',
    },
    dot: {
      type: Boolean,
      value: false,
    },
    /** @deprecated use color */
    status: {
      type: String,
      value: '',
    },
    overflowCount: {
      type: Number,
      value: 99,
    },
    /** @deprecated use overflowCount */
    max: {
      type: Number,
      value: -1,
    },
    showZero: {
      type: Boolean,
      value: false,
    },
    standalone: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    resolvedColor: 'danger',
    displayText: '',
    shouldShow: false,
  },

  observers: {
    'color, status, count, text, dot, overflowCount, max, showZero': function () {
      this._sync();
    },
  },

  lifetimes: {
    attached() {
      this._sync();
    },
  },

  methods: {
    _statusToColor(status) {
      switch (status) {
        case 'processing':
          return 'primary';
        case 'error':
          return 'danger';
        case 'success':
          return 'success';
        case 'warning':
          return 'warning';
        default:
          return 'default';
      }
    },

    _sync() {
      const {
        color,
        status,
        count,
        text,
        dot,
        overflowCount,
        max,
        showZero,
      } = this.properties;

      const resolvedColor = color || (status ? this._statusToColor(status) : 'danger');
      const cap = overflowCount > 0 ? overflowCount : max > 0 ? max : 99;

      let displayText = '';
      if (text) {
        displayText = text;
      } else if (count >= 0) {
        displayText = count > cap ? `${cap}+` : String(count);
      }

      const shouldShow =
        dot ||
        Boolean(text) ||
        (count >= 0 && (count > 0 || showZero));

      this.setData({ resolvedColor, displayText, shouldShow });
    },
  },
});
