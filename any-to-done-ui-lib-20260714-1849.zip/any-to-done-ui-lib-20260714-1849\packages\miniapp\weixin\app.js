// UI Lib WeChat mini program entry (smoke / component host)
App({
  globalData: {
    version: '1.0.0',
    lastTap: null,
  },
  onLaunch() {
    // no-op: components are pure UI shells
  },
});
