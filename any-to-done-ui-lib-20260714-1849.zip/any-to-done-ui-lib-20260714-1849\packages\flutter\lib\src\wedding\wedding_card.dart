import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// CoupleInfo — aligned to React couple object
class CoupleInfo {
  final String groom;
  final String bride;

  const CoupleInfo({required this.groom, required this.bride});

  String get display =>
      [groom, bride].where((s) => s.isNotEmpty).join(' & ');
}

/// WeddingCard — field-deep aligned to React WeddingCard.
/// status: booked | confirmed | completed | cancelled
class WeddingCard extends StatelessWidget {
  final String id;
  final CoupleInfo? couple;
  final String date;
  final String? time;
  final String venue;
  final String status;
  final String? packageName;
  final int? guestCount;
  final int? confirmedCount;
  final double? budget;
  final double? paidAmount;
  final String? phone;
  final VoidCallback? onTap;
  final ValueChanged<String>? onDetail;
  final ValueChanged<String>? onEdit;
  final ValueChanged<String>? onConfirm;
  final bool disabled;

  /// @deprecated aliases
  final String? coupleName;
  final String? style;
  final String? package;

  const WeddingCard({
    super.key,
    this.id = '',
    this.couple,
    required this.date,
    this.time,
    required this.venue,
    required this.status,
    this.packageName,
    this.guestCount,
    this.confirmedCount,
    this.budget,
    this.paidAmount,
    this.phone,
    this.onTap,
    this.onDetail,
    this.onEdit,
    this.onConfirm,
    this.disabled = false,
    this.coupleName,
    this.style,
    this.package,
  });

  CoupleInfo get _couple {
    if (couple != null) return couple!;
    final name = coupleName ?? '';
    final parts = name.split(RegExp(r'[&＆和]')).map((s) => s.trim()).toList();
    return CoupleInfo(
      groom: parts.isNotEmpty ? parts[0] : name,
      bride: parts.length > 1 ? parts[1] : '',
    );
  }

  String? get _package => packageName ?? package ?? style;

  static const _statusLabels = {
    'booked': '已预约',
    'confirmed': '已确认',
    'completed': '已完成',
    'cancelled': '已取消',
    '已预订': '已预约',
    '已预约': '已预约',
    '进行中': '已确认',
    '已确认': '已确认',
    '已完成': '已完成',
    '已取消': '已取消',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'booked':
      case '已预订':
      case '已预约':
        return colors.warning;
      case 'confirmed':
      case '进行中':
      case '已确认':
        return colors.primary;
      case 'completed':
      case '已完成':
        return colors.success;
      case 'cancelled':
      case '已取消':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  bool get _isBooked =>
      status == 'booked' || status == '已预订' || status == '已预约';

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);
    final c = _couple;
    final pkg = _package;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onDetail?.call(id);
              },
        child: Container(
          padding: AppSpacing.xl,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusXl,
            boxShadow: AppShadows.md,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(c.display, style: AppTypography.h2),
                        Text(venue, style: AppTypography.body),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusLg,
                    ),
                    child: Text(_statusLabel,
                        style: AppTypography.body.copyWith(color: sc)),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: AppSpacing.md,
                decoration: BoxDecoration(
                  color: colors.bgPage,
                  borderRadius: AppSpacing.borderRadiusMd,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(date, style: AppTypography.h3),
                          if (time != null && time!.isNotEmpty)
                            Text(time!, style: AppTypography.body),
                        ],
                      ),
                    ),
                    if (pkg != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: colors.danger.withValues(alpha: 0.1),
                          borderRadius: AppSpacing.borderRadiusSm,
                        ),
                        child: Text(pkg,
                            style: AppTypography.body
                                .copyWith(color: colors.danger)),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  if (guestCount != null)
                    _buildStat(
                      '宾客人数',
                      confirmedCount != null
                          ? '$confirmedCount/$guestCount'
                          : guestCount.toString(),
                    ),
                  if (budget != null)
                    _buildStat(
                      '预算金额',
                      '¥${(budget! / 10000).toStringAsFixed(1)}万',
                    ),
                ],
              ),
              if (onEdit != null || (onConfirm != null && _isBooked)) ...[
                const SizedBox(height: 12),
                Row(
                  children: [
                    if (onEdit != null)
                      Expanded(
                        child: OutlinedButton(
                          onPressed: disabled ? null : () => onEdit!(id),
                          child: const Text('编辑'),
                        ),
                      ),
                    if (onConfirm != null && _isBooked)
                      Expanded(
                        child: ElevatedButton(
                          onPressed: disabled ? null : () => onConfirm!(id),
                          child: const Text('确认'),
                        ),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStat(String label, String value) {
    return Column(
      children: [
        Text(value, style: AppTypography.h3),
        Text(label, style: AppTypography.caption),
      ],
    );
  }
}
