import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

class TransportRoute {
  final String id;
  final String name;
  final String status;
  final String origin;
  final String destination;
  final String? eta;

  const TransportRoute({
    required this.id,
    required this.name,
    required this.status,
    required this.origin,
    required this.destination,
    this.eta,
  });
}

/// TransportCard — field-deep aligned to React TransportCard.
class TransportCard extends StatelessWidget {
  final String routeName;
  final String carrier;
  final String status; // pending | in_transit | delivered | exception
  final List<TransportRoute> routes;
  final String? vehicleNo;
  final VoidCallback? onTap;
  final ValueChanged<TransportRoute>? onRoutePress;
  final bool disabled;

  /// @deprecated waybill legacy
  final String? waybill;
  final String? from;
  final String? to;
  final String? eta;

  const TransportCard({
    super.key,
    this.routeName = '',
    this.carrier = '',
    required this.status,
    this.routes = const [],
    this.vehicleNo,
    this.onTap,
    this.onRoutePress,
    this.disabled = false,
    this.waybill,
    this.from,
    this.to,
    this.eta,
  });

  String get _routeName =>
      routeName.isNotEmpty ? routeName : (waybill ?? '');

  static const _statusLabels = {
    'pending': '待发车',
    'loading': '装货中',
    'in_transit': '运输中',
    'delivered': '已送达',
    'exception': '异常',
    '待发运': '待发车',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'pending':
      case '待发运':
        return colors.warning;
      case 'loading':
      case 'in_transit':
        return colors.primary;
      case 'delivered':
        return colors.success;
      case 'exception':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);
    final origin = from ?? (routes.isNotEmpty ? routes.first.origin : null);
    final dest = to ?? (routes.isNotEmpty ? routes.first.destination : null);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _routeName,
                          style: AppTypography.body
                              .copyWith(fontWeight: FontWeight.w600),
                        ),
                        if (carrier.isNotEmpty)
                          Text(carrier, style: AppTypography.caption),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style: AppTypography.caption.copyWith(color: sc),
                    ),
                  ),
                ],
              ),
              if (origin != null && dest != null) ...[
                const SizedBox(height: 8),
                Text(
                  '$origin → $dest',
                  style: AppTypography.caption
                      .copyWith(color: colors.textSecondary),
                ),
              ],
              if (vehicleNo != null || eta != null) ...[
                const SizedBox(height: 4),
                Text(
                  [
                    if (vehicleNo != null) '车号 $vehicleNo',
                    if (eta != null) 'ETA $eta',
                  ].join(' · '),
                  style: AppTypography.caption,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
