/**
 * KPI card - bi industry (Douyin Mini Program)
 */
Component({
  options: { addGlobalClass: true },
  properties: {
    'label': { type: String, value: '' },
    'value': { type: String, value: '' },
    'unit': { type: String, value: '' },
    'trend': { type: String, value: '' },
    'target': { type: String, value: '' },
  },
  methods: {
    onTap() {
      this.triggerEvent('tap', { ...this.data });
    },
  },
});