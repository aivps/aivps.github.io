import 'package:flutter/material.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';

/// 分割线方向
enum DividerOrientation {
  horizontal,
  vertical,
}

/// AppDivider 分割线组件
class AppDivider extends StatelessWidget {
  final DividerOrientation orientation;
  final bool dashed;
  final String? text;
  final CrossAxisAlignment textPosition;

  const AppDivider({
    super.key,
    this.orientation = DividerOrientation.horizontal,
    this.dashed = false,
    this.text,
    this.textPosition = CrossAxisAlignment.center,
  });

  @override
  Widget build(BuildContext context) {
    if (orientation == DividerOrientation.vertical) {
      return VerticalDivider(
        width: 1,
        thickness: 1,
        color: AppColors.gray200,
      );
    }

    if (text != null) {
      return Row(
        children: [
          Expanded(
            child: Container(
              height: 1,
              color: AppColors.gray200,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.mdValue),
            child: Text(
              text!,
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.gray500,
              ),
            ),
          ),
          Expanded(
            child: Container(
              height: 1,
              color: AppColors.gray200,
            ),
          ),
        ],
      );
    }

    return Container(
      height: 1,
      color: AppColors.gray200,
    );
  }
}
