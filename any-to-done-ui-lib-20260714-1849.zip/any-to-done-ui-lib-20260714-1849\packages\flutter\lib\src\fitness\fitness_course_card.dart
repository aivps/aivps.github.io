/// Phase6 filename alias — class FitnessCourseCard is defined in course_card.dart.
export 'course_card.dart';
