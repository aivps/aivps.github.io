# 组件库索引 (Token优化版)

大模型引用时：**先读 `docs/LLM.md`**，再用本文件定位组件。不要读取完整规划文档。

字段契约：`docs/api-contract-industry-cards.md` · 演示：`demo.html` · 冒烟：`pnpm smoke` / `docs/smoke-checklist.md` · 交接：`DEVELOPMENT-HANDOFF.md`

## 组件库总览

**28 行业域** | 6 色系 | 5 套断点 | 浅色/暗黑双主题 | React 权威 `src/`

## 多平台导出状态（2026-07-13 实测文件数）

| 平台 | 路径 | 约计 | 状态 |
|------|------|------|------|
| React TSX | `src/` | ~142 `.tsx` | 权威完整 |
| Vue3 | `packages/vue/src/` | ~110+ | 扁平 props；ecommerce…hardware + monitor/bi/portrait/tools/advanced/global 高交互加深 |
| React Native | `packages/react-native/src/` | ~74 `.tsx` | 每行业 ≥2 + 字段对齐 |
| Flutter | `packages/flutter/lib/` | ~111 `.dart` | 每行业 ≥2 + 字段对齐 |
| 微信小程序 | `packages/miniapp/weixin/` | ~71 组件 js | shell + **可导入冒烟页** |
| 支付宝小程序 | `packages/miniapp/alipay/` | 同步微信 | shell + 冒烟页 |
| 抖音小程序 | `packages/miniapp/douyin/` | 同步微信 | shell + 冒烟页 |
| Web Components | `packages/wc/src/` | ~72 `.ts` | shell 字段对齐 |
| Electron / Android / iOS | `packages/{electron,android,ios}/` | Phase 6 | shell 骨架 |

## 快速查找表

| ID | 组件名 | 分类 | 路径 | 说明 |
|----|--------|------|------|------|
| G01 | ThemeProvider | 全局基建 | global/ThemeProvider.tsx · Vue `ThemeProvider.vue` | 主题切换容器 |
| G02 | BreakpointDetector | 全局基建 | global/BreakpointDetector.tsx · Vue `.vue` | 响应式断点检测 |
| G03 | EmptyState | 全局基建 | global/EmptyState.tsx · Vue `.vue` | 空状态组件 |
| G04 | GlobalLoading | 全局基建 | global/GlobalLoading.tsx · Vue `.vue` | 全局加载 |
| G05 | ErrorBoundary | 全局基建 | global/ErrorBoundary.tsx · Vue `.vue` | 错误边界 |
| G06 | PortalContainer | 全局基建 | global/PortalContainer.tsx · Vue `.vue` | 弹窗挂载节点 |
| A01 | Button | 原子基础 | atoms/Button.tsx | 按钮组件 |
| A02 | Input | 原子基础 | atoms/Input.tsx | 输入框 |
| A03 | Select | 原子基础 | atoms/Select.tsx | 下拉选择器 |
| A04 | Radio | 原子基础 | atoms/Radio.tsx | 单选框 |
| A05 | Checkbox | 原子基础 | atoms/Checkbox.tsx | 复选框 |
| A06 | Switch | 原子基础 | atoms/Switch.tsx | 开关 |
| A07 | Slider | 原子基础 | atoms/Slider.tsx | 滑块 |
| A08 | Tag | 原子基础 | atoms/Tag.tsx | 标签 |
| A09 | Avatar | 原子基础 | atoms/Avatar.tsx | 头像 |
| A10 | Badge | 原子基础 | atoms/Badge.tsx | 徽章 |
| A11 | Progress | 原子基础 | atoms/Progress.tsx | 进度条 |
| A12 | Divider | 原子基础 | atoms/Divider.tsx | 分割线 |
| A13 | Tooltip | 原子基础 | atoms/Tooltip.tsx | 提示 |
| C01 | Card | 复合业务 | composite/Card.tsx | 卡片容器 |
| C02 | Tabs | 复合业务 | composite/Tabs.tsx | 标签页 |
| C03 | Modal | 复合业务 | composite/Modal.tsx | 弹窗 |
| C04 | Drawer | 复合业务 | composite/Drawer.tsx | 抽屉 |
| C05 | Toast | 复合业务 | composite/Toast.tsx | 通知提示 |
| C06 | Pagination | 复合业务 | composite/Pagination.tsx | 分页器 |
| C07 | Table | 复合业务 | composite/Table.tsx | 数据表格 |
| C08 | Tree | 复合业务 | composite/Tree.tsx | 树形控件 |
| C09 | Upload | 复合业务 | composite/Upload.tsx | 文件上传 |
| B01 | LineChart | BI可视化 | bi/LineChart.tsx | 折线图 |
| B02 | BarChart | BI可视化 | bi/BarChart.tsx | 柱状图 |
| B03 | PieChart | BI可视化 | bi/PieChart.tsx | 饼图 |
| B04 | RadarChart | BI可视化 | bi/RadarChart.tsx | 雷达图 |
| B05 | HeatMap | BI可视化 | bi/HeatMap.tsx | 热力图 |
| B06 | Gauge | BI可视化 | bi/Gauge.tsx | 仪表盘 |
| B07 | KPIBoard | BI可视化 | bi/KPIBoard.tsx | 指标看板 |
| W01 | ApprovalFlow | 流程审批 | workflow/ApprovalFlow.tsx | 审批流程图 |
| W02 | PermissionTree | 流程审批 | workflow/PermissionTree.tsx | 权限树 |
| W03 | TicketStatus | 流程审批 | workflow/TicketStatus.tsx | 工单状态 |
| E01 | ProductCard | C端商城 | ecommerce/ProductCard.tsx | 商品卡片 |
| E02 | SKUSelector | C端商城 | ecommerce/SKUSelector.tsx | SKU选择器 |
| E03 | CartItem | C端商城 | ecommerce/CartItem.tsx | 购物车条目 |
| E04 | Coupon | C端商城 | ecommerce/Coupon.tsx | 优惠券 |
| E05 | Carousel | C端商城 | ecommerce/Carousel.tsx | 轮播图 |
| E06 | Waterfall | C端商城 | ecommerce/Waterfall.tsx | 瀑布流 |
| E07 | Countdown | C端商城 | ecommerce/Countdown.tsx | 倒计时 |
| E08 | Rating | C端商城 | ecommerce/Rating.tsx | 评分 |
| M01 | ServerStatus | 运维监控 | monitor/ServerStatus.tsx | 服务器状态 |
| M02 | DeviceIndicator | 运维监控 | monitor/DeviceIndicator.tsx | 设备指示灯 |
| M03 | DeviceStatus | 运维监控 | monitor/DeviceStatus.tsx | 设备状态卡片 |
| H01 | VirtualList | 高阶交互 | advanced/VirtualList.tsx | 虚拟滚动列表 |
| H02 | SplitPane | 高阶交互 | advanced/SplitPane.tsx | 可拉伸分栏 |
| P01 | PortraitNav | PC竖屏 | portrait/PortraitNav.tsx | 竖屏导航 |
| P02 | PortraitList | PC竖屏 | portrait/PortraitList.tsx | 竖屏列表 |
| P03 | PortraitForm | PC竖屏 | portrait/PortraitForm.tsx | 竖屏表单 |
| P04 | PortraitKPI | PC竖屏 | portrait/PortraitKPI.tsx | 竖屏指标看板 |
| T01 | Watermark | 通用工具 | tools/Watermark.tsx | 水印容器 |
| T02 | Clipboard | 通用工具 | tools/Clipboard.tsx | 剪贴板复制 |
| T03 | ImageCrop | 通用工具 | tools/ImageCrop.tsx | 图片裁剪 |
| L01 | InventoryCard | 仓储物流 | logistics/InventoryCard.tsx | 库存卡片 |
| D01 | PatientCard | 医疗门诊 | medical/PatientCard.tsx | 患者信息卡片 |
| K01 | ClassSchedule | 校园教育 | k12/ClassSchedule.tsx | 课程表 |
| R01 | PropertyCard | 物业园区 | property/PropertyCard.tsx | 房产卡片 |
| F01 | InvoicePreview | 财务财税 | finance/InvoicePreview.tsx | 发票预览 |

## 分组索引

| 分组ID | 分组名 | 路径 | 组件数 |
|--------|--------|------|--------|
| 00 | 全局基建 | global/ | 6 |
| 01 | 原子基础 | atoms/ | 13 |
| 02 | 复合业务 | composite/ | 9 |
| 03 | BI可视化 | bi/ | 7 |
| 04 | 流程审批 | workflow/ | 3 |
| 05 | C端商城 | ecommerce/ | 8 |
| 06 | 运维监控 | monitor/ | 3 |
| 07 | 高阶交互 | advanced/ | 2 |
| 08 | PC竖屏 | portrait/ | 4 |
| 09 | 通用工具 | tools/ | 3 |
| 10 | 仓储物流 | logistics/ | 1 |
| 11 | 医疗门诊 | medical/ | 1 |
| 12 | 校园教育 | k12/ | 1 |
| 13 | 物业园区 | property/ | 1 |
| 20 | 财务财税 | finance/ | 1 |

## 设计Token速查

### 六色系
- 主色: `#1677FF` (蓝色)
- 危险: `#F53F3F` (红色)
- 成功: `#00B42A` (绿色)
- 特权: `#722ED1` (紫色)
- 科技: `#13C2C2` (青色)
- 警告: `#FA8C16` (橙色)

### 响应式断点
- 手机: 320-767px
- 平板: 768-1279px
- 横屏PC: 1280-1919px
- 竖屏PC: ≤1080px宽
- 大屏: ≥1920px

### 间距
- 4px, 8px, 12px, 16px, 24px, 32px

### 圆角
- 4px, 8px, 12px, 16px, 24px

### 字号
- 12px, 14px, 16px, 18px, 20px, 24px

## 交互状态

所有组件必须支持以下交互状态：
- 默认 (default)
- 悬停 (hover)
- 按下 (active)
- 聚焦 (focus)
- 禁用 (disabled)
- 加载中 (loading)
- 错误 (error)
- 只读 (readonly)

## 设备适配

- 键鼠设备: hover交互
- 触屏设备: 聚焦高亮 (≥44px触控区域)
- TV设备: 遥控器方向键导航
- 工控设备: 大按键、高对比度
