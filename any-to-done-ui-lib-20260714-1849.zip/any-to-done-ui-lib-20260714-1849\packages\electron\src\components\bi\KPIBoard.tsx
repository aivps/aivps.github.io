import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface KPIBoardProps {
  title?: string;
  value?: string;
  unit?: string;
  trend?: string;
  trendValue?: string;
  status?: string;
  onClick?: () => void;
}

/** KPIBoard - Electron shell (field keys aligned to React) */
export const KPIBoard: React.FC<KPIBoardProps> = (props) => (
  <IndustryCardShell title="KPIBoard" status={props.status} onClick={props.onClick}>
      {props.title ? <div className="row"><span className="label">title</span><span>{props.title}</span></div> : null}
      {props.value ? <div className="row"><span className="label">value</span><span>{props.value}</span></div> : null}
      {props.unit ? <div className="row"><span className="label">unit</span><span>{props.unit}</span></div> : null}
      {props.trend ? <div className="row"><span className="label">trend</span><span>{props.trend}</span></div> : null}
      {props.trendValue ? <div className="row"><span className="label">trendValue</span><span>{props.trendValue}</span></div> : null}
  </IndustryCardShell>
);

export default KPIBoard;