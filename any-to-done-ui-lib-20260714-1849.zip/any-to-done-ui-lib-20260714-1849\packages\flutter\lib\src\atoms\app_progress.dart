import 'package:flutter/material.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';

/// 进度条状态
enum ProgressStatus {
  active,
  success,
  exception,
  normal,
}

/// 进度条尺寸
enum ProgressSize {
  sm,
  md,
  lg,
}

/// AppProgress 进度条组件
class AppProgress extends StatelessWidget {
  final double percent;
  final ProgressStatus status;
  final ProgressSize size;
  final bool showInfo;
  final double? strokeWidth;
  final Color? strokeColor;
  final Color? trailColor;
  final String Function(double)? format;

  const AppProgress({
    super.key,
    this.percent = 0,
    this.status = ProgressStatus.active,
    this.size = ProgressSize.md,
    this.showInfo = true,
    this.strokeWidth,
    this.strokeColor,
    this.trailColor,
    this.format,
  });

  @override
  Widget build(BuildContext context) {
    final clampedPercent = percent.clamp(0.0, 100.0);
    final height = _getHeight();
    final color = _getColor();
    final displayText = format != null ? format!(clampedPercent) : '${clampedPercent.round()}%';

    return Row(
      children: [
        Expanded(
          child: Container(
            height: height,
            decoration: BoxDecoration(
              color: trailColor ?? AppColors.gray200,
              borderRadius: BorderRadius.circular(height / 2),
            ),
            child: Stack(
              children: [
                Positioned(
                  left: 0,
                  top: 0,
                  bottom: 0,
                  width: (clampedPercent / 100) * 100,
                  child: Container(
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(height / 2),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        if (showInfo) ...[
          const SizedBox(width: AppSpacing.mdValue),
          Text(
            displayText,
            style: TextStyle(
              fontSize: size == ProgressSize.sm ? 12 : size == ProgressSize.lg ? 16 : 14,
              color: AppColors.gray700,
            ),
          ),
        ],
      ],
    );
  }

  double _getHeight() {
    if (strokeWidth != null) return strokeWidth!;
    switch (size) {
      case ProgressSize.sm:
        return 4;
      case ProgressSize.md:
        return 8;
      case ProgressSize.lg:
        return 12;
    }
  }

  Color _getColor() {
    if (strokeColor != null) return strokeColor!;
    switch (status) {
      case ProgressStatus.success:
        return AppColors.success;
      case ProgressStatus.exception:
        return AppColors.danger;
      case ProgressStatus.active:
        return AppColors.primary;
      default:
        return AppColors.blue300;
    }
  }
}

/// AppCircleProgress 圆形进度
class AppCircleProgress extends StatelessWidget {
  final double percent;
  final double size;
  final double strokeWidth;
  final ProgressStatus status;
  final Color? strokeColor;
  final String Function(double)? format;
  final Widget? child;

  const AppCircleProgress({
    super.key,
    this.percent = 0,
    this.size = 120,
    this.strokeWidth = 8,
    this.status = ProgressStatus.active,
    this.strokeColor,
    this.format,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    final clampedPercent = percent.clamp(0.0, 100.0);
    final color = _getColor();
    final displayText = format != null ? format!(clampedPercent) : '${clampedPercent.round()}%';

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        fit: StackFit.expand,
        children: [
          CircularProgressIndicator(
            value: clampedPercent / 100,
            strokeWidth: strokeWidth,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            backgroundColor: AppColors.gray200,
          ),
          Center(
            child: child ??
                Text(
                  displayText,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w600,
                    color: color,
                  ),
                ),
          ),
        ],
      ),
    );
  }

  Color _getColor() {
    if (strokeColor != null) return strokeColor!;
    switch (status) {
      case ProgressStatus.success:
        return AppColors.success;
      case ProgressStatus.exception:
        return AppColors.danger;
      default:
        return AppColors.primary;
    }
  }
}
