# OpenClaw 入口

- **主任务提示词（复制即用）**：[`docs/OPENCLAW-UI-UNIFY-PROMPT.md`](./docs/OPENCLAW-UI-UNIFY-PROMPT.md) — 重点看 **第 8 节**
- **打包排除清单 / 一键 zip**：[`docs/PACK-FOR-OPENCLAW.md`](./docs/PACK-FOR-OPENCLAW.md) · `pnpm pack:openclaw`
- **组件库低 Token 路由**：[`docs/LLM.md`](./docs/LLM.md)
- **视觉基准（先打开）**：[`demo.html`](./demo.html) · [`preview.html`](./preview.html)
- **品牌线**：any to done → any to done设计

把本仓库 zip + 目标程序源码一起交给 agent，粘贴第 8 节提示词即可无人值守换 UI 并交付。

## 打包（给 OpenClaw 之前）

```powershell
pnpm pack:openclaw
# 产物：dist-handoff/any-to-done-ui-lib-YYYYMMDD-HHmm.zip
# 精简体积：pnpm pack:openclaw:slim
```

默认 **排除** `node_modules`、`.git`、`.opencode`、构建产物、密钥与视觉 actuals；**保留** `src/`、`packages/`、`docs/`、demo、QA 脚本与 `visual-baselines/`。细节见 [`docs/PACK-FOR-OPENCLAW.md`](./docs/PACK-FOR-OPENCLAW.md)。
