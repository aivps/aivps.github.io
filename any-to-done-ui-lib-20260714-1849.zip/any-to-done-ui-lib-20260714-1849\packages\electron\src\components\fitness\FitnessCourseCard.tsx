import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface FitnessCourseCardProps {
  name?: string | number;
  coach?: string | number;
  time?: string | number;
  duration?: string | number;
  capacity?: string | number;
  enrolled?: string | number;
  status?: string;
  /** @deprecated use name */
  title?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 健身课 - field-deep aligned shell */
export const FitnessCourseCard: React.FC<FitnessCourseCardProps> = ({
  name,
  coach,
  time,
  duration,
  capacity,
  enrolled,
  status,
  title,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="健身课"
    status={status}
    fields={[
      { label: '名称', value: name ?? title },
      { label: '教练', value: coach },
      { label: '时间', value: time },
      { label: '时长', value: duration },
      { label: '容量', value: capacity },
      { label: '已报', value: enrolled },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default FitnessCourseCard;
