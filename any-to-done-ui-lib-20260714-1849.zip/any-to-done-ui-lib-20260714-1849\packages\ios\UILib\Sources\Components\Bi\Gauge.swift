import SwiftUI

/// 仪表盘 - bi industry (SwiftUI)
public struct Gauge: View {
    public var label: String = ""
    public var value: String = ""
    public var min: String = ""
    public var max: String = ""
    public var unit: String = ""

    public init(label: String = "", value: String = "", min: String = "", max: String = "", unit: String = "") {
        self.label = label
        self.value = value
        self.min = min
        self.max = max
        self.unit = unit
    }

    public var body: some View {
        IndustryCardShell(
            title: "仪表盘",
            status: nil,
            fields: [
            ("标签", label),
            ("数值", value),
            ("最小值", min),
            ("最大值", max),
            ("单位", unit),
            ]
        )
    }
}