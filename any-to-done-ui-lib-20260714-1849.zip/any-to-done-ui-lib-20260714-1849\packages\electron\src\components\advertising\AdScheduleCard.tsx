import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface AdScheduleCardProps {
  campaign?: string;
  slot?: string;
  channel?: string;
  date?: string;
  status?: string;
  onClick?: () => void;
}

/** AdScheduleCard - Electron shell (field keys aligned to React) */
export const AdScheduleCard: React.FC<AdScheduleCardProps> = (props) => (
  <IndustryCardShell title="AdScheduleCard" status={props.status} onClick={props.onClick}>
      {props.campaign ? <div className="row"><span className="label">campaign</span><span>{props.campaign}</span></div> : null}
      {props.slot ? <div className="row"><span className="label">slot</span><span>{props.slot}</span></div> : null}
      {props.channel ? <div className="row"><span className="label">channel</span><span>{props.channel}</span></div> : null}
      {props.date ? <div className="row"><span className="label">date</span><span>{props.date}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default AdScheduleCard;