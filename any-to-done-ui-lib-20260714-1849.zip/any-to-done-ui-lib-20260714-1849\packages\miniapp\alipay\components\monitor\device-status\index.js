/** DeviceStatus - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'deviceId': { type: String, value: '' },
    'name': { type: String, value: '' },
    'location': { type: String, value: '' },
    'status': { type: String, value: '' },
    'online': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});