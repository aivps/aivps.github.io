package com.uilib.components.bath

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 服务菜单 - bath industry (Compose) */
@Composable
fun ServiceMenuCard(
    name: String = "",
    price: String = "",
    duration: String = "",
    category: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "服务菜单",
        status = null,
        fields = listOf(
            "名称" to name,
            "价格" to price,
            "时长" to duration,
            "分类" to category,
        ),
        modifier = modifier,
    )
}