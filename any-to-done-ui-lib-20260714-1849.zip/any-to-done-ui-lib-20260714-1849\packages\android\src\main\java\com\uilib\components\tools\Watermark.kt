package com.uilib.components.tools

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 水印 - tools industry (Compose) */
@Composable
fun Watermark(
    text: String = "",
    opacity: String = "",
    angle: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "水印",
        status = null,
        fields = listOf(
            "文本" to text,
            "透明度" to opacity,
            "角度" to angle,
        ),
        modifier = modifier,
    )
}