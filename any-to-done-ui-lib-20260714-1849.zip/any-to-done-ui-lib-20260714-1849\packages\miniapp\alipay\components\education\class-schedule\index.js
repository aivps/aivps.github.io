/**
 * 课表 card - education industry (Alipay Mini Program)
 */
Component({
  options: { addGlobalClass: true },
  properties: {
    'className': { type: String, value: '' },
    'weekday': { type: String, value: '' },
    'period': { type: String, value: '' },
    'subject': { type: String, value: '' },
    'room': { type: String, value: '' },
  },
  methods: {
    onTap() {
      this.triggerEvent('tap', { ...this.data });
    },
  },
});