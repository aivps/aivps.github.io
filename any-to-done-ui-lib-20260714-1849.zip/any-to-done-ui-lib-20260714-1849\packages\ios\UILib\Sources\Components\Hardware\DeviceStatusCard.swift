import SwiftUI

/// 设备状态 - hardware industry (SwiftUI)
public struct DeviceStatusCard: View {
    public var deviceId: String = ""
    public var name: String = ""
    public var location: String = ""
    public var online: String = ""
    public var battery: String = ""

    public init(deviceId: String = "", name: String = "", location: String = "", online: String = "", battery: String = "") {
        self.deviceId = deviceId
        self.name = name
        self.location = location
        self.online = online
        self.battery = battery
    }

    public var body: some View {
        IndustryCardShell(
            title: "设备状态",
            status: nil,
            fields: [
            ("设备 ID", deviceId),
            ("名称", name),
            ("位置", location),
            ("在线", online),
            ("电量", battery),
            ]
        )
    }
}