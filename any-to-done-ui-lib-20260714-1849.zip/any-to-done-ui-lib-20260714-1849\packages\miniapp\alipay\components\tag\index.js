/**
 * Tag — shallow API aligned to React atoms.
 * Canonical colors + checked; type kept as variant extension (solid|outlined|light).
 */
Component({
  options: {
    addGlobalClass: true,
  },

  properties: {
    color: {
      type: String,
      value: 'default', // default, primary, success, warning, danger, info, purple
    },
    size: {
      type: String,
      value: 'md',
    },
    /** Platform extension (React Tag has no variant) */
    type: {
      type: String,
      value: 'light', // solid, outlined, light
    },
    closable: {
      type: Boolean,
      value: false,
    },
    /** React-aligned selected state */
    checked: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    resolvedColor: 'default',
  },

  observers: {
    color(color) {
      // cyan → info alias
      this.setData({ resolvedColor: color === 'cyan' ? 'info' : color || 'default' });
    },
  },

  lifetimes: {
    attached() {
      const color = this.properties.color;
      this.setData({ resolvedColor: color === 'cyan' ? 'info' : color || 'default' });
    },
  },

  methods: {
    onClose() {
      this.triggerEvent('close');
    },
    onTap() {
      this.triggerEvent('tap');
    },
  },
});
