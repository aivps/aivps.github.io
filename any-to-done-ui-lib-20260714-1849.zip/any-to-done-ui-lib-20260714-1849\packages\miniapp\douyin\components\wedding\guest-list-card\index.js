/** 宾客 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'name': { type: String, value: '' },
    'tableNumber': { type: String, value: '' },
    'status': { type: String, value: '' },
    'phone': { type: String, value: '' },
    'relationship': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
