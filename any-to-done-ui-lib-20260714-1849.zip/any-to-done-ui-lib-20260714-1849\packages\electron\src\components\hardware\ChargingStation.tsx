import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ChargingStationProps {
  id?: string;
  stationNumber?: string;
  stationType?: string;
  power?: string;
  status?: string;
  vehiclePlate?: string;
  batteryLevel?: string;
  totalFee?: string;
  onClick?: () => void;
}

/** ChargingStation - Electron shell (field keys aligned to React) */
export const ChargingStation: React.FC<ChargingStationProps> = (props) => (
  <IndustryCardShell title="ChargingStation" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.stationNumber ? <div className="row"><span className="label">stationNumber</span><span>{props.stationNumber}</span></div> : null}
      {props.stationType ? <div className="row"><span className="label">stationType</span><span>{props.stationType}</span></div> : null}
      {props.power ? <div className="row"><span className="label">power</span><span>{props.power}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.vehiclePlate ? <div className="row"><span className="label">vehiclePlate</span><span>{props.vehiclePlate}</span></div> : null}
      {props.batteryLevel ? <div className="row"><span className="label">batteryLevel</span><span>{props.batteryLevel}</span></div> : null}
      {props.totalFee ? <div className="row"><span className="label">totalFee</span><span>{props.totalFee}</span></div> : null}
  </IndustryCardShell>
);

export default ChargingStation;
