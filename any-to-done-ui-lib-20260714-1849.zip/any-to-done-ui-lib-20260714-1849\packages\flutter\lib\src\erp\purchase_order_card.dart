import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// PurchaseOrderCard - industry card shell (UTF-8 safe).
class PurchaseOrderCard extends StatelessWidget {
  final String id;
  final String orderNumber;
  final String supplier;
  final String status;
  final double totalAmount;
  final String currency;
  final String? orderDate;
  final int? itemCount;
  final VoidCallback? onTap;
  final bool disabled;

  const PurchaseOrderCard({
    super.key,
    this.id = '',
    this.orderNumber = '',
    this.supplier = '',
    required this.status,
    this.totalAmount = 0,
    this.currency = 'CNY',
    this.orderDate,
    this.itemCount,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      orderNumber.isNotEmpty ? orderNumber : id,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: colors.foreground),
                    ),
                  ),
                  Text(status, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: colors.primary)),
                ],
              ),
              if (supplier.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(supplier, style: TextStyle(fontSize: 13, color: colors.muted)),
              ],
              const SizedBox(height: 8),
              Text(
                '$currency ${totalAmount.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: colors.foreground),
              ),
              if (itemCount != null || orderDate != null) ...[
                const SizedBox(height: 4),
                Text(
                  [
                    if (itemCount != null) '$itemCount items',
                    if (orderDate != null) orderDate!,
                  ].join(' · '),
                  style: TextStyle(fontSize: 12, color: colors.muted),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
