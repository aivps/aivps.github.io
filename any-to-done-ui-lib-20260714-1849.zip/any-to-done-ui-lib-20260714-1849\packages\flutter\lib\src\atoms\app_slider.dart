import 'package:flutter/material.dart';
import '../tokens/colors.dart';
/// 滑块尺寸
enum SliderSize {
  sm,
  md,
  lg,
}

/// AppSlider 滑块组件
class AppSlider extends StatelessWidget {
  final double value;
  final double min;
  final double max;
  final double step;
  final bool disabled;
  final SliderSize size;
  final ValueChanged<double>? onChanged;
  final ValueChanged<double>? onChangeEnd;

  const AppSlider({
    super.key,
    this.value = 0,
    this.min = 0,
    this.max = 100,
    this.step = 1,
    this.disabled = false,
    this.size = SliderSize.md,
    this.onChanged,
    this.onChangeEnd,
  });

  @override
  Widget build(BuildContext context) {
    return SliderTheme(
      data: SliderThemeData(
        trackHeight: _getTrackHeight(),
        activeTrackColor: AppColors.primary,
        inactiveTrackColor: AppColors.gray200,
        thumbColor: AppColors.primary,
        thumbShape: RoundSliderThumbShape(enabledThumbRadius: _getThumbRadius()),
        overlayColor: AppColors.primary.withValues(alpha: 0.2),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
      ),
      child: Slider(
        value: value.clamp(min, max),
        min: min,
        max: max,
        divisions: step < (max - min) ? ((max - min) / step).round() : null,
        onChanged: disabled ? null : onChanged,
        onChangeEnd: onChangeEnd,
      ),
    );
  }

  double _getTrackHeight() {
    switch (size) {
      case SliderSize.sm:
        return 4;
      case SliderSize.md:
        return 6;
      case SliderSize.lg:
        return 8;
    }
  }

  double _getThumbRadius() {
    switch (size) {
      case SliderSize.sm:
        return 6;
      case SliderSize.md:
        return 8;
      case SliderSize.lg:
        return 10;
    }
  }
}
