import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface CourseCardProps {
  title?: string | number;
  teacher?: string | number;
  price?: string | number;
  duration?: string | number;
  studentCount?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 课程 - field-deep aligned shell */
export const CourseCard: React.FC<CourseCardProps> = ({
  title,
  teacher,
  price,
  duration,
  studentCount,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="课程"
    status={status}
    fields={[
    { label: '标题', value: title },
    { label: '讲师', value: teacher },
    { label: '价格', value: price },
    { label: '时长', value: duration },
    { label: '学员数', value: studentCount },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default CourseCard;