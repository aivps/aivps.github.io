/** AdScheduleCard - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'campaign': { type: String, value: '' },
    'slot': { type: String, value: '' },
    'channel': { type: String, value: '' },
    'date': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});