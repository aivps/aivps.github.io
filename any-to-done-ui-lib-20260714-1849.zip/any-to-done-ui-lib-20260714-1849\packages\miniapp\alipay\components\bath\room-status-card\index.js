/** RoomStatusCard - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'roomNumber': { type: String, value: '' },
    'roomType': { type: String, value: '' },
    'status': { type: String, value: '' },
    'guestName': { type: String, value: '' },
    'checkInTime': { type: String, value: '' },
    'amount': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});