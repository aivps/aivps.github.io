package com.uilib.components.wedding

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 婚礼 - field-deep aligned shell (Compose) */
@Composable
fun WeddingCard(
    id: String = "",
    couple: String = "",
    date: String = "",
    venue: String = "",
    guestCount: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "婚礼",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "新人" to couple,
            "日期" to date,
            "场地" to venue,
            "宾客数" to guestCount,
        ),
        modifier = modifier,
    )
}
