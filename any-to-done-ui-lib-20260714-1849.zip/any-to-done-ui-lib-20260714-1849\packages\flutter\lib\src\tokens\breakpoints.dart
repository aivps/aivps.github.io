import 'package:flutter/material.dart';

/// Design Tokens - Breakpoints
/// 响应式断点 + 设备类型检测
class AppBreakpoints {
  AppBreakpoints._();

  static const double phoneSmall = 0;
  static const double phone = 320;
  static const double phoneLarge = 375;
  static const double tablet = 768;
  static const double laptop = 1024;
  static const double desktop = 1280;
  static const double wide = 1440;
  static const double ultrawide = 1920;
}

/// 设备类型
enum DeviceType {
  phone,
  tablet,
  desktop,
  tv,
  watch,
}

/// 响应式工具类
class ResponsiveUtils {
  static DeviceType getDeviceType(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    
    if (width >= AppBreakpoints.desktop) return DeviceType.desktop;
    if (width >= AppBreakpoints.tablet) return DeviceType.tablet;
    return DeviceType.phone;
  }

  static bool isLandscape(BuildContext context) {
    return MediaQuery.of(context).orientation == Orientation.landscape;
  }

  static bool isPortrait(BuildContext context) {
    return MediaQuery.of(context).orientation == Orientation.portrait;
  }

  static T responsiveValue<T>(
    BuildContext context, {
    T? phone,
    T? tablet,
    T? desktop,
    required T defaultValue,
  }) {
    final deviceType = getDeviceType(context);
    
    switch (deviceType) {
      case DeviceType.phone:
        return phone ?? defaultValue;
      case DeviceType.tablet:
        return tablet ?? defaultValue;
      case DeviceType.desktop:
        return desktop ?? defaultValue;
      default:
        return defaultValue;
    }
  }
}

/// 触控目标尺寸
class TouchTargets {
  TouchTargets._();

  static const double minimum = 44;
  static const double comfortable = 48;
  static const double large = 56;
}

/// 平台特定尺寸
class PlatformSizes {
  PlatformSizes._();

  static const double statusBar = 24;
  static const double navBar = 56;
  static const double tabBar = 56;
  static const double bottomSpacing = 0;
}
