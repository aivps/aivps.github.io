﻿import SwiftUI

/// 采购单 - field-deep aligned shell (SwiftUI)
public struct PurchaseOrderCard: View {
    public var id: String = ""
    public var orderNumber: String = ""
    public var supplier: String = ""
    public var totalAmount: String = ""
    public var status: String = ""
    public var orderDate: String = ""
    public var expectedDate: String = ""
    public var buyer: String = ""

    public init(id: String = "", orderNumber: String = "", supplier: String = "", totalAmount: String = "", status: String = "", orderDate: String = "", expectedDate: String = "", buyer: String = "") {
        self.id = id
        self.orderNumber = orderNumber
        self.supplier = supplier
        self.totalAmount = totalAmount
        self.status = status
        self.orderDate = orderDate
        self.expectedDate = expectedDate
        self.buyer = buyer
    }

    public var body: some View {
        IndustryCardShell(
            title: "采购单",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("订单号", orderNumber),
            ("供应商", supplier),
            ("金额", totalAmount),
            ("下单日期", orderDate),
            ("预计到货", expectedDate),
            ("采购员", buyer),
            ]
        )
    }
}
