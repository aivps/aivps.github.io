/** ServerStatus - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'ip': { type: String, value: '' },
    'cpu': { type: String, value: '' },
    'memory': { type: String, value: '' },
    'disk': { type: String, value: '' },
    'status': { type: String, value: '' },
    'uptime': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});