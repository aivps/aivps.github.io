/** ApprovalFlow - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'title': { type: String, value: '' },
    'applicant': { type: String, value: '' },
    'currentStep': { type: String, value: '' },
    'totalSteps': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});