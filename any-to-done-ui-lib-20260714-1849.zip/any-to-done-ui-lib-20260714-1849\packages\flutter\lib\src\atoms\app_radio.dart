import 'package:flutter/material.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';

/// 单选框尺寸
enum RadioSize {
  sm,
  md,
  lg,
}

/// AppRadio 单选框组件
class AppRadio extends StatelessWidget {
  final bool value;
  final bool disabled;
  final RadioSize size;
  final String? label;
  final VoidCallback? onChanged;

  const AppRadio({
    super.key,
    this.value = false,
    this.disabled = false,
    this.size = RadioSize.md,
    this.label,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: disabled ? null : onChanged,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: _getSize(),
            height: _getSize(),
            decoration: BoxDecoration(
              color: AppColors.gray0,
              border: Border.all(
                color: value ? AppColors.primary : AppColors.gray400,
                width: 1.5,
              ),
              shape: BoxShape.circle,
            ),
            child: value
                ? Center(
                    child: Container(
                      width: _getDotSize(),
                      height: _getDotSize(),
                      decoration: const BoxDecoration(
                        color: AppColors.primary,
                        shape: BoxShape.circle,
                      ),
                    ),
                  )
                : null,
          ),
          if (label != null) ...[
            const SizedBox(width: AppSpacing.sm),
            Text(
              label!,
              style: TextStyle(
                fontSize: 14,
                color: disabled ? AppColors.gray500 : AppColors.gray900,
              ),
            ),
          ],
        ],
      ),
    );
  }

  double _getSize() {
    switch (size) {
      case RadioSize.sm:
        return 16;
      case RadioSize.md:
        return 20;
      case RadioSize.lg:
        return 24;
    }
  }

  double _getDotSize() {
    switch (size) {
      case RadioSize.sm:
        return 6;
      case RadioSize.md:
        return 8;
      case RadioSize.lg:
        return 10;
    }
  }
}
