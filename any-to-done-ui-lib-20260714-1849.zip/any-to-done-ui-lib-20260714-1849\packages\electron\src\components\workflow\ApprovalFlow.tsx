import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ApprovalFlowProps {
  title?: string;
  applicant?: string;
  currentStep?: string;
  totalSteps?: string;
  status?: string;
  onClick?: () => void;
}

/** ApprovalFlow - Electron shell (field keys aligned to React) */
export const ApprovalFlow: React.FC<ApprovalFlowProps> = (props) => (
  <IndustryCardShell title="ApprovalFlow" status={props.status} onClick={props.onClick}>
      {props.title ? <div className="row"><span className="label">title</span><span>{props.title}</span></div> : null}
      {props.applicant ? <div className="row"><span className="label">applicant</span><span>{props.applicant}</span></div> : null}
      {props.currentStep ? <div className="row"><span className="label">currentStep</span><span>{props.currentStep}</span></div> : null}
      {props.totalSteps ? <div className="row"><span className="label">totalSteps</span><span>{props.totalSteps}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default ApprovalFlow;