export { StudentCard } from './StudentCard';
export type { StudentCardProps } from './StudentCard';
export { ChildPatientCard } from './ChildPatientCard';
export type { ChildPatientCardProps } from './ChildPatientCard';