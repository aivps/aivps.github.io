﻿import SwiftUI

/// 商品 - industry (SwiftUI, field-deep aligned)
public struct ProductCard: View {
    public var id: String = ""
    public var name: String = ""
    public var price: String = ""
    public var originalPrice: String = ""
    public var sales: String = ""
    public var image: String = ""
    public var status: String = ""

    public init(id: String = "", name: String = "", price: String = "", originalPrice: String = "", sales: String = "", image: String = "", status: String = "") {
        self.id = id
        self.name = name
        self.price = price
        self.originalPrice = originalPrice
        self.sales = sales
        self.image = image
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "商品",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("名称", name),
            ("价格", price),
            ("原价", originalPrice),
            ("销量", sales),
            ("图片", image),
            ]
        )
    }
}
