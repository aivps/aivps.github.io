import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface WeddingCardProps {
  id?: string | number;
  couple?: string | number;
  date?: string | number;
  venue?: string | number;
  guestCount?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 婚礼 - field-deep aligned shell */
export const WeddingCard: React.FC<WeddingCardProps> = ({
  id,
  couple,
  date,
  venue,
  guestCount,
  status,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="婚礼"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '新人', value: couple },
      { label: '日期', value: date },
      { label: '场地', value: venue },
      { label: '宾客数', value: guestCount },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default WeddingCard;
