﻿import SwiftUI

/// 销售单 - field-deep aligned shell (SwiftUI)
public struct SalesOrderCard: View {
    public var orderNumber: String = ""
    public var customer: String = ""
    public var totalAmount: String = ""
    public var status: String = ""
    public var orderDate: String = ""
    public var deliveryDate: String = ""
    public var salesPerson: String = ""

    public init(orderNumber: String = "", customer: String = "", totalAmount: String = "", status: String = "", orderDate: String = "", deliveryDate: String = "", salesPerson: String = "") {
        self.orderNumber = orderNumber
        self.customer = customer
        self.totalAmount = totalAmount
        self.status = status
        self.orderDate = orderDate
        self.deliveryDate = deliveryDate
        self.salesPerson = salesPerson
    }

    public var body: some View {
        IndustryCardShell(
            title: "销售单",
            status: status.isEmpty ? nil : status,
            fields: [
            ("订单号", orderNumber),
            ("客户", customer),
            ("金额", totalAmount),
            ("下单日期", orderDate),
            ("交货日期", deliveryDate),
            ("销售", salesPerson),
            ]
        )
    }
}
