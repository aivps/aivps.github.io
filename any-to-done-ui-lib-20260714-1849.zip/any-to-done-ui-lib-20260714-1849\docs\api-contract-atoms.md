# 原子组件浅 API 契约（React 为准）

> **用途**：RN / Flutter / WC 与 React 原子层 **浅对齐** 的单一真相源。  
> **浅对齐**：props 名、枚举值、核心语义一致；平台特有扩展允许，但须有兼容别名。  
> **权威实现**：根目录 `src/atoms/*`

---

## 约定

1. **Canonical 优先**：新代码只用 React 契约里的名字。
2. **Legacy 别名**：旧值可继续传入，在组件内 normalize 到 canonical。
3. **平台扩展**：如 RN `testID`、Flutter `Key`、WC attribute 布尔形态，不反向污染 React。
4. **不强制深对齐**：hover / DOM 事件 / 响应式 `responsiveSize` 等 web-only 能力不要求移动端 1:1。

---

## Button

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `variant` | `primary` \| `secondary` \| `text` \| `danger` \| `ghost` | — |
| `size` | `xs` \| `sm` \| `md` \| `lg` | 默认 `md` |
| `loading` | boolean | — |
| `disabled` | boolean | — |
| `block` | boolean | — |
| `circle` | boolean | 圆形按钮 |
| `error` | boolean | 错误描边态（可选） |
| `icon` | node | — |
| `iconPosition` | `left` \| `right` | 默认 `left` |
| `children` | node / string | 文案或子节点 |

**Legacy → Canonical**

| Legacy | Canonical |
|--------|-----------|
| `outline` | `secondary`（描边视觉可保留） |
| `link` | `text` |
| `shape: 'circle'` | `circle: true` |
| `shape: 'round'` | 平台扩展（大圆角），无 React 对应 |

---

## Input

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `variant` | `outlined` \| `filled` \| `borderless` | 默认 `outlined` |
| `size` | `sm` \| `md` \| `lg` | 默认 `md` |
| `status` | `default` \| `error` \| `success` \| `warning` | — |
| `label` | string | — |
| `placeholder` | string | — |
| `disabled` | boolean | — |
| `readOnly` | boolean | — |
| `loading` | boolean | 可选 |
| `prefix` / `suffix` | node | — |
| `errorMessage` | string | 优先于通用 helper |
| `helperText` | string | — |

**Legacy → Canonical**

| Legacy | Canonical |
|--------|-----------|
| `fullWidth` | 默认块级 / `block`（若有） |
| `helperText` + `status=error` | 可同时存在；展示优先 `errorMessage` |

---

## Tag

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `color` | `default` \| `primary` \| `success` \| `warning` \| `danger` \| `info` | — |
| `size` | `sm` \| `md` \| `lg` | 默认 `md` |
| `closable` | boolean | — |
| `checked` | boolean | 可选 |
| `icon` | node | — |
| `onClose` | fn | — |
| `children` | node / string | — |

**扩展（允许，非契约）**：`purple` color、`variant: solid|outlined|light`（RN/Flutter）。

---

## Badge

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `color` | `default` \| `primary` \| `success` \| `warning` \| `danger` \| `info` | — |
| `size` | `sm` \| `md` \| `lg` | 默认 `md` |
| `count` | number | — |
| `overflowCount` | number | 默认 `99` |
| `text` | string | — |
| `dot` | boolean | — |
| `standalone` | boolean | 无 children 时独立显示 |
| `children` | node | 挂载角标的宿主 |

**Legacy → Canonical**

| Legacy | Canonical |
|--------|-----------|
| `status: success\|processing\|error\|default\|warning` | 映射到 `color`（`processing`→`primary`，`error`→`danger`） |

---

## Card

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `title` | node / string | — |
| `extra` | node | 右上角操作区 |
| `bordered` | boolean | 默认 true |
| `hoverable` | boolean | web 悬停抬升；移动端可映射 press |
| `loading` | boolean | — |
| `children` | node | — |
| `onClick` / `onPress` | fn | 平台命名：web=`onClick`，RN/Flutter=`onPress` |

**扩展**：`variant`（`default`\|`outlined`\|`filled`）、`padding`（`none`\|`sm`\|`md`\|`lg`）。

---

## 命名对照（导出）

| 概念 | React | RN | Flutter | WC tag | Vue | 小程序 | Android | iOS |
|------|-------|-----|---------|--------|-----|--------|---------|-----|
| 按钮 | `Button` | `Button` | `AppButton` | `app-button` | `Button` | `button` | `AppButton` | `AppButton` |
| 输入 | `Input` | `Input` | `AppInput` | `app-input` | `Input` | `input` | `AppInput` | `AppInput` |
| 标签 | `Tag` | `Tag` | `AppTag` | `app-tag` | `Tag` | `tag` | `AppTag` | `AppTag` |
| 徽章 | `Badge` | `Badge` | `AppBadge` | `app-badge` | `Badge` | `badge` | `AppBadge` | `AppBadge` |
| 卡片 | `Card` | `Card` | `AppCard` | `app-card` | `Card` | `card` | `AppCard` | `AppCard` |

---

## 平台覆盖（浅对齐）

| 端 | Button | Input | Tag | Badge | Card | 备注 |
|----|--------|-------|-----|-------|------|------|
| React (权威) | ✅ | ✅ | ✅ | ✅ | ✅ | `src/atoms/*` + `src/composite/Card` |
| RN | ✅ | ✅ | ✅ | ✅ | ✅ | legacy normalize |
| Flutter | ✅ | ✅ | ✅ | ✅ | ✅ | `App*` 前缀 |
| WC | ✅ | ✅ | ✅ | ✅ | ✅ | attribute 布尔 |
| Vue | ✅ | ✅ | ✅ | ✅ | ✅ | `.vue` + TSX 双轨 |
| 微信小程序 | ✅ | ✅ | ✅ | ✅ | ✅ | `variant` 优先，`type` legacy |
| Android Compose | ✅ | ✅ | ✅ | ✅ | ✅ | `ButtonVariant` enum |
| iOS SwiftUI | ✅ | ✅ | ✅ | ✅ | ✅ | `AppButtonVariant` |

---

## 本轮不做

- 行业卡字段级 API 深对齐
- 支付宝 / 抖音小程序同步（可复制 weixin 契约）
- 动效 / 主题语义（已在前序迭代完成）
