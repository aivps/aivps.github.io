# 真机 / DevTools 冒烟清单

> 静态结构校验：仓库根目录执行 `pnpm smoke` 或  
> `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke-check.ps1`  
> 报告写入 `scripts/smoke-report.latest.md`。

本清单用于 **本机已安装对应工具链** 时的人工确认。当前 CI / 部分开发机可能没有 Gradle / Xcode / 小程序 DevTools。

---

## 0. 静态（必做，可无人值守）

```bash
pnpm smoke
# 或
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/smoke-check.ps1
```

通过标准：`FAIL = 0`。`WARN` 多为「本机无编译器」，不阻塞。

---

## 1. 微信小程序

| 步骤 | 操作 | 期望 |
|------|------|------|
| 1 | 微信开发者工具 → 导入项目 → 目录选 `packages/miniapp/weixin` | 无 app.json / 页面缺失报错 |
| 2 | AppID 可用测试号 / `touristappid` | 可编译到模拟器 |
| 3 | 打开首页「行业卡冒烟」 | 至少 7 张行业卡可见（医疗/电商/财务/审批/运维/BI/电签 + VirtualList shell） |
| 4 | 点击任意卡片 | 底部「最近点击」出现 JSON 摘要 |
| 5 | 点「组件目录页」 | 列出 phase6 行业叶子组件名 |
| 6 | （可选）真机预览 | 卡片布局正常、无白屏 |
| 7 | （可选）截图覆盖 | 保存为 `visual-baselines/manual/weixin_home.png` 后 `pnpm visual` |

> 无 DevTools 时：浏览器打开 `packages/miniapp/visual-host.html?platform=weixin` 看代理壳；`pnpm visual` 已自动截该壳。

---

## 2. 支付宝小程序

| 步骤 | 操作 | 期望 |
|------|------|------|
| 1 | 支付宝开发者工具导入 `packages/miniapp/alipay` | 识别 `mini.project.json` |
| 2 | 编译首页 | 行业卡渲染 |
| 3 | 点击卡片 | 「最近点击」更新 |

---

## 3. 抖音小程序

| 步骤 | 操作 | 期望 |
|------|------|------|
| 1 | 抖音开发者工具导入 `packages/miniapp/douyin` | 识别 `project.config.json` |
| 2 | 编译首页 | 行业卡渲染 |
| 3 | 点击卡片 | 「最近点击」更新 |

---

## 4. Android（Compose 库模块）

库路径：`packages/android`（`com.android.library`，非完整 Application）。

| 步骤 | 操作 | 期望 |
|------|------|------|
| 1 | Android Studio 打开 monorepo 或单独 include 该 module | Gradle Sync 成功 |
| 2 | `./gradlew :android:assembleDebug`（需本机 wrapper / 上级工程） | 编译通过 |
| 3 | 在宿主 App 中 `@Composable PatientCard(...)` Preview | 卡片字段与契约一致 |

无完整宿主 App 时，**以 Sync + 单模块 compileKotlin 通过为准**。

---

## 5. iOS（SwiftUI Pod）

路径：`packages/ios` + `UILib.podspec`。

| 步骤 | 操作 | 期望 |
|------|------|------|
| 1 | macOS + Xcode 14+ | — |
| 2 | `pod lib lint packages/ios/UILib.podspec --allow-warnings`（可选） | 无致命错误 |
| 3 | 示例 App 引入 Sources，SwiftUI Preview `PatientCard` | 可预览 |

Windows 上 **无法** 完成此节；以静态 `smoke-check` 的 `.swift` 存在性为准。

---

## 6. 记录模板

跑 `pnpm smoke` 会自动覆盖写入 **`scripts/smoke-checklist.latest.md`**（静态 PASS/FAIL + 无工具链项 SKIP）。有 DevTools / Gradle / Xcode 的机器再人工改状态归档。

```
日期：
操作人：
静态 smoke：PASS / FAIL（报告路径）
微信 DevTools：PASS / FAIL / SKIP
支付宝：PASS / FAIL / SKIP
抖音：PASS / FAIL / SKIP
Android assemble：PASS / FAIL / SKIP
iOS Preview / pod lint：PASS / FAIL / SKIP
备注：
```

---

## 7. 截图验收（可选）

```bash
pnpm visual          # 对比 visual-baselines/
pnpm visual:update   # 有意改版后更新基线
```

详见 `docs/visual-regression.md`。小程序默认走 `packages/miniapp/visual-host.html` 代理截图入库 `visual-baselines/manual/*_home.png`；DevTools 真图可覆盖同路径。

---

## 诚实边界

- 小程序行业卡是 **字段级 shell**（扁平 props），不是 React 完整交互移植。
- Android / iOS 为 Phase 6 **Compose / SwiftUI 骨架**，依赖宿主工程才能上真机 UI。
- 空目录原子 stub（如 `checkbox` / `drawer`）不在 phase6 冒烟范围内。
