import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface GameRoomCardProps {
  id?: string | number;
  roomNumber?: string | number;
  gameName?: string | number;
  playerCount?: string | number;
  maxPlayers?: string | number;
  status?: string;
  /** @deprecated use roomNumber */
  roomId?: string | number;
  /** @deprecated use gameName */
  game?: string | number;
  /** @deprecated use playerCount */
  players?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 游戏房 - field-deep aligned shell */
export const GameRoomCard: React.FC<GameRoomCardProps> = ({
  id,
  roomNumber,
  gameName,
  playerCount,
  maxPlayers,
  status,
  roomId,
  game,
  players,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="游戏房"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '房间号', value: roomNumber ?? roomId },
      { label: '游戏', value: gameName ?? game },
      { label: '玩家数', value: playerCount ?? players },
      { label: '人数上限', value: maxPlayers },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default GameRoomCard;
