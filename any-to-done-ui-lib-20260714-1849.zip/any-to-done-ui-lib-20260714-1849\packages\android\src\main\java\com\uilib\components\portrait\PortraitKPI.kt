package com.uilib.components.portrait

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 画像KPI - portrait industry (Compose) */
@Composable
fun PortraitKPI(
    label: String = "",
    value: String = "",
    delta: String = "",
    unit: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "画像KPI",
        status = null,
        fields = listOf(
            "标签" to label,
            "数值" to value,
            "变化" to delta,
            "单位" to unit,
        ),
        modifier = modifier,
    )
}