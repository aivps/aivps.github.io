package com.uilib.components.hardware

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 充电桩 - hardware industry (Compose) */
@Composable
fun ChargingStation(
    stationId: String = "",
    location: String = "",
    powerKw: String = "",
    ports: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "充电桩",
        status = status.ifBlank { null },
        fields = listOf(
            "站点 ID" to stationId,
            "位置" to location,
            "功率(kW)" to powerKw,
            "端口" to ports,
        ),
        modifier = modifier,
    )
}