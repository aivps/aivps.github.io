﻿package com.uilib.components.manufacturing

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 生产面板 - field-deep aligned shell (Compose) */
@Composable
fun ProductionPanel(
    lineId: String = "",
    lineName: String = "",
    dailyOutput: String = "",
    dailyTarget: String = "",
    qualityRate: String = "",
    alarmCount: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "生产面板",
        status = status.ifBlank { null },
        fields = listOf(
            "产线ID" to lineId,
            "产线" to lineName,
            "当日产量" to dailyOutput,
            "目标" to dailyTarget,
            "良品率" to qualityRate,
            "告警" to alarmCount,
        ),
        modifier = modifier,
    )
}
