import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface HomeworkCardProps {
  title?: string;
  subject?: string;
  dueDate?: string;
  className?: string;
  status?: string;
  onClick?: () => void;
}

/** HomeworkCard - Electron shell (field keys aligned to React) */
export const HomeworkCard: React.FC<HomeworkCardProps> = (props) => (
  <IndustryCardShell title="HomeworkCard" status={props.status} onClick={props.onClick}>
      {props.title ? <div className="row"><span className="label">title</span><span>{props.title}</span></div> : null}
      {props.subject ? <div className="row"><span className="label">subject</span><span>{props.subject}</span></div> : null}
      {props.dueDate ? <div className="row"><span className="label">dueDate</span><span>{props.dueDate}</span></div> : null}
      {props.className ? <div className="row"><span className="label">className</span><span>{props.className}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default HomeworkCard;