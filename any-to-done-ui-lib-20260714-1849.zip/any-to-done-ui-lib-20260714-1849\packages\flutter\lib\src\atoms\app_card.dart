import 'package:flutter/material.dart';
import '../tokens/spacing.dart';
import '../tokens/theme_colors.dart';
import '../tokens/motion.dart';

/// 卡片变体
enum CardVariant {
  defaultType,
  outlined,
  filled,
}

/// 卡片内边距
enum CardPadding {
  none,
  sm,
  md,
  lg,
}

/// AppCard — theme-aware + light press scale when tappable
class AppCard extends StatefulWidget {
  final CardVariant variant;
  final CardPadding padding;
  final bool bordered;
  final VoidCallback? onTap;
  final Widget? child;

  const AppCard({
    super.key,
    this.variant = CardVariant.defaultType,
    this.padding = CardPadding.md,
    this.bordered = true,
    this.onTap,
    this.child,
  });

  @override
  State<AppCard> createState() => _AppCardState();
}

class _AppCardState extends State<AppCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final canPress = widget.onTap != null;

    Widget card = AnimatedContainer(
      duration: AppMotion.normal,
      curve: Curves.easeOutCubic,
      decoration: _getDecoration(colors, _pressed && canPress),
      padding: _getPadding(),
      child: widget.child,
    );

    if (canPress) {
      card = AnimatedScale(
        scale: _pressed ? AppMotion.pressScale : 1,
        duration: AppMotion.fast,
        curve: Curves.easeOutCubic,
        child: GestureDetector(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapUp: (_) {
            setState(() => _pressed = false);
            widget.onTap?.call();
          },
          onTapCancel: () => setState(() => _pressed = false),
          child: card,
        ),
      );
    }

    return card;
  }

  BoxDecoration _getDecoration(AppThemeColors colors, bool pressed) {
    final borderColor = pressed ? colors.primary : colors.border;
    switch (widget.variant) {
      case CardVariant.defaultType:
        return BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(AppRadius.base),
          border: widget.bordered ? Border.all(color: borderColor) : null,
          boxShadow: pressed ? AppShadow.md : AppShadow.sm,
        );
      case CardVariant.outlined:
        return BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.circular(AppRadius.base),
          border: Border.all(color: borderColor),
        );
      case CardVariant.filled:
        return BoxDecoration(
          color: colors.bgPage,
          borderRadius: BorderRadius.circular(AppRadius.base),
        );
    }
  }

  EdgeInsets _getPadding() {
    switch (widget.padding) {
      case CardPadding.none:
        return EdgeInsets.zero;
      case CardPadding.sm:
        return const EdgeInsets.all(AppSpacing.mdValue);
      case CardPadding.md:
        return const EdgeInsets.all(AppSpacing.base);
      case CardPadding.lg:
        return const EdgeInsets.all(AppSpacing.lgValue);
    }
  }
}
