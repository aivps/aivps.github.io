Component({
  properties: {
    value: { type: String, value: '' },
    options: { type: Array, value: [] },
    placeholder: { type: String, value: '请选择' },
    disabled: { type: Boolean, value: false },
  },
  data: { open: false },
  methods: {
    toggleDropdown() {
      if (this.data.disabled) return;
      this.setData({ open: !this.data.open });
    },
    onSelect(e) {
      const val = e.currentTarget.dataset.value;
      this.setData({ open: false });
      this.triggerEvent('change', { value: val });
    },
  },
});
