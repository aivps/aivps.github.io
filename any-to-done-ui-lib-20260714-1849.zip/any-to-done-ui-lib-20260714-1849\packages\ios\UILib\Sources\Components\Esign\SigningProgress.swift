import SwiftUI

/// 签署进度 - field-deep aligned shell (SwiftUI)
public struct SigningProgress: View {
    public var contractId: String = ""
    public var contractTitle: String = ""
    public var progress: String = ""
    public var signed: String = ""
    public var total: String = ""
    public var status: String = ""

    public init(contractId: String = "", contractTitle: String = "", progress: String = "", signed: String = "", total: String = "", status: String = "") {
        self.contractId = contractId
        self.contractTitle = contractTitle
        self.progress = progress
        self.signed = signed
        self.total = total
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "签署进度",
            status: status.isEmpty ? nil : status,
            fields: [
                ("合同 ID", contractId),
                ("合同标题", contractTitle),
                ("进度%", progress),
                ("已签", signed),
                ("合计", total),
            ]
        )
    }
}
