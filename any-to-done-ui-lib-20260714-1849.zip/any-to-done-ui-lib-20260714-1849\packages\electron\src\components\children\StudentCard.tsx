import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface StudentCardProps {
  name?: string;
  age?: string;
  className?: string;
  guardian?: string;
  status?: string;
  onClick?: () => void;
}

/** StudentCard - Electron shell (field keys aligned to React) */
export const StudentCard: React.FC<StudentCardProps> = (props) => (
  <IndustryCardShell title="StudentCard" status={props.status} onClick={props.onClick}>
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.age ? <div className="row"><span className="label">age</span><span>{props.age}</span></div> : null}
      {props.className ? <div className="row"><span className="label">className</span><span>{props.className}</span></div> : null}
      {props.guardian ? <div className="row"><span className="label">guardian</span><span>{props.guardian}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default StudentCard;