import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// SalesOrderCard - industry card shell (UTF-8 safe English labels).
class SalesOrderCard extends StatelessWidget {
  final String id;
  final String orderNumber;
  final String customer;
  final String status;
  final double totalAmount;
  final String currency;
  final String? orderDate;
  final VoidCallback? onTap;
  final bool disabled;

  const SalesOrderCard({
    super.key,
    this.id = '',
    this.orderNumber = '',
    this.customer = '',
    required this.status,
    this.totalAmount = 0,
    this.currency = 'CNY',
    this.orderDate,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      orderNumber.isNotEmpty ? orderNumber : id,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: colors.foreground,
                      ),
                    ),
                  ),
                  _StatusChip(status: status, color: colors.primary, bg: colors.primaryBg),
                ],
              ),
              if (customer.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(customer, style: TextStyle(fontSize: 13, color: colors.muted)),
              ],
              const SizedBox(height: 8),
              Text(
                '$currency ${totalAmount.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: colors.foreground),
              ),
              if (orderDate != null) ...[
                const SizedBox(height: 4),
                Text(orderDate!, style: TextStyle(fontSize: 12, color: colors.muted)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String status;
  final Color color;
  final Color bg;
  const _StatusChip({required this.status, required this.color, required this.bg});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(AppRadius.sm)),
      child: Text(status, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: color)),
    );
  }
}
