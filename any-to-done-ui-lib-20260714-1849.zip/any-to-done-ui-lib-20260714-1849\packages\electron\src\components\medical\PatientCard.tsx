import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface PatientCardProps {
  id?: string | number;
  name?: string | number;
  gender?: string | number;
  age?: string | number;
  phone?: string | number;
  department?: string | number;
  visitType?: string | number;
  status?: string;
  queueNumber?: string | number;
  visitTime?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 患者 - medical/ecommerce (Electron, field-deep aligned) */
export const PatientCard: React.FC<PatientCardProps> = ({
  id,
  name,
  gender,
  age,
  phone,
  department,
  visitType,
  status,
  queueNumber,
  visitTime,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="患者"
    status={status}
    fields={[
    { label: 'ID', value: id },
    { label: '姓名', value: name },
    { label: '性别', value: gender },
    { label: '年龄', value: age },
    { label: '电话', value: phone },
    { label: '科室', value: department },
    { label: '挂号类型', value: visitType },
    { label: '排队号', value: queueNumber },
    { label: '就诊时间', value: visitTime },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default PatientCard;
