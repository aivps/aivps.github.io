/** 故障 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'incidentId': { type: String, value: '' },
    'title': { type: String, value: '' },
    'level': { type: String, value: '' },
    'status': { type: String, value: '' },
    'assignee': { type: String, value: '' },
    'createdAt': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
