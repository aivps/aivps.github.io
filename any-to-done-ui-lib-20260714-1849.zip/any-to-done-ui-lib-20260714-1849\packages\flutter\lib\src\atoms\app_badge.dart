import 'package:flutter/material.dart';
import '../tokens/colors.dart';
/// 徽章状态
enum BadgeStatus {
  success,
  processing,
  error,
  defaultType,
  warning,
}

/// AppBadge 徽章组件
class AppBadge extends StatelessWidget {
  final int? count;
  final bool dot;
  final BadgeStatus status;
  final int overflowCount;
  final bool showZero;
  final Widget? child;

  const AppBadge({
    super.key,
    this.count,
    this.dot = false,
    this.status = BadgeStatus.error,
    this.overflowCount = 99,
    this.showZero = false,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    final shouldShow = dot || (count != null && (count! > 0 || showZero));

    if (child == null) {
      return shouldShow ? _buildBadge() : const SizedBox.shrink();
    }

    return Stack(
      clipBehavior: Clip.none,
      children: [
        child!,
        if (shouldShow)
          Positioned(
            right: -6,
            top: -6,
            child: _buildBadge(),
          ),
      ],
    );
  }

  Widget _buildBadge() {
    if (dot) {
      return Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: _getStatusColor(),
          shape: BoxShape.circle,
        ),
      );
    }

    return Container(
      height: 20,
      padding: const EdgeInsets.symmetric(horizontal: 6),
      decoration: BoxDecoration(
        color: _getStatusColor(),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Text(
          _getDisplayCount(),
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: AppColors.gray0,
          ),
        ),
      ),
    );
  }

  String _getDisplayCount() {
    if (count == null) return '';
    if (count! > overflowCount) return '$overflowCount+';
    return count.toString();
  }

  Color _getStatusColor() {
    switch (status) {
      case BadgeStatus.success:
        return AppColors.success;
      case BadgeStatus.processing:
        return AppColors.primary;
      case BadgeStatus.error:
        return AppColors.danger;
      case BadgeStatus.warning:
        return AppColors.orange;
      case BadgeStatus.defaultType:
        return AppColors.gray300;
    }
  }
}
