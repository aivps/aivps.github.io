import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ContractCardProps {
  id?: string | number;
  contractNumber?: string | number;
  title?: string | number;
  parties?: string | number;
  amount?: string | number;
  status?: string;
  createdAt?: string | number;
  /** @deprecated use contractNumber */
  contractNo?: string | number;
  /** @deprecated use createdAt */
  date?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 合同 - field-deep aligned shell */
export const ContractCard: React.FC<ContractCardProps> = ({
  id,
  contractNumber,
  title,
  parties,
  amount,
  status,
  createdAt,
  contractNo,
  date,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="合同"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '合同号', value: contractNumber ?? contractNo },
      { label: '标题', value: title },
      { label: '签署方', value: parties },
      { label: '金额', value: amount },
      { label: '创建日期', value: createdAt ?? date },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ContractCard;
