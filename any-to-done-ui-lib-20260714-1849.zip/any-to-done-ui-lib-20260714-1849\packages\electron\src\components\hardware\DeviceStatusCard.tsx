import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface DeviceStatusCardProps {
  id?: string;
  name?: string;
  type?: string;
  location?: string;
  status?: string;
  lastHeartbeat?: string;
  battery?: string;
  onClick?: () => void;
}

/** DeviceStatusCard - Electron shell (field keys aligned to React) */
export const DeviceStatusCard: React.FC<DeviceStatusCardProps> = (props) => (
  <IndustryCardShell title="DeviceStatusCard" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.type ? <div className="row"><span className="label">type</span><span>{props.type}</span></div> : null}
      {props.location ? <div className="row"><span className="label">location</span><span>{props.location}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.lastHeartbeat ? <div className="row"><span className="label">lastHeartbeat</span><span>{props.lastHeartbeat}</span></div> : null}
      {props.battery ? <div className="row"><span className="label">battery</span><span>{props.battery}</span></div> : null}
  </IndustryCardShell>
);

export default DeviceStatusCard;
