import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface EvidenceCardProps {
  caseId?: string | number;
  name?: string | number;
  type?: string | number;
  uploadDate?: string | number;
  size?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 证据 - field-deep aligned shell */
export const EvidenceCard: React.FC<EvidenceCardProps> = ({
  caseId,
  name,
  type,
  uploadDate,
  size,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="证据"
    status={status}
    fields={[
    { label: '案件', value: caseId },
    { label: '名称', value: name },
    { label: '类型', value: type },
    { label: '上传日期', value: uploadDate },
    { label: '大小', value: size },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default EvidenceCard;