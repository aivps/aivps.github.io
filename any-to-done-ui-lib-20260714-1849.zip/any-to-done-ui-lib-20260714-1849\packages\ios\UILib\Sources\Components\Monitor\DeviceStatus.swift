import SwiftUI

/// 监控设备 - monitor industry (SwiftUI)
public struct DeviceStatus: View {
    public var deviceId: String = ""
    public var name: String = ""
    public var location: String = ""
    public var online: String = ""
    public var status: String = ""

    public init(deviceId: String = "", name: String = "", location: String = "", online: String = "", status: String = "") {
        self.deviceId = deviceId
        self.name = name
        self.location = location
        self.online = online
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "监控设备",
            status: status.isEmpty ? nil : status,
            fields: [
            ("设备 ID", deviceId),
            ("名称", name),
            ("位置", location),
            ("在线", online),
            ]
        )
    }
}