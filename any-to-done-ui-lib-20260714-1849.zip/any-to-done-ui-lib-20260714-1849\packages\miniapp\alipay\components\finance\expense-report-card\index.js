/** 报销单 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'reportId': { type: String, value: '' },
    'reportName': { type: String, value: '' },
    'applicant': { type: String, value: '' },
    'department': { type: String, value: '' },
    'submitDate': { type: String, value: '' },
    'totalAmount': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});