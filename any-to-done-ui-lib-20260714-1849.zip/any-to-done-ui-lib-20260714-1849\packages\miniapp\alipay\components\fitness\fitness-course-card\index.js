/** 健身课 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'name': { type: String, value: '' },
    'coach': { type: String, value: '' },
    'time': { type: String, value: '' },
    'duration': { type: String, value: '' },
    'capacity': { type: String, value: '' },
    'enrolled': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
