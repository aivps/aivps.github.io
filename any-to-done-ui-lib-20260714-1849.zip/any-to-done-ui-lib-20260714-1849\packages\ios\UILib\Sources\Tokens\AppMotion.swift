import CoreGraphics

/// Motion tokens — press scale + duration (aligned with React motion).
public enum AppMotion {
    public static let durationFast: Double = 0.12
    public static let durationNormal: Double = 0.2
    public static let pressScale: CGFloat = 0.98
}
