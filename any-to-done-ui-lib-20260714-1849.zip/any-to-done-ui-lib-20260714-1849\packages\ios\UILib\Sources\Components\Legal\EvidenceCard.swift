import SwiftUI

/// 证据 - field-deep aligned shell (SwiftUI)
public struct EvidenceCard: View {
    public var caseId: String = ""
    public var name: String = ""
    public var type: String = ""
    public var uploadDate: String = ""
    public var size: String = ""
    public var status: String = ""

    public init(caseId: String = "", name: String = "", type: String = "", uploadDate: String = "", size: String = "", status: String = "") {
        self.caseId = caseId
        self.name = name
        self.type = type
        self.uploadDate = uploadDate
        self.size = size
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "证据",
            status: status.isEmpty ? nil : status,
            fields: [
            ("案件", caseId),
            ("名称", name),
            ("类型", type),
            ("上传日期", uploadDate),
            ("大小", size),
            ]
        )
    }
}