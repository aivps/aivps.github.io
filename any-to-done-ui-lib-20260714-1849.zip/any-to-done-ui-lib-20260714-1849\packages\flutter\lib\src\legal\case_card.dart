import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// CaseCard — field-deep aligned to React CaseCard.
class CaseCard extends StatelessWidget {
  final String id;
  final String caseNumber;
  final String caseType;
  final String title;
  final String client;
  final String? opposingParty;
  final String status; // pending | processing | trial | judgment | closed
  final String filingDate;
  final String? courtDate;
  final String? lawyer;
  final String? deadline;
  final String? nextStep;
  final String? court;
  final VoidCallback? onTap;
  final ValueChanged<String>? onDetail;
  final ValueChanged<String>? onUpdate;
  final bool disabled;

  /// @deprecated
  final String? caseNo;
  final String? type;
  final String? nextDate;

  const CaseCard({
    super.key,
    this.id = '',
    this.caseNumber = '',
    this.caseType = '',
    required this.title,
    required this.client,
    this.opposingParty,
    required this.status,
    this.filingDate = '',
    this.courtDate,
    this.lawyer,
    this.deadline,
    this.nextStep,
    this.court,
    this.onTap,
    this.onDetail,
    this.onUpdate,
    this.disabled = false,
    this.caseNo,
    this.type,
    this.nextDate,
  });

  String get _caseNumber =>
      caseNumber.isNotEmpty ? caseNumber : (caseNo ?? '');
  String get _caseType => caseType.isNotEmpty ? caseType : (type ?? '');
  String? get _courtDate => courtDate ?? nextDate;

  static const _statusLabels = {
    'pending': '待受理',
    'processing': '办理中',
    'trial': '审理中',
    'judgment': '待判决',
    'closed': '已结案',
    '待立案': '待受理',
    '审理中': '审理中',
    '已结案': '已结案',
    '已归档': '已结案',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'pending':
      case '待立案':
        return colors.warning;
      case 'processing':
      case 'trial':
      case '审理中':
        return colors.primary;
      case 'judgment':
        return colors.warning;
      case 'closed':
      case '已结案':
      case '已归档':
        return colors.success;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onDetail?.call(id);
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            if (_caseType.isNotEmpty)
                              Container(
                                margin: const EdgeInsets.only(right: 8),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: colors.primary.withValues(alpha: 0.1),
                                  borderRadius: AppSpacing.borderRadiusSm,
                                ),
                                child: Text(
                                  _caseType,
                                  style: AppTypography.caption
                                      .copyWith(color: colors.primary),
                                ),
                              ),
                            Text(_caseNumber, style: AppTypography.caption),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          title,
                          style: AppTypography.body
                              .copyWith(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style: AppTypography.caption.copyWith(color: sc),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text('当事人：$client', style: AppTypography.caption),
              Text('立案：$filingDate', style: AppTypography.caption),
              if (lawyer != null)
                Text('律师：$lawyer', style: AppTypography.caption),
              if (_courtDate != null)
                Text(
                  '开庭：$_courtDate',
                  style: AppTypography.caption.copyWith(color: colors.warning),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
