import SwiftUI

/// 会员 - field-deep aligned shell (SwiftUI)
public struct MemberCard: View {
    public var id: String = ""
    public var name: String = ""
    public var phone: String = ""
    public var cardType: String = ""
    public var expireDate: String = ""
    public var remainingSessions: String = ""
    public var status: String = ""

    public init(id: String = "", name: String = "", phone: String = "", cardType: String = "", expireDate: String = "", remainingSessions: String = "", status: String = "") {
        self.id = id
        self.name = name
        self.phone = phone
        self.cardType = cardType
        self.expireDate = expireDate
        self.remainingSessions = remainingSessions
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "会员",
            status: status.isEmpty ? nil : status,
            fields: [
                ("ID", id),
                ("名称", name),
                ("电话", phone),
                ("卡类型", cardType),
                ("到期日", expireDate),
                ("剩余次数", remainingSessions),
            ]
        )
    }
}
