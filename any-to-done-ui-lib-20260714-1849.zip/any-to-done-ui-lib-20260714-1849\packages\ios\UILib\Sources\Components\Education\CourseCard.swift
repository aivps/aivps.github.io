import SwiftUI

/// 课程 - field-deep aligned shell (SwiftUI)
public struct CourseCard: View {
    public var title: String = ""
    public var teacher: String = ""
    public var price: String = ""
    public var duration: String = ""
    public var studentCount: String = ""
    public var status: String = ""

    public init(title: String = "", teacher: String = "", price: String = "", duration: String = "", studentCount: String = "", status: String = "") {
        self.title = title
        self.teacher = teacher
        self.price = price
        self.duration = duration
        self.studentCount = studentCount
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "课程",
            status: status.isEmpty ? nil : status,
            fields: [
            ("标题", title),
            ("讲师", teacher),
            ("价格", price),
            ("时长", duration),
            ("学员数", studentCount),
            ]
        )
    }
}