/** 游戏房 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'roomNumber': { type: String, value: '' },
    'gameName': { type: String, value: '' },
    'playerCount': { type: String, value: '' },
    'maxPlayers': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
