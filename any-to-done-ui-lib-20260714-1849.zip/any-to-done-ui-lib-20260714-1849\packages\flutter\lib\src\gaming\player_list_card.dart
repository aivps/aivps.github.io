import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// PlayerItem — aligned to React PlayerItem
class PlayerItem {
  final String id;
  final String nickname;
  final String? avatar;
  final int level;
  final int coins;
  final String status; // online | offline | playing
  final int? wins;
  final int? losses;
  final bool isVip;
  final String? lastActive;

  const PlayerItem({
    this.id = '',
    required this.nickname,
    this.avatar,
    this.level = 0,
    this.coins = 0,
    this.status = 'offline',
    this.wins,
    this.losses,
    this.isVip = false,
    this.lastActive,
  });

  /// @deprecated name → nickname, score → coins
  factory PlayerItem.legacy({
    required String name,
    int? score,
    String status = 'offline',
    int level = 0,
    bool ready = false,
  }) {
    return PlayerItem(
      nickname: name,
      coins: score ?? 0,
      status: ready ? 'playing' : status,
      level: level,
    );
  }
}

/// @deprecated use PlayerItem
typedef PlayerInfo = PlayerItem;

/// PlayerListCard — field-deep aligned to React PlayerListCard.
class PlayerListCard extends StatelessWidget {
  final List<PlayerItem> players;
  final String title;
  final int? totalOnline;
  final VoidCallback? onTap;
  final ValueChanged<PlayerItem>? onPlayerClick;
  final ValueChanged<PlayerItem>? onBan;
  final bool disabled;

  const PlayerListCard({
    super.key,
    required this.players,
    this.title = '玩家列表',
    this.totalOnline,
    this.onTap,
    this.onPlayerClick,
    this.onBan,
    this.disabled = false,
  });

  static const _statusLabels = {
    'online': '在线',
    'offline': '离线',
    'playing': '游戏中',
    'away': '离线',
  };

  Color _statusColor(AppThemeColors colors, String status) {
    switch (status) {
      case 'online':
        return colors.success;
      case 'playing':
        return colors.primary;
      default:
        return colors.textDisabled;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final online = totalOnline ??
        players
            .where((p) => p.status == 'online' || p.status == 'playing')
            .length;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(title, style: AppTypography.h3),
                  Text('$online 在线',
                      style: AppTypography.caption
                          .copyWith(color: colors.success)),
                ],
              ),
              const SizedBox(height: 12),
              ...players.map((p) {
                final c = _statusColor(colors, p.status);
                final label = _statusLabels[p.status] ?? p.status;
                return InkWell(
                  onTap: disabled
                      ? null
                      : () => onPlayerClick?.call(p),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration:
                              BoxDecoration(shape: BoxShape.circle, color: c),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${p.nickname}${p.isVip ? ' ★' : ''}',
                                style: AppTypography.body
                                    .copyWith(fontWeight: FontWeight.w500),
                              ),
                              Text('Lv.${p.level} · ${p.coins}',
                                  style: AppTypography.caption),
                            ],
                          ),
                        ),
                        Text(label,
                            style: AppTypography.caption.copyWith(color: c)),
                        if (onBan != null)
                          TextButton(
                            onPressed: disabled ? null : () => onBan!(p),
                            child: const Text('封禁'),
                          ),
                      ],
                    ),
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
