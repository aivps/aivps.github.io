Component({
  properties: {
    value: { type: Number, value: 0 },
    min: { type: Number, value: 0 },
    max: { type: Number, value: 100 },
    step: { type: Number, value: 1 },
    disabled: { type: Boolean, value: false },
    showValue: { type: Boolean, value: false },
  },
  data: {},
  methods: {
    onChange(e) {
      this.triggerEvent('change', { value: e.detail.value });
    },
    onChanging(e) {
      this.triggerEvent('changing', { value: e.detail.value });
    },
  },
});
