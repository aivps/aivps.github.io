/**
 * 虚拟列表 card - advanced industry (Douyin Mini Program)
 */
Component({
  options: { addGlobalClass: true },
  properties: {
    'itemCount': { type: String, value: '' },
    'itemHeight': { type: String, value: '' },
    'height': { type: String, value: '' },
  },
  methods: {
    onTap() {
      this.triggerEvent('tap', { ...this.data });
    },
  },
});