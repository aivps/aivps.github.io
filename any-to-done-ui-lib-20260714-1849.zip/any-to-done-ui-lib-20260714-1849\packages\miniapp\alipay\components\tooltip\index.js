Component({
  properties: {
    content: { type: String, value: '' },
    position: { type: String, value: 'top' },
    show: { type: Boolean, value: false },
  },
  data: {},
  methods: {},
});
