import SwiftUI

/// 玩家 - field-deep aligned shell (SwiftUI)
public struct PlayerListCard: View {
    public var nickname: String = ""
    public var level: String = ""
    public var coins: String = ""
    public var status: String = ""

    public init(nickname: String = "", level: String = "", coins: String = "", status: String = "") {
        self.nickname = nickname
        self.level = level
        self.coins = coins
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "玩家",
            status: status.isEmpty ? nil : status,
            fields: [
                ("昵称", nickname),
                ("等级", level),
                ("金币", coins),
            ]
        )
    }
}
