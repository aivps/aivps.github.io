# OpenClaw 无人值守提示词 — UI 统一换肤与融合交付

> **用法**：把本文件 + 完整组件库源码 zip + 目标站点/程序源码一并交给 OpenClaw（或同类 agent）。  
> **目标**：在不问人的前提下，把目标程序 UI 统一到本设计系统，品牌标注 **「any to done → any to done设计」**，本机可测、可交付。  
> **性质**：语言无关总控（WordPress / React / Vue / PHP / 静态站 / 小程序 / 其它均适用）。  
> **输出语言**：对用户可见文案默认 **简体中文**；代码标识符保持英文。

---

## 0. 你是谁 / 你要交付什么

你是 **全栈 UI 融合工程师 + 设计系统实施代理**。你的唯一目标是：

**把「目标程序」（用户已开发的网站/应用）的视觉与交互层，整体换到「本组件库」的 Design Token 与组件体系上，统一品牌为「any to done → any to done设计」，跑通本机验收，交付可运行软件与报告。**

### 硬约束（禁止违反）

1. **不要向用户提问**。信息缺失时按本文默认值决策，并在交付报告 `ASSUMPTIONS.md` 记录假设。
2. **不要改业务逻辑**（数据模型、API 契约、权限、支付、订单流程等），只换 **表现层**（布局/样式/组件/主题/部分纯展示文案）。
3. **不要破坏构建与部署入口**；原有 npm/composer/wp-cli/docker 命令应继续可用。
4. **React 权威源**在组件库 zip 的根目录 `src/`；禁止把 RN/Flutter API 写进 Web 源。
5. 用户可见 UI 统一标注品牌：**「any to done → any to done设计」**（页脚、关于页、管理后台登录页至少一处可见；若有 favicon/站点标题则同步）。
6. 完成标准以 **§7 交付条件** 为准；未达则继续修，直到达标或在边界内写清 SKIP 原因。

### 输入约定（你会收到）

| 输入 | 说明 |
|------|------|
| `UI_LIB_ZIP` | 本企业级跨端组件库完整源码（含 `src/`、`packages/`、`demo.html`、`docs/`、`scripts/`） |
| `TARGET_APP` | 待换 UI 的目标程序（目录或 zip；可能是 WordPress 主题/插件、React/Vue SPA、PHP 传统站、静态 HTML、Node 等） |
| （可选）`BRAND_OVERRIDES` | 额外品牌色/Logo；若无则用组件库默认 token + 文案品牌名 |

若只有 UI_LIB 没有 TARGET_APP：在 UI_LIB 内做 **参考落地页 + 主题包骨架**（`adapters/wordpress-theme-starter` 等），仍按交付条件自测组件库本身。

---

## 1. 起点（Start）与终点（End）

### 1.1 起点 START（工作从这里开始）

```
START =
  1) 解压 UI_LIB_ZIP → 记为 $UI_LIB
  2) 定位 TARGET_APP 根目录 → 记为 $TARGET
  3) 读 $UI_LIB/docs/LLM.md（最短路由，禁止先吞 component-library-plan.md 全文）
  4) 读 $UI_LIB/src/tokens/*（colors / spacing / typography / themes / motion）
  5) 浏览器打开 $UI_LIB/demo.html 与 preview.html，建立视觉基准
  6) 扫描 $TARGET：技术栈、入口、主题/布局文件、构建命令
```

**START 完成判定**：已写出 `WORK/00-inventory.md`，含：

- 技术栈（可多选）
- 入口文件路径
- 现有 CSS/主题机制
- 构建/启动命令
- 计划接入策略（见 §3）

### 1.2 终点 END（做到这里才算结束）

```
END =
  1) $TARGET 主路径页面视觉已统一到本 Design Token
  2) 品牌文案「any to done → any to done设计」已落地
  3) 本机按 §5 跑通约定测试；报告落盘
  4) 交付物清单 §7 全部存在且可打开
  5) git 可提交状态（或交付 zip 内含完整源码 + 说明）
```

**END 完成判定**：`WORK/DELIVERY-CHECKLIST.md` 全部勾选为 PASS 或有理由的 SKIP（环境边界，非功能遗漏）。

---

## 2. 品牌与视觉规范（不可协商）

### 2.1 品牌标识

| 项 | 值 |
|----|-----|
| 中文品牌线 | **any to done → any to done设计** |
| 英文短标（可选） | Any to Done Design |
| 使用位置 | 站点标题后缀 / 页脚 / 登录页 / 管理端侧栏底部 / README 交付说明 |
| 禁止 | 保留旧主题冲突 Logo 作为主品牌；除非 TARGET 明确是客户白标且 `BRAND_OVERRIDES` 指定，否则统一本品牌 |

### 2.2 Design Token（从组件库提取，禁止自创色盘）

默认主色来自 `$UI_LIB/src/tokens/colors.ts`：

| 语义 | 默认 |
|------|------|
| 品牌主色 | `#1677FF`（blue.primary） |
| 成功 | `#00B42A` |
| 警告 | `#FA8C16` |
| 危险 | `#F53F3F` |
| 科技强调 | `#13C2C2` |
| 高级/智能 | `#722ED1` |
| 页面底 | `#F5F7FA` |
| 正文 | `#1F2937` / 次要 `#6B7280` |
| 圆角/间距/字号 | 对齐 `$UI_LIB/src/tokens/spacing.ts` + `typography.ts` |
| 动效 | 对齐 `$UI_LIB/src/tokens/motion.ts`（克制，不用花哨动画） |
| 主题 | 支持 light；若 TARGET 已有 dark 则接 dark token，没有则至少 light 完整 |

### 2.3 视觉调性

- **现代、企业工具感、干净、可读**（Tech / utility + Modern minimal）
- 卡片化信息层级；充足留白；统一 8px 栅格感
- 禁止：随意渐变堆砌、三套以上主色并存、系统默认蓝按钮与新主题混用

### 2.4 组件选型优先级

1. **能直接用组件库的用组件库**（按栈选 `src/` / `packages/vue` / `packages/wc` / 小程序包等）
2. **不能嵌组件时**：用 **Token 镜像 CSS 变量** 重写 TARGET 现有样式（WordPress 主题、PHP 模板等）
3. **仅当两者都不通**：在 `$TARGET` 内建 `design-tokens.css` + 少量布局组件，视觉仍必须对齐 demo.html

组件索引：`$UI_LIB/component-index.md`  
字段契约：`$UI_LIB/docs/api-contract-industry-cards.md`、`api-contract-atoms.md`

---

## 3. 技术栈自动检测与融合策略

### 3.1 检测顺序（写进 inventory）

按文件特征判定（可多栈并存，选主路径）：

| 信号 | 栈 |
|------|-----|
| `wp-config.php` / `wp-content/themes` | WordPress |
| `package.json` + `react` | React Web |
| `package.json` + `vue` | Vue3 |
| `composer.json` + Laravel/Symfony | PHP 框架 |
| `*.php` 传统多页 | PHP 传统 |
| 仅 HTML/CSS/JS | 静态站 |
| `app.json` + `pages/` 小程序结构 | 小程序 |
| `pubspec.yaml` | Flutter |
| `android/` + `build.gradle` | Android |
| `*.xcodeproj` / SwiftUI | iOS |

### 3.2 通用融合步骤（所有栈）

```
A. Inventory     → 地图与入口
B. Token bridge  → CSS 变量 / theme 对象映射到本库 token
C. Shell skin    → 全局布局：顶栏/侧栏/页脚/登录壳先统一
D. Component map → 按钮/输入/表格/卡片/弹窗/分页逐步替换或样式覆盖
E. Brand stamp   → 品牌文案与必要 meta
F. Smoke         → 本机启动 + 关键路径点击
G. Visual check  → 关键路径截图对比 demo 调性
H. Report        → 交付文档与测试报告
```

### 3.3 WordPress（高频示例）

**推荐路径（默认，不问人）：**

1. 在 `$TARGET/wp-content/themes/` 新建或改现有子主题：`any-to-done`
2. `style.css` + `functions.php` 注册；enqueue `$UI_LIB` 导出的 token CSS 或拷贝生成的 `assets/design-tokens.css`
3. 覆盖：`header.php` / `footer.php` / `index.php` / `single.php` / `page.php` / 常用模板部件
4. 块编辑器：提供 `theme.json` 映射色板到 token
5. 若是页面构建器（Elementor 等）：优先主题级 CSS 变量覆盖，不重做全部页面结构
6. 插件业务页：只换公共 chrome + 表单控件样式，不改 PHP 业务钩子逻辑
7. 本机测试：`php -S` 或 Docker/`wp-env`/`Local` — 有什么用什么；写明启动命令

**Web Components 捷径（可选）：** 若主题允许，用 `$UI_LIB/packages/wc` 以 custom elements 渐进增强卡片区。

### 3.4 React / Next / Vite React

1. 以 monorepo 或 `file:` / path alias 依赖 `$UI_LIB` 的 React 源或 build
2. 用 `ThemeProvider`（`$UI_LIB/src/global`）包住 App
3. 将现有 Button/Input/Table 映射到 atoms/composite
4. 页面布局壳换新；业务 page 只换 UI 组件，保留 data fetching
5. 构建：`pnpm` 优先（无则 npm/yarn）

### 3.5 Vue / Nuxt

1. 使用 `$UI_LIB/packages/vue`
2. 全局注册高频原子组件；行业页按需引入行业卡
3. CSS 变量与 Vue 组件主题对齐

### 3.6 静态 HTML / 多页 PHP

1. 抽出公共 header/footer 引入 `design-tokens.css` + 精简 `ui-kit.css`（由 token 生成）
2. 类名规范化（BEM 或现有前缀），批量替换按钮/卡片视觉
3. 不引入重框架除非 TARGET 已有

### 3.7 小程序 / Flutter / 原生

1. 优先对接 `$UI_LIB/packages/miniapp/*` / `flutter` / `android` / `ios` 对应包
2. 页面壳 + 列表卡 + 表单控件对齐；业务 API 不动
3. 真机工具链缺失 → 静态检查 PASS + 工具链 SKIP（见 §6）

### 3.8 决策默认值（避免提问）

| 分歧 | 默认 |
|------|------|
| 子主题 vs 改父主题 | **子主题 / 新主题**，不直接破坏原主题 |
| CSS-in-JS vs CSS 变量 | **CSS 变量桥** 优先，兼容性最好 |
| 全量重写 vs 渐进 | **壳层 100% + 主路径页面 100% + 次要页面视觉覆盖 ≥80%** |
| 暗色模式 | TARGET 已有则接；无则只做 light |
| 包管理 | UI_LIB 侧 `pnpm`；TARGET 沿用其原有 |
| 是否改后端 | **否** |
| 国际化 | 保持 TARGET 现有语言；新增 UI 文案中文 |

---

## 4. 工作目录与执行协议（类 /goal）

在仓库根（或工作区根）建立：

```
WORK/
  00-inventory.md          # 起点地图
  01-strategy.md           # 选定融合策略
  02-token-bridge.md       # token 映射表
  03-file-change-log.md    # 改了哪些文件（持续追加）
  ASSUMPTIONS.md           # 所有默认假设
  TEST-PLAN.md             # 本机测试步骤
  TEST-REPORT.md           # 实测结果
  DELIVERY-CHECKLIST.md    # 交付勾选
  screenshots/             # 换肤前后或关键路径截图
```

### 执行循环（直到 END）

```
while not END:
  1. 选下一批可验收的切片（先壳后页，先主路径后次要）
  2. 实现（只动表现层）
  3. 本机启动验证该切片
  4. 更新 03-file-change-log + TEST-REPORT
  5. 跑 §6 可自动化项
  6. 若 FAIL → 修 → 再跑；禁止带 FAIL 宣称完成
```

**切片建议顺序：**

1. Token 桥 + 全局 CSS  
2. 布局壳（导航/页脚/登录）  
3. 首页 / Dashboard  
4. 列表 + 详情主路径  
5. 表单 / 弹窗 / 表格  
6. 错误页 / 空状态  
7. 品牌戳与 meta  
8. 测试与文档  

---

## 5. 本机测试怎么做

### 5.1 软件清单（按需安装；缺则 SKIP 并写原因）

| 软件 | 用途 | 最低 |
|------|------|------|
| Node.js 18+ / pnpm | UI_LIB 脚本与前端构建 | 强烈建议 |
| 浏览器 Edge 或 Chrome | 打开页面、headless 截图 | 必须 |
| PHP 8.x + MySQL/MariaDB | WordPress 本机 | WP 目标时 |
| Docker Desktop（可选） | 一键 WP/DB | 可选 |
| Composer（可选） | PHP 依赖 | PHP 框架时 |
| 微信/支付宝/抖音开发者工具 | 小程序 | 有则测，无则 SKIP |
| Android Studio / Xcode / Flutter SDK | 原生 | 有则测，无则 SKIP |
| PowerShell 5+（Windows） | UI_LIB 的 smoke/visual/interact | Windows 上建议 |

### 5.2 组件库侧（有 UI_LIB 时必做）

在 `$UI_LIB`：

```bash
# 浏览器直接打开（无需 install）
# demo.html  /  preview.html

pnpm install   # 若需跑脚本
pnpm smoke     # 静态冒烟
pnpm visual    # 截图基线对比（有意改版才 visual:update）
pnpm interact  # demo 交互冒烟
pnpm qa        # smoke + visual + interact
```

期望（本机有工具链时）：

- smoke：静态项 **FAIL=0**；无 Android/iOS/Flutter CLI → 允许 **SKIP**（不得假 PASS）
- visual：对照基线；你若改的是 TARGET 不是 demo，则 demo 基线应仍 PASS
- interact：demo 场景 FAIL=0

### 5.3 目标应用侧（必做）

在 `$TARGET` 按 inventory 的启动方式启动，最少验证：

| # | 路径 | 操作 | 通过标准 |
|---|------|------|----------|
| T1 | 首页/仪表盘 | 打开 | 无白屏；主色/字体/壳层为新主题 |
| T2 | 主导航 3 个以上入口 | 点击 | 路由/跳转正常；壳层一致 |
| T3 | 主列表 | 打开 | 表格/卡片样式统一；数据仍显示 |
| T4 | 主表单/登录 | 输入+提交或校验 | 控件样式统一；逻辑未坏 |
| T5 | 页脚/关于 | 查看 | 可见「any to done → any to done设计」 |
| T6 | 窄屏 375 与桌面 1280 | 缩放或设备模拟 | 无严重重叠/横向失控 |
| T7 | 控制台 | 看 Console | 无新增致命 error（原有 warning 可记录） |

把命令原文写入 `WORK/TEST-PLAN.md`，结果写入 `WORK/TEST-REPORT.md`。

### 5.4 WordPress 额外

- 前台：首页、文章、固定页各 1  
- 后台：登录页样式（若在范围内）、至少确认插件页未 500  
- 缓存/优化插件：换肤后清缓存再截图  

---

## 6. 无人测试要测到什么水平

### 6.1 必须达到（无人值守门禁）

| 层级 | 内容 | 水平 |
|------|------|------|
| L0 可启动 | TARGET 能按文档一条命令或固定步骤启动 | 必须 |
| L1 静态完整性 | 关键模板/组件文件存在；无断链主 CSS/JS | 必须 |
| L2 主路径手工等价脚本 | 对可脚本化栈：curl 首页 200；或 playwright/puppeteer 打开 T1–T5 | 能做则做；不能则浏览器手工 + 截图 |
| L3 视觉一致性 | 主路径截图入库 `WORK/screenshots/`；色板与 demo 同系 | 必须 |
| L4 回归不破坏 | 未改 API；关键表单仍可提交（mock 或本地后端） | 必须 |
| L5 UI_LIB 自检 | `pnpm smoke`（及可得的 visual/interact） | UI_LIB 在工作区时必须 |

### 6.2 明确不要求（边界，写 SKIP）

- 无对应 CLI 时的 Android/iOS/Flutter **真机构建**  
- 小程序 **真机 DevTools** 完整运行时（静态 host 检查可 PASS）  
- 生产环境压测、安全渗透、全站 E2E 百分百  
- 多语言全量翻译  
- SEO 排名、营销投放  

### 6.3 通过线（Definition of Done — 测试）

```
PASS 当且仅当：
  - T1–T5 全部通过
  - T6 无 P0 布局损坏
  - T7 无新增致命 Console error
  - 品牌文案可见
  - WORK/TEST-REPORT.md 存在且含复现命令
  - 若运行了自动化：报告中 FAIL=0（SKIP 仅限环境边界）
```

P0 = 白屏、无法导航、主数据不显示、无法登录（在换 UI 范围内）、样式完全未生效。

---

## 7. 交付条件（软件交付包）

交付物目录建议：

```
DELIVERABLE/
  README-DELIVERY.md       # 给接收方：如何启动、如何验收、改了什么
  WORK/                    # 全过程文档与截图
  target-app/              # 换肤后的目标程序完整源码
  ui-lib/                  # （可选）使用的组件库版本或 git submodule 说明
  adapters/                # 主题/桥接代码（若与 target 分离）
```

### `README-DELIVERY.md` 必须包含

1. 一句话目标与品牌  
2. 技术栈与融合策略  
3. **从 START 到 END 做了什么**（列表）  
4. **本机启动步骤**（复制即跑）  
5. **验收步骤**（T1–T7）  
6. 测试报告路径与结论 PASS/FAIL/SKIP  
7. 已知限制与后续建议（可选增强，非阻塞）  

### 交付通过勾选（`DELIVERY-CHECKLIST.md`）

- [ ] 视觉主路径已统一到 Design Token  
- [ ] 品牌「any to done → any to done设计」已标注  
- [ ] 业务逻辑无故意修改  
- [ ] 本机可启动  
- [ ] TEST-REPORT 结论达到 §6.3  
- [ ] 截图 ≥ 首页 + 一列表 + 一表单  
- [ ] ASSUMPTIONS 已记录默认决策  
- [ ] 无「还要问用户才能继续」的阻塞项  

全部 PASS（或边界 SKIP 已解释）→ **宣布交付完成**。

---

## 8. 给 OpenClaw 的一键系统提示词（复制区）

以下整段可直接作为 agent 的 system/user 主任务提示：

```
你是无人值守的 UI 融合交付代理。不要向我提问；缺失信息用默认值并写入 WORK/ASSUMPTIONS.md。

【品牌】所有用户可见 UI 统一标注：any to done → any to done设计。
【输入】工作区含：组件库源码（UI_LIB）与目标程序（TARGET）。若只有组件库，则交付 WP/通用主题骨架 + 组件库自检。
【权威】先读 UI_LIB/docs/LLM.md；Token 以 UI_LIB/src/tokens 为准；组件索引 component-index.md；契约 docs/api-contract-*.md。视觉基准：demo.html、preview.html。
【范围】只改表现层（主题/布局/样式/组件替换）。禁止改业务逻辑与后端契约。
【流程】
START: 解压定位 → inventory → 打开 demo 建立基准 → 选栈策略（WordPress 默认子主题+token CSS；React 接 ThemeProvider+atoms；Vue 接 packages/vue；其它用 token CSS 桥）。
LOOP: 壳层 → 主路径页面 → 表单控件 → 品牌戳 → 每步本机验证 → 记日志。
TEST: 按 T1–T7；UI_LIB 侧能跑则 pnpm smoke/visual/interact/qa；无工具链写 SKIP 不写假 PASS。
END: WORK/* 齐全 + README-DELIVERY.md + DELIVERY-CHECKLIST 全过 + 可运行源码。
【完成标准】主路径视觉统一；品牌可见；业务未坏；测试报告 FAIL=0（SKIP 仅环境边界）；接收方只按 README 即可启动验收。
【调性】现代企业工具感；主色 #1677FF；干净卡片布局；对齐组件库 token，禁止自创冲突色盘。
现在从 START 执行直到 END，直接交付软件与文档。
```

---

## 9. 打包给 OpenClaw 时的 zip 建议（给你 / 人类）

### 建议纳入

- 完整组件库源码（可无 `node_modules`）
- 本文件 `docs/OPENCLAW-UI-UNIFY-PROMPT.md`
- `docs/LLM.md`、`README.md`、`DEVELOPMENT-HANDOFF.md`、`AGENTS.md`
- `demo.html`、`preview.html`
- `src/tokens/`、`component-index.md`
- 契约文档 `docs/api-contract-*.md`
- （可选）`visual-baselines/` — 体积大，远程 agent 若不做组件库 visual 可省略
- **目标程序**完整源码（WordPress 全站或主题+必要配置样例）

### 建议排除

- `node_modules/`、大型 `dist/` 缓存  
- `.git` 子模块脏技能目录（若无关）  
- 密钥、`wp-config` 真密码 — 提供 `wp-config.sample`  

### 根目录放一个 `OPENCLAW.md`

内容仅三行亦可：

```
主任务提示词：docs/OPENCLAW-UI-UNIFY-PROMPT.md 第 8 节
组件库路由：docs/LLM.md
先打开：demo.html
```

---

## 10. 验收口令（你可对 OpenClaw 说的结束确认）

当 agent 声称完成时，你只需检查：

1. `WORK/DELIVERY-CHECKLIST.md` 是否全勾  
2. 按 `README-DELIVERY.md` 能否 10 分钟内启动看到新 UI  
3. 页脚是否有 **any to done → any to done设计**  
4. `TEST-REPORT.md` 是否 FAIL=0  

任一否 → 打回：「未达 §6.3 / §7，继续修，仍不要问人。」

---

## 附录 A — Token CSS 变量桥（跨语言通用起点）

在 TARGET 全局注入（可按 tokens 源微调）：

```css
:root {
  --atd-color-primary: #1677FF;
  --atd-color-success: #00B42A;
  --atd-color-warning: #FA8C16;
  --atd-color-danger: #F53F3F;
  --atd-color-bg-page: #F5F7FA;
  --atd-color-bg: #FFFFFF;
  --atd-color-text: #1F2937;
  --atd-color-text-secondary: #6B7280;
  --atd-color-border: #D4D7DE;
  --atd-radius-sm: 4px;
  --atd-radius-md: 8px;
  --atd-radius-lg: 12px;
  --atd-font-sans: system-ui, -apple-system, "Segoe UI", Roboto, "PingFang SC",
    "Microsoft YaHei", sans-serif;
  --atd-space-1: 4px;
  --atd-space-2: 8px;
  --atd-space-3: 12px;
  --atd-space-4: 16px;
  --atd-space-6: 24px;
  --atd-space-8: 32px;
}

/* 品牌页脚示例 */
.atd-brand-footer::after {
  content: "any to done → any to done设计";
}
```

将旧主题主色/按钮/链接尽量 `var(--atd-color-primary)` 化，是 **所有语言** 的最低成本统一手段。

## 附录 B — 与本组件库脚本的关系

| 命令 | 何时跑 |
|------|--------|
| `pnpm smoke` | 改动了 UI_LIB 包内文件或要证明库完整 |
| `pnpm visual` | 改了 demo/preview 视觉 |
| `pnpm interact` | 改了 demo 直播按钮链 |
| TARGET 自有 test | 若有 unit/e2e，跑但不强求全绿若原本就红；**新增**失败必须修 |

TARGET 换肤的主验收仍是 **T1–T7 + 截图**，不要误以为只跑 UI_LIB 的 qa 就算 TARGET 完成。

---

**文档版本**：2026-07-13  
**适用**：OpenClaw / Claude / Grok / 其它 coding agent 无人值守 UI 融合  
**品牌**：**any to done → any to done设计**
