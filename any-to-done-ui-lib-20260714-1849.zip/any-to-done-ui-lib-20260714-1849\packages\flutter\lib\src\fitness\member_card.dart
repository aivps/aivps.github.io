import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// MemberCardInfo — aligned to React memberCard object
class MemberCardInfo {
  final String type;
  final String startDate;
  final String endDate;
  final int? remainingSessions;

  const MemberCardInfo({
    required this.type,
    this.startDate = '',
    required this.endDate,
    this.remainingSessions,
  });
}

/// MemberCard — field-deep aligned to React MemberCard.
/// status: active | expired | frozen | pending
class MemberCard extends StatelessWidget {
  final String id;
  final String name;
  final String phone;
  final String? avatar;
  final MemberCardInfo? memberCard;
  final String status;
  final String? lastVisit;
  final double? balance;
  final VoidCallback? onTap;
  final ValueChanged<String>? onBook;
  final ValueChanged<String>? onRenew;
  final ValueChanged<String>? onView;
  final bool disabled;

  /// @deprecated aliases
  final String? cardType;
  final String? expireDate;
  final int? remainTimes;
  final int? remainingSessions;

  const MemberCard({
    super.key,
    this.id = '',
    required this.name,
    this.phone = '',
    this.avatar,
    this.memberCard,
    required this.status,
    this.lastVisit,
    this.balance,
    this.onTap,
    this.onBook,
    this.onRenew,
    this.onView,
    this.disabled = false,
    this.cardType,
    this.expireDate,
    this.remainTimes,
    this.remainingSessions,
  });

  MemberCardInfo get _card {
    if (memberCard != null) return memberCard!;
    return MemberCardInfo(
      type: cardType ?? '',
      endDate: expireDate ?? '',
      remainingSessions: remainingSessions ?? remainTimes,
    );
  }

  static const _statusLabels = {
    'active': '有效',
    'expired': '已过期',
    'frozen': '冻结',
    'pending': '待续费',
    '正常': '有效',
    '有效': '有效',
    '冻结': '冻结',
    '过期': '已过期',
    '已过期': '已过期',
    '待续费': '待续费',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'active':
      case '正常':
      case '有效':
        return colors.success;
      case 'frozen':
      case '冻结':
        return colors.primary;
      case 'pending':
      case '待续费':
        return colors.warning;
      case 'expired':
      case '过期':
      case '已过期':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  bool get _isActive =>
      status == 'active' || status == '正常' || status == '有效';
  bool get _needsRenew =>
      status == 'expired' ||
      status == 'pending' ||
      status == '过期' ||
      status == '已过期' ||
      status == '待续费';

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final card = _card;
    final statusColor = _statusColor(colors);
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onView?.call(id);
              },
        child: Container(
          padding: AppSpacing.xl,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusXl,
            boxShadow: AppShadows.md,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name,
                          style: AppTypography.h2
                              .copyWith(color: colors.textPrimary)),
                      if (phone.isNotEmpty)
                        Text(phone,
                            style: AppTypography.body
                                .copyWith(color: colors.textSecondary)),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusLg,
                    ),
                    child: Text(_statusLabel,
                        style:
                            AppTypography.body.copyWith(color: statusColor)),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (card.type.isNotEmpty || card.endDate.isNotEmpty)
                Container(
                  padding: AppSpacing.md,
                  decoration: BoxDecoration(
                    color: colors.bgPage,
                    borderRadius: AppSpacing.borderRadiusMd,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (card.type.isNotEmpty)
                        Text(card.type,
                            style: AppTypography.body
                                .copyWith(color: colors.primary)),
                      if (card.endDate.isNotEmpty)
                        Text(
                          card.startDate.isNotEmpty
                              ? '${card.startDate} ~ ${card.endDate}'
                              : '到期: ${card.endDate}',
                          style: AppTypography.body
                              .copyWith(color: colors.textSecondary),
                        ),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  if (card.remainingSessions != null)
                    _buildStat('剩余次数', card.remainingSessions.toString()),
                  if (balance != null) _buildStat('账户余额', '¥$balance'),
                  if (lastVisit != null) _buildStat('上次到访', lastVisit!),
                ],
              ),
              if ((onBook != null && _isActive) ||
                  (onRenew != null && _needsRenew)) ...[
                const SizedBox(height: 12),
                Row(
                  children: [
                    if (onBook != null && _isActive)
                      Expanded(
                        child: ElevatedButton(
                          onPressed: disabled ? null : () => onBook!(id),
                          child: const Text('预约课程'),
                        ),
                      ),
                    if (onRenew != null && _needsRenew)
                      Expanded(
                        child: ElevatedButton(
                          onPressed: disabled ? null : () => onRenew!(id),
                          child: const Text('立即续费'),
                        ),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStat(String label, String value) {
    return Column(
      children: [
        Text(value, style: AppTypography.h3),
        Text(label, style: AppTypography.caption),
      ],
    );
  }
}
