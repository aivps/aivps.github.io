import 'package:flutter/material.dart';
import '../tokens/colors.dart';

/// 开关尺寸
enum SwitchSize {
  sm,
  md,
  lg,
}

/// AppSwitch 开关组件
class AppSwitch extends StatelessWidget {
  final bool value;
  final bool disabled;
  final SwitchSize size;
  final ValueChanged<bool>? onChanged;

  const AppSwitch({
    super.key,
    this.value = false,
    this.disabled = false,
    this.size = SwitchSize.md,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: disabled ? null : () => onChanged?.call(!value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: _getWidth(),
        height: _getHeight(),
        padding: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: value ? AppColors.primary : AppColors.gray300,
          borderRadius: BorderRadius.circular(_getHeight() / 2),
        ),
        child: AnimatedAlign(
          duration: const Duration(milliseconds: 200),
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            width: _getHeight() - 4,
            height: _getHeight() - 4,
            decoration: BoxDecoration(
              color: AppColors.gray0,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }

  double _getWidth() {
    switch (size) {
      case SwitchSize.sm:
        return 32;
      case SwitchSize.md:
        return 40;
      case SwitchSize.lg:
        return 52;
    }
  }

  double _getHeight() {
    switch (size) {
      case SwitchSize.sm:
        return 18;
      case SwitchSize.md:
        return 22;
      case SwitchSize.lg:
        return 28;
    }
  }
}
