package com.uilib.tokens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Semantic color tokens for light / dark (aligned with React lightTheme / darkTheme).
 */
data class UiColorScheme(
    val blue: Color = Color(0xFF1677FF),
    val blueLight: Color = Color(0xFFE6F4FF),
    val red: Color = Color(0xFFF53F3F),
    val green: Color = Color(0xFF00B42A),
    val purple: Color = Color(0xFF722ED1),
    val cyan: Color = Color(0xFF13C2C2),
    val orange: Color = Color(0xFFFA8C16),
    val surface: Color = Color(0xFFFFFFFF),
    val background: Color = Color(0xFFF5F7FA),
    val foreground: Color = Color(0xFF111827),
    val muted: Color = Color(0xFF6B7280),
    val border: Color = Color(0xFFE8E8E8),
    val gray100: Color = Color(0xFFF3F4F6),
    val gray200: Color = Color(0xFFE5E7EB),
    val gray700: Color = Color(0xFF374151),
    val gray900: Color = Color(0xFF111827),
    val primary: Color = Color(0xFF1677FF),
    val primaryBg: Color = Color(0xFFE6F4FF),
    val success: Color = Color(0xFF00B42A),
    val warning: Color = Color(0xFFFA8C16),
    val danger: Color = Color(0xFFF53F3F),
)

val LightColorScheme = UiColorScheme()

val DarkColorScheme = UiColorScheme(
    blue = Color(0xFF1668DC),
    blueLight = Color(0x261668DC),
    red = Color(0xFFDC4444),
    green = Color(0xFF49AA19),
    purple = Color(0xFF9254DE),
    cyan = Color(0xFF36CFC9),
    orange = Color(0xFFD89614),
    surface = Color(0xFF1F1F1F),
    background = Color(0xFF0A0A0A),
    foreground = Color(0xFFE8E8E8),
    muted = Color(0xFFA3A3A3),
    border = Color(0xFF303030),
    gray100 = Color(0xFF1F1F1F),
    gray200 = Color(0xFF303030),
    gray700 = Color(0xFFA3A3A3),
    gray900 = Color(0xFFE8E8E8),
    primary = Color(0xFF1668DC),
    primaryBg = Color(0x261668DC),
    success = Color(0xFF49AA19),
    warning = Color(0xFFD89614),
    danger = Color(0xFFDC4444),
)

val LocalUiColors = staticCompositionLocalOf { LightColorScheme }

/**
 * Backward-compatible static colors (light defaults).
 * Prefer [LocalUiColors] / [uiColors] inside Compose for dark mode.
 */
object AppColors {
    val Blue = LightColorScheme.blue
    val BlueLight = LightColorScheme.blueLight
    val Red = LightColorScheme.red
    val Green = LightColorScheme.green
    val Purple = LightColorScheme.purple
    val Cyan = LightColorScheme.cyan
    val Orange = LightColorScheme.orange
    val Surface = LightColorScheme.surface
    val Background = LightColorScheme.background
    val Foreground = LightColorScheme.foreground
    val Muted = LightColorScheme.muted
    val Border = LightColorScheme.border
    val Gray100 = LightColorScheme.gray100
    val Gray200 = LightColorScheme.gray200
    val Gray700 = LightColorScheme.gray700
    val Gray900 = LightColorScheme.gray900
}

val uiColors: UiColorScheme
    @Composable
    @ReadOnlyComposable
    get() = LocalUiColors.current
