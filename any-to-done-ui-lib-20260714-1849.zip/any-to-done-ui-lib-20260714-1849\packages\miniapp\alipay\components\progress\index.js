Component({
  properties: {
    percent: { type: Number, value: 0 },
    status: { type: String, value: 'normal' },
    size: { type: String, value: 'md' },
    showText: { type: Boolean, value: true },
    color: { type: String, value: '' },
  },
  data: {},
  methods: {},
});
