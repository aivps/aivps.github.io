import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// InventoryCard — field-deep aligned to React InventoryCard.
class InventoryCard extends StatelessWidget {
  final String id;
  final String name;
  final String sku;
  final int quantity;
  final String unit;
  final String? location;
  final int warningThreshold;
  final String? status; // normal | low | out
  final VoidCallback? onTap;
  final ValueChanged<String>? onReorder;
  final ValueChanged<String>? onView;
  final bool disabled;

  /// @deprecated
  final String? warehouse;
  final int? minStock;

  const InventoryCard({
    super.key,
    this.id = '',
    required this.name,
    required this.sku,
    required this.quantity,
    required this.unit,
    this.location,
    this.warningThreshold = 10,
    this.status,
    this.onTap,
    this.onReorder,
    this.onView,
    this.disabled = false,
    this.warehouse,
    this.minStock,
  });

  String? get _location => location ?? warehouse;
  int get _threshold => minStock ?? warningThreshold;

  String get _status {
    if (status != null) return status!;
    if (quantity <= 0) return 'out';
    if (quantity <= _threshold) return 'low';
    return 'normal';
  }

  static const _statusLabels = {
    'normal': '正常',
    'low': '库存预警',
    'out': '缺货',
  };

  String get _statusLabel => _statusLabels[_status] ?? _status;

  Color _statusColor(AppThemeColors colors) {
    switch (_status) {
      case 'low':
        return colors.warning;
      case 'out':
        return colors.danger;
      default:
        return colors.success;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onView?.call(id);
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: AppTypography.body
                              .copyWith(fontWeight: FontWeight.w600),
                        ),
                        Text('SKU: $sku', style: AppTypography.caption),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style: AppTypography.caption.copyWith(color: sc),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                '$quantity $unit',
                style: AppTypography.h3,
              ),
              Text(
                '预警 $_threshold${_location != null ? ' · $_location' : ''}',
                style: AppTypography.caption,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
