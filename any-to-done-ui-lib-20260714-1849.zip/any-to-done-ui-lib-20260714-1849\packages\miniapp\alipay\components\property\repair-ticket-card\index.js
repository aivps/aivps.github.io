/** 报修单 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'title': { type: String, value: '' },
    'location': { type: String, value: '' },
    'priority': { type: String, value: '' },
    'status': { type: String, value: '' },
    'reporter': { type: String, value: '' },
    'assignee': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
