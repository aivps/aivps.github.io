import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface PropertyCardProps {
  id?: string | number;
  title?: string | number;
  price?: string | number;
  area?: string | number;
  rooms?: string | number;
  address?: string | number;
  status?: string;
  /** @deprecated use title */
  name?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 房源 - field-deep aligned shell */
export const PropertyCard: React.FC<PropertyCardProps> = ({
  id,
  title,
  price,
  area,
  rooms,
  address,
  status,
  name,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="房源"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '标题', value: title ?? name },
      { label: '价格', value: price },
      { label: '面积', value: area },
      { label: '户型', value: rooms },
      { label: '地址', value: address },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default PropertyCard;
