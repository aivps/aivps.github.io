/// 企业级跨端UI组件库 - Flutter版本
library enterprise_ui_components;

// Design Tokens
export 'src/tokens/index.dart';

// Global
export 'src/global/theme_provider.dart';

// Atoms
export 'src/atoms/index.dart' hide AppCard;

// Composite
export 'src/composite/index.dart';

// Industry components
export 'src/medical/index.dart';
export 'src/finance/index.dart';
export 'src/ecommerce/index.dart';
export 'src/hardware/index.dart';
export 'src/manufacturing/index.dart';
export 'src/wedding/index.dart';
export 'src/legal/index.dart';
export 'src/fitness/index.dart' hide CourseCard;
export 'src/property/index.dart';
export 'src/education/index.dart';
export 'src/logistics/index.dart';
export 'src/it-service/index.dart';
export 'src/esign/index.dart';
export 'src/video/index.dart';
export 'src/erp/index.dart';
export 'src/bath/index.dart';
export 'src/gaming/index.dart';
export 'src/advertising/index.dart';
export 'src/children/index.dart';
export 'src/k12/index.dart';
export 'src/monitor/index.dart';
export 'src/workflow/index.dart';
export 'src/bi/index.dart';
export 'src/advanced/index.dart';
export 'src/portrait/index.dart';
export 'src/tools/index.dart';

// Version
const String version = '1.0.0';