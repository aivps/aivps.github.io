import SwiftUI

/// 虚拟列表 - advanced industry (SwiftUI)
public struct VirtualList: View {
    public var itemCount: String = ""
    public var itemHeight: String = ""
    public var overscan: String = ""

    public init(itemCount: String = "", itemHeight: String = "", overscan: String = "") {
        self.itemCount = itemCount
        self.itemHeight = itemHeight
        self.overscan = overscan
    }

    public var body: some View {
        IndustryCardShell(
            title: "虚拟列表",
            status: nil,
            fields: [
            ("条目数", itemCount),
            ("条目高度", itemHeight),
            ("预渲染", overscan),
            ]
        )
    }
}