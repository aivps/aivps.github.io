import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// MedicalRecordCard — field-deep aligned to React MedicalRecordCard.
/// Canonical: flat props + English recordType. Legacy Chinese type labels accepted.
class MedicalRecordCard extends StatelessWidget {
  final String recordId;
  final String patientName;
  final String patientId;
  final String recordType; // visit | admission | ...
  final String date;
  final String? department;
  final String? doctor;
  final String? diagnosis;
  final String? notes;
  final VoidCallback? onTap;
  final VoidCallback? onView;
  final bool disabled;

  const MedicalRecordCard({
    super.key,
    required this.recordId,
    required this.patientName,
    required this.patientId,
    required this.recordType,
    required this.date,
    this.department,
    this.doctor,
    this.diagnosis,
    this.notes,
    this.onTap,
    this.onView,
    this.disabled = false,
  });

  static const _typeLabels = {
    'visit': '门诊记录',
    'admission': '住院记录',
    'surgery': '手术记录',
    'lab': '检验报告',
    'imaging': '影像报告',
    'prescription': '处方',
    '门诊记录': '门诊记录',
    '住院记录': '住院记录',
    '手术记录': '手术记录',
    '检验报告': '检验报告',
    '影像报告': '影像报告',
    '处方': '处方',
  };

  String get _typeLabel => _typeLabels[recordType] ?? recordType;

  Color _typeColor(AppThemeColors colors) {
    switch (recordType) {
      case 'visit':
      case '门诊记录':
        return colors.primary;
      case 'admission':
      case '住院记录':
        return colors.primary;
      case 'surgery':
      case '手术记录':
        return colors.danger;
      case 'lab':
      case '检验报告':
        return colors.success;
      case 'imaging':
      case '影像报告':
        return colors.primary;
      case 'prescription':
      case '处方':
        return colors.warning;
      default:
        return colors.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final typeColor = _typeColor(colors);
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : (onTap ?? onView),
        child: Semantics(
          button: onTap != null || onView != null,
          label: '病历 $patientName $_typeLabel',
          child: Container(
            padding: AppSpacing.lg,
            decoration: BoxDecoration(
              color: colors.surface,
              borderRadius: AppSpacing.borderRadiusLg,
              boxShadow: AppShadows.sm,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: typeColor.withValues(alpha: 0.1),
                        borderRadius: AppSpacing.borderRadiusSm,
                      ),
                      child: Text(
                        _typeLabel,
                        style:
                            AppTypography.caption.copyWith(color: typeColor),
                      ),
                    ),
                    const Spacer(),
                    Text(date,
                        style:
                            AppTypography.caption.copyWith(color: colors.muted)),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  patientName,
                  style:
                      AppTypography.h3.copyWith(color: colors.textPrimary),
                ),
                Text(
                  '病历号: $patientId · 记录ID: $recordId',
                  style:
                      AppTypography.caption.copyWith(color: colors.muted),
                ),
                const SizedBox(height: 8),
                if (department != null)
                  _row(colors, '科室', department!),
                if (doctor != null) _row(colors, '医生', doctor!),
                if (diagnosis != null) _row(colors, '诊断', diagnosis!),
                if (notes != null) _row(colors, '备注', notes!),
                if (onView != null)
                  TextButton(
                    onPressed: disabled ? null : onView,
                    child: const Text('查看'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(AppThemeColors colors, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: AppTypography.caption.copyWith(color: colors.muted)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style:
                  AppTypography.body.copyWith(color: colors.textPrimary),
            ),
          ),
        ],
      ),
    );
  }
}
