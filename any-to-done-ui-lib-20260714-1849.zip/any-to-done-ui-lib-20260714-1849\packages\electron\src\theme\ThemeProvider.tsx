/**
 * Electron ThemeProvider — light/dark mode with CSS variables.
 */

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  applyThemeToDocument,
  darkTheme,
  getThemeColors,
  lightTheme,
  type SemanticColors,
  type ThemeMode,
} from '../tokens';

export interface ThemeContextValue {
  mode: ThemeMode;
  colors: SemanticColors;
  isDark: boolean;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

export interface ThemeProviderProps {
  children: React.ReactNode;
  defaultMode?: ThemeMode;
  storageKey?: string;
  /** When true, sync CSS vars onto documentElement (desktop shell) */
  applyToDocument?: boolean;
}

export function ThemeProvider({
  children,
  defaultMode = 'light',
  storageKey = 'ui-lib-electron-theme',
  applyToDocument = true,
}: ThemeProviderProps) {
  const [mode, setModeState] = useState<ThemeMode>(() => {
    if (typeof window === 'undefined') return defaultMode;
    const saved = localStorage.getItem(storageKey);
    if (saved === 'light' || saved === 'dark') return saved;
    if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) return 'dark';
    return defaultMode;
  });

  useEffect(() => {
    if (!applyToDocument || typeof document === 'undefined') return;
    applyThemeToDocument(mode);
  }, [mode, applyToDocument]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = (e: MediaQueryListEvent) => {
      if (!localStorage.getItem(storageKey)) {
        setModeState(e.matches ? 'dark' : 'light');
      }
    };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [storageKey]);

  const setMode = useCallback(
    (next: ThemeMode) => {
      setModeState(next);
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem(storageKey, next);
      }
    },
    [storageKey]
  );

  const toggleMode = useCallback(() => {
    setMode(mode === 'dark' ? 'light' : 'dark');
  }, [mode, setMode]);

  const value = useMemo<ThemeContextValue>(
    () => ({
      mode,
      colors: getThemeColors(mode),
      isDark: mode === 'dark',
      setMode,
      toggleMode,
    }),
    [mode, setMode, toggleMode]
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    return {
      mode: 'light',
      colors: lightTheme,
      isDark: false,
      setMode: () => {},
      toggleMode: () => {},
    };
  }
  return ctx;
}

export { lightTheme, darkTheme };
export default ThemeProvider;
