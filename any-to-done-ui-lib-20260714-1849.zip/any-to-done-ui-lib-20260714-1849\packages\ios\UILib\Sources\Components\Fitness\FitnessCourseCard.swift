import SwiftUI

/// 健身课 - field-deep aligned shell (SwiftUI)
public struct FitnessCourseCard: View {
    public var name: String = ""
    public var coach: String = ""
    public var time: String = ""
    public var duration: String = ""
    public var capacity: String = ""
    public var enrolled: String = ""
    public var status: String = ""

    public init(name: String = "", coach: String = "", time: String = "", duration: String = "", capacity: String = "", enrolled: String = "", status: String = "") {
        self.name = name
        self.coach = coach
        self.time = time
        self.duration = duration
        self.capacity = capacity
        self.enrolled = enrolled
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "健身课",
            status: status.isEmpty ? nil : status,
            fields: [
                ("名称", name),
                ("教练", coach),
                ("时间", time),
                ("时长", duration),
                ("容量", capacity),
                ("已报", enrolled),
            ]
        )
    }
}
