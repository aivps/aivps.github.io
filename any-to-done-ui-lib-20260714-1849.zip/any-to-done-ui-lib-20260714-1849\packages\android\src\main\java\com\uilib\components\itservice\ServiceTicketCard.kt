﻿package com.uilib.components.itservice

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 服务单 - field-deep aligned shell (Compose) */
@Composable
fun ServiceTicketCard(
    id: String = "",
    ticketNumber: String = "",
    title: String = "",
    priority: String = "",
    assignee: String = "",
    status: String = "",
    client: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "服务单",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "工单号" to ticketNumber,
            "标题" to title,
            "优先级" to priority,
            "处理人" to assignee,
            "客户" to client,
        ),
        modifier = modifier,
    )
}
