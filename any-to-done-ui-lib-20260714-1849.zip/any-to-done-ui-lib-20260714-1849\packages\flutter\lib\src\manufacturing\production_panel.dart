import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// ProductionPanel - manufacturing summary panel (UTF-8 safe).
class ProductionPanel extends StatelessWidget {
  final String title;
  final String status;
  final double completion;
  final int? planned;
  final int? actual;
  final VoidCallback? onTap;
  final bool disabled;

  const ProductionPanel({
    super.key,
    this.title = 'Production',
    required this.status,
    this.completion = 0,
    this.planned,
    this.actual,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final pct = completion.clamp(0.0, 1.0);
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: colors.foreground),
                    ),
                  ),
                  Text(status, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: colors.primary)),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(AppRadius.sm),
                child: LinearProgressIndicator(
                  value: pct,
                  minHeight: 8,
                  backgroundColor: colors.border,
                  color: colors.primary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                [
                  'Completion ${(pct * 100).toStringAsFixed(0)}%',
                  if (planned != null) 'Plan $planned',
                  if (actual != null) 'Actual $actual',
                ].join(' · '),
                style: TextStyle(fontSize: 13, color: colors.muted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
