import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface StudentRecordCardProps {
  name?: string;
  studentId?: string;
  grade?: string;
  className?: string;
  status?: string;
  onClick?: () => void;
}

/** StudentRecordCard - Electron shell (field keys aligned to React) */
export const StudentRecordCard: React.FC<StudentRecordCardProps> = (props) => (
  <IndustryCardShell title="StudentRecordCard" status={props.status} onClick={props.onClick}>
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.studentId ? <div className="row"><span className="label">studentId</span><span>{props.studentId}</span></div> : null}
      {props.grade ? <div className="row"><span className="label">grade</span><span>{props.grade}</span></div> : null}
      {props.className ? <div className="row"><span className="label">className</span><span>{props.className}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default StudentRecordCard;