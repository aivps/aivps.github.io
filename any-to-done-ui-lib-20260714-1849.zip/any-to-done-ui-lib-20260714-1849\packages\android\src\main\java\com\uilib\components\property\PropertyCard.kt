﻿package com.uilib.components.property

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 房源 - field-deep aligned shell (Compose) */
@Composable
fun PropertyCard(
    id: String = "",
    title: String = "",
    price: String = "",
    area: String = "",
    rooms: String = "",
    address: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "房源",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "标题" to title,
            "价格" to price,
            "面积" to area,
            "户型" to rooms,
            "地址" to address,
        ),
        modifier = modifier,
    )
}
