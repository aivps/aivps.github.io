import 'package:flutter/material.dart';
import '../tokens/colors.dart';

class AppPagination extends StatelessWidget {
  final int current;
  final int total;
  final int pageSize;
  final ValueChanged<int> onChanged;
  final bool showTotal;

  const AppPagination({
    super.key,
    required this.current,
    required this.total,
    required this.onChanged,
    this.pageSize = 10,
    this.showTotal = false,
  });

  int get totalPages => (total / pageSize).ceil();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (showTotal)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Text('共 $total 条', style: TextStyle(fontSize: 13, color: Colors.grey[500])),
          ),
        _buildBtn(Icons.chevron_left, current > 1 ? () => onChanged(current - 1) : null),
        ...List.generate(totalPages.clamp(0, 7), (i) {
          final page = i + 1;
          final isActive = page == current;
          return GestureDetector(
            onTap: isActive ? null : () => onChanged(page),
            child: Container(
              width: 36,
              height: 36,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              decoration: BoxDecoration(
                color: isActive ? AppColors.primary : Colors.transparent,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: isActive ? AppColors.primary : Colors.grey[300]!),
              ),
              alignment: Alignment.center,
              child: Text(
                '$page',
                style: TextStyle(
                  fontSize: 14,
                  color: isActive ? Colors.white : Colors.grey[700],
                  fontWeight: isActive ? FontWeight.w500 : FontWeight.normal,
                ),
              ),
            ),
          );
        }),
        _buildBtn(Icons.chevron_right, current < totalPages ? () => onChanged(current + 1) : null),
      ],
    );
  }

  Widget _buildBtn(IconData icon, VoidCallback? onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey[300]!),
          borderRadius: BorderRadius.circular(6),
        ),
        alignment: Alignment.center,
        child: Icon(icon, size: 18, color: onTap != null ? Colors.grey[700] : Colors.grey[400]),
      ),
    );
  }
}
