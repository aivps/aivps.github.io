import 'package:flutter/material.dart';
import '../tokens/breakpoints.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';
import '../tokens/motion.dart';

/// Canonical variants (React-aligned).
/// Legacy: [outline] → secondary outline visual; [link] → text.
enum ButtonVariant {
  primary,
  secondary,
  text,
  danger,
  ghost,

  /// @deprecated maps to secondary with outline stroke
  outline,

  /// @deprecated maps to text
  link,
}

/// Canonical sizes (React-aligned), includes xs.
enum ButtonSize {
  xs,
  sm,
  md,
  lg,
}

/// Platform shape extension. Prefer [circle] bool for React parity.
enum ButtonShape {
  defaultShape,
  circle,
  round,
}

/// AppButton — shallow API aligned to React Button + light press scale.
class AppButton extends StatefulWidget {
  final ButtonVariant variant;
  final ButtonSize size;
  final ButtonShape shape;

  /// React-aligned circular button (overrides shape when true).
  final bool circle;
  final bool disabled;
  final bool loading;
  final bool error;
  final Widget? icon;
  final IconData? iconData;

  /// React-aligned: left | right via [iconLeft] (true = left).
  final bool iconLeft;
  final String iconPosition;
  final bool block;
  final VoidCallback? onPressed;
  final Widget child;

  const AppButton({
    super.key,
    this.variant = ButtonVariant.primary,
    this.size = ButtonSize.md,
    this.shape = ButtonShape.defaultShape,
    this.circle = false,
    this.disabled = false,
    this.loading = false,
    this.error = false,
    this.icon,
    this.iconData,
    this.iconLeft = true,
    this.iconPosition = 'left',
    this.block = false,
    this.onPressed,
    required this.child,
  });

  @override
  State<AppButton> createState() => _AppButtonState();
}

class _AppButtonState extends State<AppButton> {
  bool _pressed = false;

  ButtonVariant get _variant {
    switch (widget.variant) {
      case ButtonVariant.outline:
        return ButtonVariant.secondary;
      case ButtonVariant.link:
        return ButtonVariant.text;
      default:
        return widget.variant;
    }
  }

  bool get _isOutlineLegacy => widget.variant == ButtonVariant.outline;
  bool get _iconOnLeft => widget.iconPosition == 'left' && widget.iconLeft;

  @override
  Widget build(BuildContext context) {
    final isDisabled = widget.disabled || widget.loading;

    return SizedBox(
      width: widget.block ? double.infinity : null,
      height: _getHeight(),
      child: AnimatedScale(
        scale: _pressed && !isDisabled ? AppMotion.pressScale : 1,
        duration: AppMotion.fast,
        curve: Curves.easeOutCubic,
        child: Listener(
          onPointerDown: isDisabled ? null : (_) => setState(() => _pressed = true),
          onPointerUp: (_) => setState(() => _pressed = false),
          onPointerCancel: (_) => setState(() => _pressed = false),
          child: ElevatedButton(
            onPressed: isDisabled ? null : widget.onPressed,
            style: _getButtonStyle(),
            child: _buildChild(),
          ),
        ),
      ),
    );
  }

  Widget _buildChild() {
    if (widget.loading) {
      return SizedBox(
        width: 16,
        height: 16,
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation<Color>(_getTextColor()),
        ),
      );
    }

    final widgets = <Widget>[];

    if (widget.icon != null) {
      widgets.add(widget.icon!);
    } else if (widget.iconData != null) {
      widgets.add(Icon(widget.iconData, size: _getIconSize()));
    }

    widgets.add(widget.child);

    if (widget.icon != null || widget.iconData != null) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: _iconOnLeft ? widgets : widgets.reversed.toList(),
      );
    }

    return widget.child;
  }

  double _getHeight() {
    switch (widget.size) {
      case ButtonSize.xs:
        return 24;
      case ButtonSize.sm:
        return 32;
      case ButtonSize.md:
        return 40;
      case ButtonSize.lg:
        return TouchTargets.comfortable;
    }
  }

  double _getIconSize() {
    switch (widget.size) {
      case ButtonSize.xs:
        return 12;
      case ButtonSize.sm:
        return 14;
      case ButtonSize.md:
        return 16;
      case ButtonSize.lg:
        return 20;
    }
  }

  ButtonStyle _getButtonStyle() {
    final color = _getColor();
    final textColor = _getTextColor();
    final borderRadius = _getBorderRadius();
    final needsBorder = _isOutlineLegacy ||
        _variant == ButtonVariant.secondary ||
        widget.error;

    return ElevatedButton.styleFrom(
      backgroundColor: color,
      foregroundColor: textColor,
      disabledBackgroundColor: color.withValues(alpha: 0.5),
      disabledForegroundColor: textColor.withValues(alpha: 0.5),
      elevation: 0,
      padding: _getPadding(),
      animationDuration: AppMotion.fast,
      side: needsBorder
          ? BorderSide(
              color: widget.error
                  ? AppColors.danger
                  : (_isOutlineLegacy || _variant == ButtonVariant.secondary)
                      ? AppColors.gray300
                      : Colors.transparent,
            )
          : BorderSide.none,
      shape: RoundedRectangleBorder(
        borderRadius: borderRadius,
      ),
    );
  }

  Color _getColor() {
    switch (_variant) {
      case ButtonVariant.primary:
        return AppColors.primary;
      case ButtonVariant.secondary:
        return _isOutlineLegacy ? Colors.transparent : AppColors.gray0;
      case ButtonVariant.ghost:
        return Colors.transparent;
      case ButtonVariant.danger:
        return AppColors.danger;
      case ButtonVariant.text:
        return Colors.transparent;
      case ButtonVariant.outline:
      case ButtonVariant.link:
        return Colors.transparent;
    }
  }

  Color _getTextColor() {
    switch (_variant) {
      case ButtonVariant.primary:
        return AppColors.gray0;
      case ButtonVariant.secondary:
        return AppColors.gray900;
      case ButtonVariant.ghost:
        return AppColors.gray900;
      case ButtonVariant.danger:
        return AppColors.gray0;
      case ButtonVariant.text:
        return AppColors.primary;
      case ButtonVariant.outline:
        return AppColors.gray900;
      case ButtonVariant.link:
        return AppColors.primary;
    }
  }

  BorderRadius _getBorderRadius() {
    final isCircle = widget.circle || widget.shape == ButtonShape.circle;
    if (isCircle || widget.shape == ButtonShape.round) {
      return BorderRadius.circular(999);
    }
    return BorderRadius.circular(AppRadius.base);
  }

  EdgeInsets _getPadding() {
    if (widget.circle || widget.shape == ButtonShape.circle) {
      return EdgeInsets.zero;
    }
    switch (widget.size) {
      case ButtonSize.xs:
        return const EdgeInsets.symmetric(horizontal: 8);
      case ButtonSize.sm:
        return const EdgeInsets.symmetric(horizontal: AppSpacing.mdValue);
      case ButtonSize.md:
        return const EdgeInsets.symmetric(horizontal: AppSpacing.base);
      case ButtonSize.lg:
        return const EdgeInsets.symmetric(horizontal: AppSpacing.lgValue);
    }
  }
}
