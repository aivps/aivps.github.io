package com.uilib.components.medical

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 病历 - industry (Compose, field-deep aligned) */
@Composable
fun MedicalRecordCard(
    recordId: String = "",
    patientName: String = "",
    patientId: String = "",
    recordType: String = "",
    date: String = "",
    department: String = "",
    doctor: String = "",
    diagnosis: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "病历",
        status = status.ifBlank { null },
        fields = listOf(
            "记录ID" to recordId,
            "患者" to patientName,
            "患者ID" to patientId,
            "类型" to recordType,
            "日期" to date,
            "科室" to department,
            "医生" to doctor,
            "诊断" to diagnosis,
        ),
        modifier = modifier,
    )
}
