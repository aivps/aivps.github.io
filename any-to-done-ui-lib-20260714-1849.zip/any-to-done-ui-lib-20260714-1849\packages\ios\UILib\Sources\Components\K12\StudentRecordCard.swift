import SwiftUI

/// 学籍 - k12 industry (SwiftUI)
public struct StudentRecordCard: View {
    public var name: String = ""
    public var studentId: String = ""
    public var grade: String = ""
    public var className: String = ""
    public var status: String = ""

    public init(name: String = "", studentId: String = "", grade: String = "", className: String = "", status: String = "") {
        self.name = name
        self.studentId = studentId
        self.grade = grade
        self.className = className
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "学籍",
            status: status.isEmpty ? nil : status,
            fields: [
            ("名称", name),
            ("学号", studentId),
            ("年级", grade),
            ("班级", className),
            ]
        )
    }
}