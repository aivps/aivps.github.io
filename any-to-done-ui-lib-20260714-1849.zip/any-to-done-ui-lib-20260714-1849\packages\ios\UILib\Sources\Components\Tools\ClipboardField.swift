import SwiftUI

/// 剪贴板 - tools industry (SwiftUI)
public struct ClipboardField: View {
    public var label: String = ""
    public var value: String = ""

    public init(label: String = "", value: String = "") {
        self.label = label
        self.value = value
    }

    public var body: some View {
        IndustryCardShell(
            title: "剪贴板",
            status: nil,
            fields: [
            ("标签", label),
            ("数值", value),
            ]
        )
    }
}