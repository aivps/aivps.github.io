/** 购物车项 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'price': { type: String, value: '' },
    'quantity': { type: String, value: '' },
    'sku': { type: String, value: '' },
    'selected': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
