import 'package:flutter/material.dart';

/// ServerStatus - field-deep aligned to React src/monitor
class ServerStatus extends StatelessWidget {
  final String? id;
  final String? name;
  final String? ip;
  final String? cpu;
  final String? memory;
  final String? disk;
  final String? status;
  final String? uptime;
  final VoidCallback? onTap;
  final bool disabled;

  const ServerStatus({
    super.key,
    this.id,
    this.name,
    this.ip,
    this.cpu,
    this.memory,
    this.disk,
    this.status,
    this.uptime,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF1F1F1F) : Colors.white;
    final border = isDark ? const Color(0xFF303030) : const Color(0xFFE8E8E8);
    final muted = const Color(0xFF8C8C8C);
    final fg = isDark ? const Color(0xFFE8E8E8) : const Color(0xFF262626);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Material(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ServerStatus', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: fg)),
                const SizedBox(height: 12),
                if (id != null && id!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('id', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(id!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (name != null && name!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('name', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(name!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (ip != null && ip!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('ip', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(ip!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (cpu != null && cpu!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('cpu', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(cpu!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (memory != null && memory!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('memory', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(memory!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (disk != null && disk!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('disk', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(disk!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (status != null && status!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('status', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(status!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (uptime != null && uptime!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('uptime', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(uptime!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}