package com.uilib.components.workflow

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 审批流 - workflow industry (Compose) */
@Composable
fun ApprovalFlow(
    title: String = "",
    applicant: String = "",
    currentStep: String = "",
    totalSteps: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "审批流",
        status = status.ifBlank { null },
        fields = listOf(
            "标题" to title,
            "申请人" to applicant,
            "当前步骤" to currentStep,
            "总步骤" to totalSteps,
        ),
        modifier = modifier,
    )
}