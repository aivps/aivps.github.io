import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface PurchaseOrderCardProps {
  id?: string | number;
  orderNumber?: string | number;
  supplier?: string | number;
  totalAmount?: string | number;
  status?: string;
  orderDate?: string | number;
  expectedDate?: string | number;
  buyer?: string | number;
  /** @deprecated use orderNumber */
  orderNo?: string | number;
  /** @deprecated use supplier */
  vendor?: string | number;
  /** @deprecated use totalAmount */
  amount?: string | number;
  /** @deprecated use orderDate */
  date?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 采购单 - field-deep aligned shell */
export const PurchaseOrderCard: React.FC<PurchaseOrderCardProps> = ({
  id,
  orderNumber,
  supplier,
  totalAmount,
  status,
  orderDate,
  expectedDate,
  buyer,
  orderNo,
  vendor,
  amount,
  date,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="采购单"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '订单号', value: orderNumber ?? orderNo },
      { label: '供应商', value: supplier ?? vendor },
      { label: '金额', value: totalAmount ?? amount },
      { label: '下单日期', value: orderDate ?? date },
      { label: '预计到货', value: expectedDate },
      { label: '采购员', value: buyer },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default PurchaseOrderCard;
