/** Watermark - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'text': { type: String, value: '' },
    'opacity': { type: String, value: '' },
    'angle': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});