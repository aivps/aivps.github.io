/** 销售单 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'orderNumber': { type: String, value: '' },
    'customer': { type: String, value: '' },
    'totalAmount': { type: String, value: '' },
    'status': { type: String, value: '' },
    'orderDate': { type: String, value: '' },
    'deliveryDate': { type: String, value: '' },
    'salesPerson': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
