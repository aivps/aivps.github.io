import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface CampaignCardProps {
  id?: string;
  name?: string;
  platform?: string;
  budget?: string;
  spent?: string;
  impressions?: string;
  clicks?: string;
  status?: string;
  onClick?: () => void;
}

/** CampaignCard - Electron shell (field keys aligned to React) */
export const CampaignCard: React.FC<CampaignCardProps> = (props) => (
  <IndustryCardShell title="CampaignCard" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.platform ? <div className="row"><span className="label">platform</span><span>{props.platform}</span></div> : null}
      {props.budget ? <div className="row"><span className="label">budget</span><span>{props.budget}</span></div> : null}
      {props.spent ? <div className="row"><span className="label">spent</span><span>{props.spent}</span></div> : null}
      {props.impressions ? <div className="row"><span className="label">impressions</span><span>{props.impressions}</span></div> : null}
      {props.clicks ? <div className="row"><span className="label">clicks</span><span>{props.clicks}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default CampaignCard;