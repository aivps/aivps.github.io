/** 生产面板 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'lineId': { type: String, value: '' },
    'lineName': { type: String, value: '' },
    'dailyOutput': { type: String, value: '' },
    'dailyTarget': { type: String, value: '' },
    'qualityRate': { type: String, value: '' },
    'alarmCount': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
