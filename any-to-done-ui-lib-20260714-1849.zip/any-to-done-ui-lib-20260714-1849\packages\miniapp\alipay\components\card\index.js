/**
 * Card — shallow API aligned to React composite Card.
 * Canonical: title, extra, bordered, hoverable, loading; variant extension.
 * Legacy: type → variant, clickable → hoverable semantics.
 */
Component({
  options: {
    addGlobalClass: true,
    multipleSlots: true,
  },

  properties: {
    title: {
      type: String,
      value: '',
    },
    extra: {
      type: String,
      value: '',
    },
    /** React-aligned variant */
    variant: {
      type: String,
      value: '',
    },
    /** @deprecated use variant */
    type: {
      type: String,
      value: 'default', // default, outlined, filled
    },
    padding: {
      type: String,
      value: 'md',
    },
    bordered: {
      type: Boolean,
      value: true,
    },
    hoverable: {
      type: Boolean,
      value: false,
    },
    loading: {
      type: Boolean,
      value: false,
    },
    /** @deprecated prefer hoverable + bind:tap */
    clickable: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    resolvedVariant: 'default',
    isPressable: false,
  },

  observers: {
    'variant, type, hoverable, clickable': function (variant, type, hoverable, clickable) {
      this.setData({
        resolvedVariant: variant || type || 'default',
        isPressable: hoverable || clickable,
      });
    },
  },

  lifetimes: {
    attached() {
      const { variant, type, hoverable, clickable } = this.properties;
      this.setData({
        resolvedVariant: variant || type || 'default',
        isPressable: hoverable || clickable,
      });
    },
  },

  methods: {
    onTap() {
      if (this.data.isPressable) {
        this.triggerEvent('tap');
      }
    },
  },
});
