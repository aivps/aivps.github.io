/** Gauge - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'label': { type: String, value: '' },
    'value': { type: String, value: '' },
    'min': { type: String, value: '' },
    'max': { type: String, value: '' },
    'unit': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});