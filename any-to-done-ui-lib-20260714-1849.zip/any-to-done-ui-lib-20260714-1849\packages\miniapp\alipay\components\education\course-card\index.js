/** 课程 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'title': { type: String, value: '' },
    'teacher': { type: String, value: '' },
    'price': { type: String, value: '' },
    'duration': { type: String, value: '' },
    'studentCount': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});