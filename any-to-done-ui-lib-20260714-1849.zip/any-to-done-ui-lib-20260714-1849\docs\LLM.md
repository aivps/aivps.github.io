# LLM / Agent 最短路径（低 Token）

> **先读本文件，再按需跳转。** 不要默认打开 `component-library-plan.md` 全文或全仓扫描。

## 30 秒路由

| 你要做什么 | 只读这些 |
|------------|----------|
| 查组件有没有、路径在哪 | `component-index.md` |
| 改行业卡 **字段名/枚举** | `docs/api-contract-industry-cards.md` 对应章节 |
| 改原子组件 API | `docs/api-contract-atoms.md` |
| 实现/行为以谁为准 | **`src/{industry}/*`（React Web）** |
| Vue 高交互范例 | `packages/vue/src/{ecommerce,workflow,medical,finance,erp,logistics,manufacturing,legal,property,education,fitness,it-service,esign,gaming,wedding,video,advertising,bath,children,k12,hardware,monitor,bi,portrait,tools,advanced,global}/*` |
| 多端改哪 | 下表「平台路径」 |
| 看长什么样 | 打开 `demo.html`（医疗/电商/财务/ERP/物流/制造/法务/物业/教育/健身/IT/电签/棋牌/婚庆/视频/广告/硬件/洗浴/儿童/K12/审批/运维/BI/竖屏/工具/高阶/全局可点）或 `preview.html` |
| 真机/静态冒烟 | `pnpm smoke` → `scripts/smoke-check.ps1`；自动记录 `scripts/smoke-checklist.latest.md`；人工清单 `docs/smoke-checklist.md`；小程序宿主 `packages/miniapp/{weixin,alipay,douyin}` |
| 截图验收 | `pnpm visual` → `scripts/visual-check.ps1`；目标 ~60 帧（全可交互行业 light + 全可交互行业 dark 抽样含 children/k12/tools + preview + 小程序三端）；基线 `visual-baselines/`；说明 `docs/visual-regression.md` |
| demo 交互冒烟 | `pnpm interact` → `scripts/interact-check.ps1`；场景 `scripts/interact-targets.json`（38）；报告 `scripts/interact-report.latest.md` |
| 串联验收 | `pnpm qa` → smoke + visual + interact |
| 接手进度 | `DEVELOPMENT-HANDOFF.md` |

## 平台路径（不要全扫）

| 平台 | 路径 |
|------|------|
| React（权威） | `src/` → `packages/react` re-export |
| Vue3 | `packages/vue/src/{industry}/` |
| React Native | `packages/react-native/src/{industry}/` |
| Flutter | `packages/flutter/lib/src/{industry}/` |
| 微信小程序 | `packages/miniapp/weixin/components/{industry}/` |
| 支付宝 | `packages/miniapp/alipay/components/`（与微信契约同步） |
| 抖音 | `packages/miniapp/douyin/components/`（与微信契约同步） |
| Web Components | `packages/wc/src/components/{industry}/` |
| Electron | `packages/electron/src/components/{industry}/` |
| Android Compose | `packages/android/.../components/` |
| iOS SwiftUI | `packages/ios/UILib/Sources/Components/` |

## 契约硬规则（改字段前必看）

1. **Canonical = React**：prop 名与英文枚举以 `src/` 为准。
2. **UI 可中文，值保持英文**：如 `status: "waiting"` → 展示「候诊中」。
3. **Legacy 别名**：旧嵌套对象/中文枚举可在组件内 normalize，勿反向污染 React。
4. **Shell 端**（小程序/WC/Electron/原生）：扁平 string 字段，**key 与契约表一致**。
5. **phase6 字段源**：`scripts/phase6-industries.json`（生成 Android/iOS/Electron 等）。
6. **Vue 加深模式**：嵌套对象（`product`/`item`/`ticket`/`nodes`/`patient`/`invoice`/`order`/`transport`/`inventory`/`line`/`panel`/`caseInfo`/`property`/`course`/`schedule`/`member`/`memberCard`/`incident`/`contract`/`progressInfo`/`room`/`players`/`wedding`/`guests`/`video`/`player`/`campaign`/`schedule`/`services`/`student`/`homework`/`station`/`device`/`servers`/`items`）为 canonical 或可选；advanced 用 `items[]` + 行 slot / 分栏 slots；global 用 provide/inject（Theme / Breakpoint / Portal）+ 展示组件；扁平 props 作 shell/legacy 输入并在组件内合成；事件与 React 对齐。

## 行业 ID 一览（28）

`global` `atoms` `composite` `bi` `workflow` `ecommerce` `monitor` `advanced` `portrait` `tools` `logistics` `medical` `education` `k12` `property` `advertising` `children` `manufacturing` `wedding` `legal` `fitness` `finance` `it-service` `esign` `erp` `bath` `gaming` `video` `hardware`

每行业多端至少 **2** 张行业卡（parity 基线）。

## 禁止浪费 Token 的行为

- 不要把整个 `component-library-plan.md` 塞进上下文（规划历史，非运行时 API）。
- 不要对 `packages/**` 做无目标 grep；先定 industry + platform。
- 不要从示例文案抄 prop 名；以契约文档英文 key 为准。
- 不要在 shell 端发明中文 prop 名。

## 推荐提示词片段（复制即用）

```
任务：对齐 {platform} 的 {Industry}/{Component} 到 React 契约。
1. 读 docs/api-contract-industry-cards.md 中该组件表
2. 读 src/{industry}/{Component}.tsx 确认 canonical props
3. 只改 packages/{platform}/ 下对应文件
4. 枚举用英文；UI label 中文；保留 legacy 别名 normalize
```

```
任务：加深 Vue 行业卡（参考 ecommerce/workflow 模式）。
1. 读 src/{industry}/{Component}.tsx
2. 改 packages/vue/src/{industry}/{Component}.vue
3. 嵌套对象为 canonical；扁平 props 合成；事件名与 React 对齐
4. 更新 demo.html 对应区块（可选）+ 契约章节
```

## 生成脚本（可选）

| 脚本 | 用途 |
|------|------|
| `scripts/align-remaining.ps1` | 剩余行业 phase6 字段 + 微信/WC/Electron shell |
| `scripts/gen-rn-remaining.ps1` | RN 剩余行业卡骨架 |
| `scripts/gen-flutter-remaining.ps1` | Flutter 剩余行业卡骨架 |
| `scripts/gen-vue-industry.ps1` | Vue 全行业扁平 props 卡 |
| `scripts/sync-alipay-douyin.ps1` | 微信 → 支付宝/抖音同步 |
| `scripts/gen-phase6.ps1` | Android / iOS / Electron 生成 |
| `scripts/smoke-check.ps1` | 静态冒烟（三端小程序宿主 + phase6 52 卡 + Android/iOS/Flutter/RN 文件） |
| `scripts/visual-check.ps1` | 截图验收（demo/preview → Edge headless PNG + SHA256 基线） |
| `scripts/interact-check.ps1` | demo 点击冒烟（Edge dump-dom + toast/DOM 断言） |
| `scripts/qa.ps1` | 串联 smoke → visual → interact |

## 验证清单（改完自检）

- [ ] prop/attribute 名与契约表一致  
- [ ] status 等枚举为英文  
- [ ] 展示文案为中文  
- [ ] 未把 RN/Flutter API 写进 `src/`  
- [ ] 浏览器打开 `demo.html` 对照字段语义  
- [ ] 改 shell/phase6 后跑 `pnpm smoke`（FAIL=0）  
- [ ] 改 `demo.html` 视觉后跑 `pnpm visual`；有意改版则 `pnpm visual:update` 后入库基线  
