import 'package:flutter/material.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';

/// 复选框尺寸
enum CheckboxSize {
  sm,
  md,
  lg,
}

/// AppCheckbox 复选框组件
class AppCheckbox extends StatelessWidget {
  final bool value;
  final bool disabled;
  final bool indeterminate;
  final CheckboxSize size;
  final String? label;
  final ValueChanged<bool?>? onChanged;

  const AppCheckbox({
    super.key,
    this.value = false,
    this.disabled = false,
    this.indeterminate = false,
    this.size = CheckboxSize.md,
    this.label,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: disabled ? null : () => onChanged?.call(!value),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: _getSize(),
            height: _getSize(),
            decoration: BoxDecoration(
              color: value || indeterminate ? AppColors.primary : AppColors.gray0,
              border: Border.all(
                color: value || indeterminate ? AppColors.primary : AppColors.gray400,
                width: 1.5,
              ),
              borderRadius: BorderRadius.circular(4),
            ),
            child: value || indeterminate
                ? Center(
                    child: Text(
                      indeterminate ? '−' : '✓',
                      style: TextStyle(
                        fontSize: _getIconSize(),
                        color: AppColors.gray0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  )
                : null,
          ),
          if (label != null) ...[
            const SizedBox(width: AppSpacing.sm),
            Text(
              label!,
              style: TextStyle(
                fontSize: 14,
                color: disabled ? AppColors.gray500 : AppColors.gray900,
              ),
            ),
          ],
        ],
      ),
    );
  }

  double _getSize() {
    switch (size) {
      case CheckboxSize.sm:
        return 16;
      case CheckboxSize.md:
        return 20;
      case CheckboxSize.lg:
        return 24;
    }
  }

  double _getIconSize() {
    switch (size) {
      case CheckboxSize.sm:
        return 10;
      case CheckboxSize.md:
        return 14;
      case CheckboxSize.lg:
        return 18;
    }
  }
}
