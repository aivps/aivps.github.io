import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface InventoryCardProps {
  id?: string | number;
  name?: string | number;
  sku?: string | number;
  quantity?: string | number;
  unit?: string | number;
  location?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 库存 - field-deep aligned shell */
export const InventoryCard: React.FC<InventoryCardProps> = ({
  id,
  name,
  sku,
  quantity,
  unit,
  location,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="库存"
    status={status}
    fields={[
    { label: 'ID', value: id },
    { label: '名称', value: name },
    { label: 'SKU', value: sku },
    { label: '数量', value: quantity },
    { label: '单位', value: unit },
    { label: '库位', value: location },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default InventoryCard;