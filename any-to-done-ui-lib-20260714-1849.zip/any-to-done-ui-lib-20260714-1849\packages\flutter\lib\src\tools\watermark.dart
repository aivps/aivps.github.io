import 'package:flutter/material.dart';

/// Watermark - field-deep aligned to React src/tools
class Watermark extends StatelessWidget {
  final String? text;
  final String? opacity;
  final String? angle;
  final VoidCallback? onTap;
  final bool disabled;

  const Watermark({
    super.key,
    this.text,
    this.opacity,
    this.angle,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF1F1F1F) : Colors.white;
    final border = isDark ? const Color(0xFF303030) : const Color(0xFFE8E8E8);
    final muted = const Color(0xFF8C8C8C);
    final fg = isDark ? const Color(0xFFE8E8E8) : const Color(0xFF262626);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Material(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Watermark', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: fg)),
                const SizedBox(height: 12),
                if (text != null && text!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('text', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(text!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (opacity != null && opacity!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('opacity', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(opacity!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (angle != null && angle!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('angle', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(angle!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}