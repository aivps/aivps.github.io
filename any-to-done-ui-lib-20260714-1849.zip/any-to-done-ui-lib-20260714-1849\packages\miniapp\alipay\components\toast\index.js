/**
 * 轻提示组件
 */
Component({
  options: {
    addGlobalClass: true,
  },

  properties: {
    // 是否显示
    visible: {
      type: Boolean,
      value: false,
    },
    // 提示类型
    type: {
      type: String,
      value: 'info', // success, error, warning, info, loading
    },
    // 提示内容
    content: {
      type: String,
      value: '',
    },
    // 显示时长(ms)
    duration: {
      type: Number,
      value: 2000,
    },
    // 位置
    position: {
      type: String,
      value: 'center', // top, center, bottom
    },
  },

  observers: {
    visible(val) {
      if (val && this.properties.duration > 0 && this.properties.type !== 'loading') {
        this._timer = setTimeout(() => {
          this.hide();
        }, this.properties.duration);
      }
    },
  },

  lifetimes: {
    detached() {
      if (this._timer) {
        clearTimeout(this._timer);
      }
    },
  },

  methods: {
    hide() {
      this.triggerEvent('close');
    },
  },
});
