import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface WatermarkProps {
  text?: string;
  opacity?: string;
  angle?: string;
  status?: string;
  onClick?: () => void;
}

/** Watermark - Electron shell (field keys aligned to React) */
export const Watermark: React.FC<WatermarkProps> = (props) => (
  <IndustryCardShell title="Watermark" status={props.status} onClick={props.onClick}>
      {props.text ? <div className="row"><span className="label">text</span><span>{props.text}</span></div> : null}
      {props.opacity ? <div className="row"><span className="label">opacity</span><span>{props.opacity}</span></div> : null}
      {props.angle ? <div className="row"><span className="label">angle</span><span>{props.angle}</span></div> : null}
  </IndustryCardShell>
);

export default Watermark;