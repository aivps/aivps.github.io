/**
 * 分栏 card - advanced industry (Douyin Mini Program)
 */
Component({
  options: { addGlobalClass: true },
  properties: {
    'direction': { type: String, value: '' },
    'ratio': { type: String, value: '' },
    'minSize': { type: String, value: '' },
  },
  methods: {
    onTap() {
      this.triggerEvent('tap', { ...this.data });
    },
  },
});