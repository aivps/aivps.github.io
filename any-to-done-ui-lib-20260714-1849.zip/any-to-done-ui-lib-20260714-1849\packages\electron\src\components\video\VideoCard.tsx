import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface VideoCardProps {
  id?: string;
  title?: string;
  duration?: string;
  views?: string;
  likes?: string;
  status?: string;
  author?: string;
  category?: string;
  onClick?: () => void;
}

/** VideoCard - Electron shell (field keys aligned to React) */
export const VideoCard: React.FC<VideoCardProps> = (props) => (
  <IndustryCardShell title="VideoCard" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.title ? <div className="row"><span className="label">title</span><span>{props.title}</span></div> : null}
      {props.duration ? <div className="row"><span className="label">duration</span><span>{props.duration}</span></div> : null}
      {props.views ? <div className="row"><span className="label">views</span><span>{props.views}</span></div> : null}
      {props.likes ? <div className="row"><span className="label">likes</span><span>{props.likes}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.author ? <div className="row"><span className="label">author</span><span>{props.author}</span></div> : null}
      {props.category ? <div className="row"><span className="label">category</span><span>{props.category}</span></div> : null}
  </IndustryCardShell>
);

export default VideoCard;
