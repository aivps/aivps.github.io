﻿package com.uilib.components.manufacturing

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 产线 - field-deep aligned shell (Compose) */
@Composable
fun ProductionLineCard(
    lineId: String = "",
    lineName: String = "",
    product: String = "",
    target: String = "",
    actual: String = "",
    status: String = "",
    shift: String = "",
    efficiency: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "产线",
        status = status.ifBlank { null },
        fields = listOf(
            "产线ID" to lineId,
            "名称" to lineName,
            "产品" to product,
            "目标" to target,
            "实际" to actual,
            "班次" to shift,
            "效率" to efficiency,
        ),
        modifier = modifier,
    )
}
