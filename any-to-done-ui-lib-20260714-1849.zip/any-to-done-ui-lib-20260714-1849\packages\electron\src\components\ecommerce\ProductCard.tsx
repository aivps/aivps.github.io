import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ProductCardProps {
  id?: string | number;
  name?: string | number;
  price?: string | number;
  originalPrice?: string | number;
  sales?: string | number;
  image?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 商品 - medical/ecommerce (Electron, field-deep aligned) */
export const ProductCard: React.FC<ProductCardProps> = ({
  id,
  name,
  price,
  originalPrice,
  sales,
  image,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="商品"
    status={status}
    fields={[
    { label: 'ID', value: id },
    { label: '名称', value: name },
    { label: '价格', value: price },
    { label: '原价', value: originalPrice },
    { label: '销量', value: sales },
    { label: '图片', value: image },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ProductCard;
