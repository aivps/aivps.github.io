import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface CaseCardProps {
  id?: string | number;
  caseNumber?: string | number;
  caseType?: string | number;
  title?: string | number;
  client?: string | number;
  lawyer?: string | number;
  filingDate?: string | number;
  courtDate?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 案件 - field-deep aligned shell */
export const CaseCard: React.FC<CaseCardProps> = ({
  id,
  caseNumber,
  caseType,
  title,
  client,
  lawyer,
  filingDate,
  courtDate,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="案件"
    status={status}
    fields={[
    { label: 'ID', value: id },
    { label: '案号', value: caseNumber },
    { label: '类型', value: caseType },
    { label: '标题', value: title },
    { label: '当事人', value: client },
    { label: '律师', value: lawyer },
    { label: '立案日期', value: filingDate },
    { label: '开庭日期', value: courtDate },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default CaseCard;