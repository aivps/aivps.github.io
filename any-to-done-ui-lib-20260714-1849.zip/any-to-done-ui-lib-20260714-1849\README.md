# 企业级跨端UI组件库

一套可全局复用的企业级跨端UI组件，统一Design Token，覆盖Web、小程序、Flutter、iOS SwiftUI、Android Compose、Electron桌面、车机、手表、TV、工控屏、自助终端全部设备。

## 30 秒入口（人 / LLM）

| 目的 | 打开 |
|------|------|
| **看得见的演示** | [`demo.html`](./demo.html)（行业卡：医疗/电商/财务/ERP/物流/制造/法务/物业/教育/健身/IT/电签/棋牌/婚庆/视频/广告/硬件/洗浴/儿童/K12/审批/运维/BI/竖屏/工具/高阶/全局可交互）· [`preview.html`](./preview.html)（原子组件） |
| **静态 / 真机冒烟** | `pnpm smoke` · 自动记录 `scripts/smoke-checklist.latest.md` · [`docs/smoke-checklist.md`](./docs/smoke-checklist.md) · 小程序导入 `packages/miniapp/weixin` 等 |
| **截图验收** | `pnpm visual` / `pnpm visual:update` · [`docs/visual-regression.md`](./docs/visual-regression.md) · 基线 `visual-baselines/`（含小程序 proxy `manual/*_home.png`） |
| **demo 交互冒烟** | `pnpm interact` · `scripts/interact-targets.json` · 报告 `scripts/interact-report.latest.md` |
| **串联验收** | `pnpm qa` · smoke + visual + interact |
| **AI 低 Token 路由** | [`docs/LLM.md`](./docs/LLM.md) |
| **字段契约** | [`docs/api-contract-industry-cards.md`](./docs/api-contract-industry-cards.md) |
| **组件索引** | [`component-index.md`](./component-index.md) |
| **交接进度** | [`DEVELOPMENT-HANDOFF.md`](./DEVELOPMENT-HANDOFF.md) |
| **本仓 Agent 约定** | [`AGENTS.md`](./AGENTS.md) |

权威实现：根目录 `src/`（React）。`packages/react` 仅为 re-export。

## 特性

- **六色系方案**: 蓝色/红色/绿色/紫色/青色/橙色，覆盖所有业务场景
- **双主题**: 浅色模式 + 暗黑模式，组件两套样式自动适配
- **多断点响应式**: 手机/平板/横屏PC/竖屏PC/大屏工控 五套断点全局适配
- **多平台输出**: React/Vue3/Flutter/WebComponents/小程序 多平台组件包
- **完整状态**: 默认/hover/active/focus/disabled/loading/error/只读
- **低耦合**: 全部组件无任何行业业务硬编码，仅提供UI渲染能力

## 目录结构

```
├── src/                    # 源码目录
│   ├── tokens/             # Design Token 定义
│   ├── global/             # 00 全局基建组件
│   ├── atoms/              # 01 原子基础组件
│   ├── composite/          # 02 复合业务组件
│   ├── bi/                 # 03 BI可视化组件
│   ├── workflow/           # 04 流程审批组件
│   ├── ecommerce/          # 05 C端商城组件
│   ├── monitor/            # 06 运维监控组件
│   ├── advanced/           # 07 高阶交互组件
│   ├── portrait/           # 08 PC竖屏布局组件
│   ├── utils/              # 09 通用工具组件
│   ├── logistics/          # 10 仓储物流组件
│   ├── medical/            # 11 医疗门诊组件
│   ├── education/          # 12 校园教育组件
│   ├── property/           # 13 物业园区组件
│   ├── advertising/        # 14 广告传媒组件
│   ├── children/           # 15 儿童医院组件
│   ├── manufacturing/      # 16 制造业工厂组件
│   ├── wedding/            # 17 婚庆婚嫁组件
│   ├── legal/              # 18 律师法务组件
│   ├── fitness/            # 19 健身房组件
│   ├── finance/            # 20 财务财税组件
│   ├── it-service/         # 21 运维外包组件
│   ├── k12/                # 22 K12教育组件
│   ├── esign/              # 23 电子签约组件
│   ├── erp/                # 24 ERP企业资源管理组件
│   ├── bath/               # 25 洗浴休闲中心组件
│   ├── gaming/             # 26 在线棋牌游戏后台组件
│   ├── video/              # 27 视频播放组件
│   └── hardware/           # 28 特种硬件设备规范
├── packages/               # 多平台导出包
│   ├── react/              # React TSX 组件包
│   ├── vue/                # Vue3 组件包
│   ├── flutter/            # Flutter Widget 包
│   ├── wc/                 # Web Components 包
│   ├── miniapp/            # 小程序组件包
│   ├── ios/                # iOS SwiftUI 组件包
│   ├── android/            # Android Compose 组件包
│   ├── electron/           # Electron 桌面组件包
│   └── hardware/           # 特种硬件规范文档
├── component-index.md      # 组件索引（Token优化版）
└── component-library-plan.md # 完整规划文档
```

## 快速开始

### React

```tsx
import { Button, Input, Card } from '@ui-lib/react';

function App() {
  return (
    <Card title="用户信息">
      <Input placeholder="请输入用户名" />
      <Button variant="primary">提交</Button>
    </Card>
  );
}
```

### Vue 3

```vue
<template>
  <Card title="用户信息">
    <Input placeholder="请输入用户名" />
    <Button variant="primary">提交</Button>
  </Card>
</template>

<script setup>
import { Card, Input, Button } from '@ui-lib/vue';
</script>
```

### Flutter

```dart
import 'package:ui_lib/ui_lib.dart';

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ThemeProvider(
      mode: ThemeMode.light,
      palette: ThemePalette.blue,
      child: Card(
        child: Column(
          children: [
            UIButton(
              variant: ButtonVariant.primary,
              child: Text('提交'),
            ),
          ],
        ),
      ),
    );
  }
}
```

## 设计Token

### 六色系

| 色系 | 主色 | 场景 |
|------|------|------|
| 蓝色 | `#1677FF` | 默认/品牌 |
| 红色 | `#F53F3F` | 危险/告警/促销 |
| 绿色 | `#00B42A` | 成功/完成/在线 |
| 紫色 | `#722ED1` | 特权/高级/智能 |
| 青色 | `#13C2C2` | 科技/数据/监控 |
| 橙色 | `#FA8C16` | 警告/营销/活力 |

### 响应式断点

| 断点 | 范围 | 设备 |
|------|------|------|
| xs | 320-767px | 手机 |
| sm | 768-1279px | 平板 |
| md | 1280-1919px | 横屏PC |
| lg | ≤1080宽 | 竖屏PC |
| xl | ≥1920px | 大屏/工控 |

## 组件清单

### 00 全局基建
- ThemeProvider 主题切换
- BreakpointDetector 断点识别
- EmptyState 空状态
- GlobalLoading 全局加载
- ErrorBoundary 异常捕获
- PortalContainer 弹窗挂载

### 01 原子基础
- Button 按钮 (7种变体)
- Input 输入框 (单行/密码/文本域/数字)
- Select 下拉选择
- Radio 单选框
- Checkbox 复选框
- Switch 开关
- Slider 滑块
- Tag 标签
- Avatar 头像
- Badge 徽章
- Progress 进度条
- Divider 分割线
- Tooltip 提示

### 02 复合业务
- Card 卡片
- Tabs 标签页
- Modal 弹窗
- Drawer 抽屉
- Toast 通知
- Pagination 分页
- Table 表格
- Tree 树形控件
- Upload 上传

### 03-28 行业组件
详见 [component-index.md](component-index.md)

## 响应式规范

1. **Resize防抖**: 300ms延迟，避免频繁重绘
2. **横竖屏旋转监听**: 自动重排全部组件布局
3. **断点缓存**: 全局断点钩子自动缓存当前设备类型
4. **三套交互逻辑**: 键鼠/触屏/遥控器，代码自动识别

## 无障碍规范

1. **ARIA语义**: 全部组件内置aria标签、role角色
2. **键盘导航**: 全组件支持键盘Tab正向/反向切换焦点
3. **高对比度模式**: 一键切换，同步适配浅色/暗黑两套主题
4. **字号放大控制器**: 全局生效，所有组件文字自动缩放适配

## 开发

```bash
# 安装依赖
pnpm install

# 开发模式
pnpm dev

# 构建
pnpm build

# 测试
pnpm test
```

## 许可证

MIT License
