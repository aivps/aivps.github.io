import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// PropertyCard - real-estate listing shell (UTF-8 safe).
class PropertyCard extends StatelessWidget {
  final String id;
  final String title;
  final String status;
  final String? address;
  final double? price;
  final String currency;
  final VoidCallback? onTap;
  final bool disabled;

  const PropertyCard({
    super.key,
    this.id = '',
    this.title = '',
    required this.status,
    this.address,
    this.price,
    this.currency = 'CNY',
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      title.isNotEmpty ? title : id,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: colors.foreground),
                    ),
                  ),
                  Text(status, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: colors.info)),
                ],
              ),
              if (address != null && address!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(address!, style: TextStyle(fontSize: 13, color: colors.muted)),
              ],
              if (price != null) ...[
                const SizedBox(height: 8),
                Text(
                  '$currency ${price!.toStringAsFixed(0)}',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: colors.foreground),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
