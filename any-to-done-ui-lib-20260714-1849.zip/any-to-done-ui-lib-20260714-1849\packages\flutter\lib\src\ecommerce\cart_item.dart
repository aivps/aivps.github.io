import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// Cart item data — React-aligned nested shape.
class CartItemData {
  final String id;
  final String name;
  final double price;
  final int quantity;
  final String? image;
  final String? sku;
  final bool selected;
  final int? stock;

  const CartItemData({
    required this.id,
    required this.name,
    required this.price,
    required this.quantity,
    this.image,
    this.sku,
    this.selected = false,
    this.stock,
  });
}

/// CartItem — field-deep aligned to React CartItem.
///
/// - Nested: pass [item] (React shape).
/// - Flat legacy: [name]/[price]/[quantity]/[imageUrl]/[sku].
/// - Callbacks stay Flutter-friendly (qty/bool without id); use [item].id in parent.
class CartItem extends StatelessWidget {
  final CartItemData? item;
  final String name;
  final double price;
  final int quantity;
  final String? imageUrl;
  final String? sku;
  final bool selected;
  final ValueChanged<int>? onQuantityChange;
  final VoidCallback? onRemove;
  final ValueChanged<bool>? onSelect;

  const CartItem({
    super.key,
    this.item,
    this.name = '',
    this.price = 0,
    this.quantity = 1,
    this.imageUrl,
    this.sku,
    this.selected = false,
    this.onQuantityChange,
    this.onRemove,
    this.onSelect,
  });

  String get _name => item?.name ?? name;
  double get _price => item?.price ?? price;
  int get _quantity => item?.quantity ?? quantity;
  String? get _image => item?.image ?? imageUrl;
  String? get _sku => item?.sku ?? sku;
  bool get _selected => item?.selected ?? selected;
  int get _maxStock => item?.stock ?? 99;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;

    return Container(
      padding: AppSpacing.lg,
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: AppSpacing.borderRadiusLg,
        boxShadow: AppShadows.sm,
      ),
      child: Row(
        children: [
          if (onSelect != null)
            Checkbox(
              value: _selected,
              onChanged: (v) => onSelect?.call(v ?? false),
              activeColor: colors.primary,
            ),
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: colors.background,
              borderRadius: AppSpacing.borderRadiusMd,
              image: _image != null && _image!.isNotEmpty
                  ? DecorationImage(
                      image: NetworkImage(_image!),
                      fit: BoxFit.cover,
                    )
                  : null,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _name,
                  style: AppTypography.body
                      .copyWith(fontWeight: FontWeight.w600),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (_sku != null)
                  Text(_sku!, style: AppTypography.caption),
                const SizedBox(height: 4),
                Text(
                  '¥${_price.toStringAsFixed(2)}',
                  style: AppTypography.h3.copyWith(color: colors.danger),
                ),
              ],
            ),
          ),
          Column(
            children: [
              Row(
                children: [
                  _qtyBtn(
                    colors,
                    '-',
                    () => onQuantityChange
                        ?.call((_quantity - 1).clamp(1, _maxStock)),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      '$_quantity',
                      style: AppTypography.body
                          .copyWith(color: colors.textPrimary),
                    ),
                  ),
                  _qtyBtn(
                    colors,
                    '+',
                    () => onQuantityChange
                        ?.call((_quantity + 1).clamp(1, _maxStock)),
                  ),
                ],
              ),
              if (onRemove != null)
                TextButton(
                  onPressed: onRemove,
                  child: Text(
                    '删除',
                    style:
                        AppTypography.caption.copyWith(color: colors.muted),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _qtyBtn(AppThemeColors colors, String label, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        width: 28,
        height: 28,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: colors.background,
          borderRadius: AppSpacing.borderRadiusSm,
        ),
        child: Text(label,
            style: AppTypography.body.copyWith(color: colors.textPrimary)),
      ),
    );
  }
}
