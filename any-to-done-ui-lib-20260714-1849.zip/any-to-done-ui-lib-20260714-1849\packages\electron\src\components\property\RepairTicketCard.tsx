import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface RepairTicketCardProps {
  id?: string | number;
  title?: string | number;
  location?: string | number;
  priority?: string | number;
  status?: string;
  reporter?: string | number;
  assignee?: string | number;
  /** @deprecated use id */
  ticketNo?: string | number;
  /** @deprecated use title */
  issue?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 报修单 - field-deep aligned shell */
export const RepairTicketCard: React.FC<RepairTicketCardProps> = ({
  id,
  title,
  location,
  priority,
  status,
  reporter,
  assignee,
  ticketNo,
  issue,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="报修单"
    status={status}
    fields={[
      { label: '单号', value: id ?? ticketNo },
      { label: '问题', value: title ?? issue },
      { label: '位置', value: location },
      { label: '优先级', value: priority },
      { label: '报修人', value: reporter },
      { label: '处理人', value: assignee },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default RepairTicketCard;
