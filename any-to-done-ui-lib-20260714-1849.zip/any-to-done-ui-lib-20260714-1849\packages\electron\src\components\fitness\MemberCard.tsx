import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface MemberCardProps {
  id?: string | number;
  name?: string | number;
  phone?: string | number;
  cardType?: string | number;
  expireDate?: string | number;
  remainingSessions?: string | number;
  status?: string;
  /** @deprecated use cardType */
  level?: string | number;
  /** @deprecated use remainingSessions */
  remainTimes?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 会员 - field-deep aligned shell */
export const MemberCard: React.FC<MemberCardProps> = ({
  id,
  name,
  phone,
  cardType,
  expireDate,
  remainingSessions,
  status,
  level,
  remainTimes,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="会员"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '名称', value: name },
      { label: '电话', value: phone },
      { label: '卡类型', value: cardType ?? level },
      { label: '到期日', value: expireDate },
      { label: '剩余次数', value: remainingSessions ?? remainTimes },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default MemberCard;
