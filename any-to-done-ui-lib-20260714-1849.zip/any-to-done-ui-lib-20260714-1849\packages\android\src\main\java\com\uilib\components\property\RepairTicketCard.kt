﻿package com.uilib.components.property

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 报修单 - field-deep aligned shell (Compose) */
@Composable
fun RepairTicketCard(
    id: String = "",
    title: String = "",
    location: String = "",
    priority: String = "",
    status: String = "",
    reporter: String = "",
    assignee: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "报修单",
        status = status.ifBlank { null },
        fields = listOf(
            "单号" to id,
            "问题" to title,
            "位置" to location,
            "优先级" to priority,
            "报修人" to reporter,
            "处理人" to assignee,
        ),
        modifier = modifier,
    )
}
