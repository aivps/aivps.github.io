import 'package:flutter/material.dart';
import '../tokens/colors.dart';
/// SplitPane 可调分栏
class SplitPane extends StatefulWidget {
  final Widget left;
  final Widget right;
  final double initialRatio;
  final double minRatio;
  final double maxRatio;
  final Axis axis;

  const SplitPane({
    super.key,
    required this.left,
    required this.right,
    this.initialRatio = 0.4,
    this.minRatio = 0.2,
    this.maxRatio = 0.8,
    this.axis = Axis.horizontal,
  });

  @override
  State<SplitPane> createState() => _SplitPaneState();
}

class _SplitPaneState extends State<SplitPane> {
  late double _ratio;

  @override
  void initState() {
    super.initState();
    _ratio = widget.initialRatio.clamp(widget.minRatio, widget.maxRatio);
  }

  @override
  Widget build(BuildContext context) {
    final horizontal = widget.axis == Axis.horizontal;
    return LayoutBuilder(
      builder: (context, constraints) {
        final total = horizontal ? constraints.maxWidth : constraints.maxHeight;
        final first = total * _ratio;
        return Flex(
          direction: widget.axis,
          children: [
            SizedBox(
              width: horizontal ? first : null,
              height: horizontal ? null : first,
              child: widget.left,
            ),
            GestureDetector(
              behavior: HitTestBehavior.translucent,
              onHorizontalDragUpdate: horizontal
                  ? (d) => setState(() {
                        _ratio = (_ratio + d.delta.dx / total).clamp(widget.minRatio, widget.maxRatio);
                      })
                  : null,
              onVerticalDragUpdate: !horizontal
                  ? (d) => setState(() {
                        _ratio = (_ratio + d.delta.dy / total).clamp(widget.minRatio, widget.maxRatio);
                      })
                  : null,
              child: Container(
                width: horizontal ? 6 : null,
                height: horizontal ? null : 6,
                color: AppColors.gray200,
                child: Center(
                  child: Container(
                    width: horizontal ? 2 : 24,
                    height: horizontal ? 24 : 2,
                    color: AppColors.gray400,
                  ),
                ),
              ),
            ),
            Expanded(child: widget.right),
          ],
        );
      },
    );
  }
}