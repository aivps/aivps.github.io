import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ProductionLineCardProps {
  lineId?: string | number;
  lineName?: string | number;
  product?: string | number;
  target?: string | number;
  actual?: string | number;
  status?: string;
  shift?: string | number;
  efficiency?: string | number;
  /** @deprecated use lineName */
  name?: string | number;
  workers?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 产线 - field-deep aligned shell */
export const ProductionLineCard: React.FC<ProductionLineCardProps> = ({
  lineId,
  lineName,
  product,
  target,
  actual,
  status,
  shift,
  efficiency,
  name,
  workers,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="产线"
    status={status}
    fields={[
      { label: '产线ID', value: lineId },
      { label: '名称', value: lineName ?? name },
      { label: '产品', value: product },
      { label: '目标', value: target },
      { label: '实际', value: actual },
      { label: '班次', value: shift },
      { label: '效率', value: efficiency },
      { label: '人数', value: workers },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ProductionLineCard;
