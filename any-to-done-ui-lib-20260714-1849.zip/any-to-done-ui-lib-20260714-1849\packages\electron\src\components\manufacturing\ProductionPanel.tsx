import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ProductionPanelProps {
  lineId?: string | number;
  lineName?: string | number;
  dailyOutput?: string | number;
  dailyTarget?: string | number;
  qualityRate?: string | number;
  alarmCount?: string | number;
  status?: string;
  /** @deprecated */
  output?: string | number;
  target?: string | number;
  oee?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 生产面板 - field-deep aligned shell */
export const ProductionPanel: React.FC<ProductionPanelProps> = ({
  lineId,
  lineName,
  dailyOutput,
  dailyTarget,
  qualityRate,
  alarmCount,
  status,
  output,
  target,
  oee,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="生产面板"
    status={status}
    fields={[
      { label: '产线ID', value: lineId },
      { label: '产线', value: lineName },
      { label: '当日产量', value: dailyOutput ?? output },
      { label: '目标', value: dailyTarget ?? target },
      { label: '良品率', value: qualityRate ?? oee },
      { label: '告警', value: alarmCount },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ProductionPanel;
