import SwiftUI

/// 审批流 - workflow industry (SwiftUI)
public struct ApprovalFlow: View {
    public var title: String = ""
    public var applicant: String = ""
    public var currentStep: String = ""
    public var totalSteps: String = ""
    public var status: String = ""

    public init(title: String = "", applicant: String = "", currentStep: String = "", totalSteps: String = "", status: String = "") {
        self.title = title
        self.applicant = applicant
        self.currentStep = currentStep
        self.totalSteps = totalSteps
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "审批流",
            status: status.isEmpty ? nil : status,
            fields: [
            ("标题", title),
            ("申请人", applicant),
            ("当前步骤", currentStep),
            ("总步骤", totalSteps),
            ]
        )
    }
}