package com.uilib.components.advanced

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 虚拟列表 - advanced industry (Compose) */
@Composable
fun VirtualList(
    itemCount: String = "",
    itemHeight: String = "",
    overscan: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "虚拟列表",
        status = null,
        fields = listOf(
            "条目数" to itemCount,
            "条目高度" to itemHeight,
            "预渲染" to overscan,
        ),
        modifier = modifier,
    )
}