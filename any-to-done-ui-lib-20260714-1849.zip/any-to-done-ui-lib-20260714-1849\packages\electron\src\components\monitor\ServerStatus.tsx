import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ServerStatusProps {
  id?: string;
  name?: string;
  ip?: string;
  cpu?: string;
  memory?: string;
  disk?: string;
  status?: string;
  uptime?: string;
  onClick?: () => void;
}

/** ServerStatus - Electron shell (field keys aligned to React) */
export const ServerStatus: React.FC<ServerStatusProps> = (props) => (
  <IndustryCardShell title="ServerStatus" status={props.status} onClick={props.onClick}>
      {props.id ? <div className="row"><span className="label">id</span><span>{props.id}</span></div> : null}
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.ip ? <div className="row"><span className="label">ip</span><span>{props.ip}</span></div> : null}
      {props.cpu ? <div className="row"><span className="label">cpu</span><span>{props.cpu}</span></div> : null}
      {props.memory ? <div className="row"><span className="label">memory</span><span>{props.memory}</span></div> : null}
      {props.disk ? <div className="row"><span className="label">disk</span><span>{props.disk}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.uptime ? <div className="row"><span className="label">uptime</span><span>{props.uptime}</span></div> : null}
  </IndustryCardShell>
);

export default ServerStatus;
