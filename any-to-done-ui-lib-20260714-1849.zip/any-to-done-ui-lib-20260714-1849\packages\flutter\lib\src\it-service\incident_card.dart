import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// IncidentCard - IT incident shell (UTF-8 safe).
class IncidentCard extends StatelessWidget {
  final String id;
  final String title;
  final String status;
  final String level;
  final String? assignee;
  final VoidCallback? onTap;
  final bool disabled;

  const IncidentCard({
    super.key,
    this.id = '',
    this.title = '',
    required this.status,
    this.level = 'P3',
    this.assignee,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: colors.danger.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                    ),
                    child: Text(level, style: TextStyle(fontSize: 12, color: colors.danger, fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title.isNotEmpty ? title : id,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: colors.foreground),
                    ),
                  ),
                  Text(status, style: TextStyle(fontSize: 12, color: colors.muted)),
                ],
              ),
              if (assignee != null && assignee!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text('Assignee: $assignee', style: TextStyle(fontSize: 13, color: colors.muted)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
