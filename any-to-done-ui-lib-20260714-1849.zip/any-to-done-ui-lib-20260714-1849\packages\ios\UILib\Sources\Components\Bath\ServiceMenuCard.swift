import SwiftUI

/// 服务菜单 - bath industry (SwiftUI)
public struct ServiceMenuCard: View {
    public var name: String = ""
    public var price: String = ""
    public var duration: String = ""
    public var category: String = ""

    public init(name: String = "", price: String = "", duration: String = "", category: String = "") {
        self.name = name
        self.price = price
        self.duration = duration
        self.category = category
    }

    public var body: some View {
        IndustryCardShell(
            title: "服务菜单",
            status: nil,
            fields: [
            ("名称", name),
            ("价格", price),
            ("时长", duration),
            ("分类", category),
            ]
        )
    }
}