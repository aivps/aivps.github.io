/** PortraitKPI - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'label': { type: String, value: '' },
    'value': { type: String, value: '' },
    'delta': { type: String, value: '' },
    'unit': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});