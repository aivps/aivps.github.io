package com.uilib.components.wedding

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 宾客 - field-deep aligned shell (Compose) */
@Composable
fun GuestListCard(
    name: String = "",
    tableNumber: String = "",
    status: String = "",
    phone: String = "",
    relationship: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "宾客",
        status = status.ifBlank { null },
        fields = listOf(
            "名称" to name,
            "关系" to relationship,
            "桌号" to tableNumber,
            "电话" to phone,
        ),
        modifier = modifier,
    )
}
