package com.uilib.components.k12

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 作业 - k12 industry (Compose) */
@Composable
fun HomeworkCard(
    title: String = "",
    subject: String = "",
    dueDate: String = "",
    className: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "作业",
        status = status.ifBlank { null },
        fields = listOf(
            "标题" to title,
            "科目" to subject,
            "截止日期" to dueDate,
            "班级" to className,
        ),
        modifier = modifier,
    )
}