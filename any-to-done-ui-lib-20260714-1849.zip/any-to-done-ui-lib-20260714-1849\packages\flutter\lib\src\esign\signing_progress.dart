import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// Signer — aligned to React Signer
class Signer {
  final String id;
  final String name;
  final String role;
  final String status; // pending | signed | rejected | expired
  final String? signedAt;
  final String? method;

  const Signer({
    this.id = '',
    required this.name,
    this.role = '',
    required this.status,
    this.signedAt,
    this.method,
  });
}

/// @deprecated use Signer
typedef SigningStep = Signer;

/// SigningProgress — field-deep aligned to React SigningProgress.
class SigningProgress extends StatelessWidget {
  final String contractTitle;
  final String contractId;
  final List<Signer> signers;
  final String overallStatus; // draft | pending | partial | completed | expired | rejected
  final String createdAt;
  final String? expiresAt;
  final double progress; // 0–100
  final VoidCallback? onTap;
  final ValueChanged<Signer>? onRemind;
  final VoidCallback? onSign;
  final VoidCallback? onViewContract;
  final bool disabled;

  /// @deprecated aliases
  final String? title;
  final List<Signer>? steps;

  const SigningProgress({
    super.key,
    this.contractTitle = '',
    this.contractId = '',
    this.signers = const [],
    this.overallStatus = 'pending',
    this.createdAt = '',
    this.expiresAt,
    this.progress = 0,
    this.onTap,
    this.onRemind,
    this.onSign,
    this.onViewContract,
    this.disabled = false,
    this.title,
    this.steps,
  });

  String get _title =>
      contractTitle.isNotEmpty ? contractTitle : (title ?? '');
  List<Signer> get _signers =>
      signers.isNotEmpty ? signers : (steps ?? const []);

  static const _overallLabels = {
    'draft': '草稿',
    'pending': '签署中',
    'partial': '部分签署',
    'completed': '已完成',
    'expired': '已过期',
    'rejected': '已拒签',
  };

  static const _signerLabels = {
    'pending': '待签署',
    'signed': '已签署',
    'rejected': '已拒签',
    'expired': '已过期',
    'done': '已签署',
    'current': '待签署',
  };

  Color _signerColor(AppThemeColors colors, String status) {
    switch (status) {
      case 'signed':
      case 'done':
        return colors.success;
      case 'rejected':
      case 'expired':
        return colors.danger;
      case 'current':
      case 'pending':
        return colors.primary;
      default:
        return colors.textDisabled;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final list = _signers;
    final pct = progress.clamp(0, 100);
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_title, style: AppTypography.h3),
                        if (contractId.isNotEmpty)
                          Text(contractId, style: AppTypography.caption),
                      ],
                    ),
                  ),
                  Text(
                    _overallLabels[overallStatus] ?? overallStatus,
                    style: AppTypography.caption.copyWith(color: colors.primary),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('签署进度', style: AppTypography.caption),
                  Text('${pct.toInt()}%', style: AppTypography.caption),
                ],
              ),
              const SizedBox(height: 4),
              LinearProgressIndicator(
                value: pct / 100,
                backgroundColor: colors.border,
                color: colors.primary,
              ),
              const SizedBox(height: 16),
              ...list.asMap().entries.map((e) {
                final i = e.key;
                final s = e.value;
                final c = _signerColor(colors, s.status);
                final label = _signerLabels[s.status] ?? s.status;
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      children: [
                        Container(
                          width: 20,
                          height: 20,
                          decoration:
                              BoxDecoration(shape: BoxShape.circle, color: c),
                          child: (s.status == 'signed' || s.status == 'done')
                              ? Icon(Icons.check,
                                  size: 12, color: colors.textInverse)
                              : null,
                        ),
                        if (i < list.length - 1)
                          Container(width: 2, height: 28, color: colors.border),
                      ],
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(s.name,
                                    style: AppTypography.body
                                        .copyWith(fontWeight: FontWeight.w600)),
                                Text(label,
                                    style: AppTypography.caption
                                        .copyWith(color: c)),
                              ],
                            ),
                            if (s.role.isNotEmpty)
                              Text(s.role, style: AppTypography.caption),
                            if (s.signedAt != null)
                              Text(s.signedAt!, style: AppTypography.caption),
                            if (onRemind != null &&
                                (s.status == 'pending' ||
                                    s.status == 'current'))
                              TextButton(
                                onPressed:
                                    disabled ? null : () => onRemind!(s),
                                child: const Text('催签'),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              }),
              if (createdAt.isNotEmpty || expiresAt != null)
                Text(
                  [
                    if (createdAt.isNotEmpty) '创建: $createdAt',
                    if (expiresAt != null) '截止: $expiresAt',
                  ].join(' · '),
                  style: AppTypography.caption,
                ),
            ],
          ),
        ),
      ),
    );
  }
}
