import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// Product data — React-aligned nested shape.
class ProductData {
  final String id;
  final String name;
  final double price;
  final double? originalPrice;
  final String? image;
  final int? sales;
  final double? rating;
  final List<String>? tags;
  final int? stock;

  const ProductData({
    required this.id,
    required this.name,
    required this.price,
    this.originalPrice,
    this.image,
    this.sales,
    this.rating,
    this.tags,
    this.stock,
  });
}

/// ProductCard — field-deep aligned to React ProductCard.
/// Prefer [product]; flat constructor args kept as legacy.
class ProductCard extends StatelessWidget {
  final ProductData? product;
  /// Legacy flat API
  final String? name;
  final double? price;
  final double? originalPrice;
  final int? sales;
  final String? imageUrl;
  final List<String>? tags;
  final String layout; // vertical | horizontal | grid | list
  final bool showSales;
  final bool showRating;
  final VoidCallback? onTap;
  final ValueChanged<String>? onClick;
  final ValueChanged<String>? onAddToCart;

  const ProductCard({
    super.key,
    this.product,
    this.name,
    this.price,
    this.originalPrice,
    this.sales,
    this.imageUrl,
    this.tags,
    this.layout = 'vertical',
    this.showSales = true,
    this.showRating = false,
    this.onTap,
    this.onClick,
    this.onAddToCart,
  });

  ProductData get _data {
    if (product != null) return product!;
    return ProductData(
      id: '',
      name: name ?? '',
      price: price ?? 0,
      originalPrice: originalPrice,
      image: imageUrl,
      sales: sales,
      tags: tags,
    );
  }

  bool get _horizontal =>
      layout == 'horizontal' || layout == 'list';

  int? get _discount {
    final d = _data;
    if (d.originalPrice == null || d.originalPrice == 0) return null;
    return ((d.price / d.originalPrice!) * 10).round();
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final d = _data;
    final image = d.image ?? '';

    void handleTap() {
      onTap?.call();
      onClick?.call(d.id);
    }

    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (!_horizontal)
          Stack(
            children: [
              AspectRatio(
                aspectRatio: 1,
                child: Container(
                  decoration: BoxDecoration(
                    color: colors.background,
                    borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(12)),
                    image: image.isNotEmpty
                        ? DecorationImage(
                            image: NetworkImage(image),
                            fit: BoxFit.cover,
                          )
                        : null,
                  ),
                ),
              ),
              if (_discount != null)
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: colors.danger,
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      '$_discount折',
                      style: AppTypography.caption
                          .copyWith(color: colors.textInverse),
                    ),
                  ),
                ),
            ],
          ),
        Padding(
          padding: AppSpacing.md,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (_horizontal) ...[
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: colors.background,
                    borderRadius: AppSpacing.borderRadiusMd,
                    image: image.isNotEmpty
                        ? DecorationImage(
                            image: NetworkImage(image),
                            fit: BoxFit.cover,
                          )
                        : null,
                  ),
                ),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.name,
                      style: AppTypography.body
                          .copyWith(color: colors.textPrimary),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (d.tags != null && d.tags!.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Wrap(
                        spacing: 4,
                        children: d.tags!
                            .take(2)
                            .map(
                              (t) => Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: colors.primaryBg,
                                  borderRadius: AppSpacing.borderRadiusSm,
                                ),
                                child: Text(
                                  t,
                                  style: AppTypography.caption
                                      .copyWith(color: colors.primary),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    ],
                    const SizedBox(height: 4),
                    Text(
                      '¥${d.price.toStringAsFixed(2)}',
                      style: AppTypography.h3.copyWith(color: colors.danger),
                    ),
                    if (d.originalPrice != null)
                      Text(
                        '¥${d.originalPrice!.toStringAsFixed(2)}',
                        style: AppTypography.caption.copyWith(
                          color: colors.muted,
                          decoration: TextDecoration.lineThrough,
                        ),
                      ),
                    if (showSales)
                      Text(
                        '已售 ${d.sales ?? 0}',
                        style: AppTypography.caption
                            .copyWith(color: colors.muted),
                      ),
                    if (showRating && d.rating != null)
                      Text(
                        '评分 ${d.rating}',
                        style: AppTypography.caption
                            .copyWith(color: colors.muted),
                      ),
                  ],
                ),
              ),
              if (onAddToCart != null)
                IconButton(
                  onPressed: () => onAddToCart!(d.id),
                  icon: Icon(Icons.add_circle, color: colors.primary),
                ),
            ],
          ),
        ),
      ],
    );

    return GestureDetector(
      onTap: handleTap,
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: AppSpacing.borderRadiusLg,
          boxShadow: AppShadows.sm,
        ),
        clipBehavior: Clip.antiAlias,
        child: body,
      ),
    );
  }
}
