package com.uilib.components.monitor

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 监控设备 - monitor industry (Compose) */
@Composable
fun DeviceStatus(
    deviceId: String = "",
    name: String = "",
    location: String = "",
    online: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "监控设备",
        status = status.ifBlank { null },
        fields = listOf(
            "设备 ID" to deviceId,
            "名称" to name,
            "位置" to location,
            "在线" to online,
        ),
        modifier = modifier,
    )
}