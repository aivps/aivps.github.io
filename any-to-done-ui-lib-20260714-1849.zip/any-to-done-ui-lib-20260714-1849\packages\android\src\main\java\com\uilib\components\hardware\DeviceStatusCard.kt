package com.uilib.components.hardware

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 设备状态 - hardware industry (Compose) */
@Composable
fun DeviceStatusCard(
    deviceId: String = "",
    name: String = "",
    location: String = "",
    online: String = "",
    battery: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "设备状态",
        status = null,
        fields = listOf(
            "设备 ID" to deviceId,
            "名称" to name,
            "位置" to location,
            "在线" to online,
            "电量" to battery,
        ),
        modifier = modifier,
    )
}