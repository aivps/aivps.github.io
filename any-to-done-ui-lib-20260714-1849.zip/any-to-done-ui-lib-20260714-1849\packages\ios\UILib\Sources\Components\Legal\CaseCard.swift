import SwiftUI

/// 案件 - field-deep aligned shell (SwiftUI)
public struct CaseCard: View {
    public var id: String = ""
    public var caseNumber: String = ""
    public var caseType: String = ""
    public var title: String = ""
    public var client: String = ""
    public var lawyer: String = ""
    public var filingDate: String = ""
    public var courtDate: String = ""
    public var status: String = ""

    public init(id: String = "", caseNumber: String = "", caseType: String = "", title: String = "", client: String = "", lawyer: String = "", filingDate: String = "", courtDate: String = "", status: String = "") {
        self.id = id
        self.caseNumber = caseNumber
        self.caseType = caseType
        self.title = title
        self.client = client
        self.lawyer = lawyer
        self.filingDate = filingDate
        self.courtDate = courtDate
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "案件",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("案号", caseNumber),
            ("类型", caseType),
            ("标题", title),
            ("当事人", client),
            ("律师", lawyer),
            ("立案日期", filingDate),
            ("开庭日期", courtDate),
            ]
        )
    }
}