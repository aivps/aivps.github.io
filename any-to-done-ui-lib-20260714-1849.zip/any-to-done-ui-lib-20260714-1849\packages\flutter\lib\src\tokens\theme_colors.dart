import 'package:flutter/material.dart';
import 'colors.dart';

/// Semantic surface tokens for light / dark (aligned with React themes).
class AppThemeColors {
  const AppThemeColors({
    required this.bg,
    required this.bgPage,
    required this.bgElevated,
    required this.surface,
    required this.background,
    required this.fg,
    required this.foreground,
    required this.muted,
    required this.border,
    required this.borderSecondary,
    required this.disabled,
    required this.primary,
    required this.primaryBg,
    required this.success,
    required this.warning,
    required this.danger,
    required this.info,
    required this.textPrimary,
    required this.textSecondary,
    required this.textTertiary,
    required this.textDisabled,
    required this.textInverse,
  });

  final Color bg;
  final Color bgPage;
  final Color bgElevated;
  final Color surface;
  final Color background;
  final Color fg;
  final Color foreground;
  final Color muted;
  final Color border;
  final Color borderSecondary;
  final Color disabled;
  final Color primary;
  final Color primaryBg;
  final Color success;
  final Color warning;
  final Color danger;
  final Color info;
  final Color textPrimary;
  final Color textSecondary;
  final Color textTertiary;
  final Color textDisabled;
  final Color textInverse;

  static const light = AppThemeColors(
    bg: AppColors.gray0,
    bgPage: AppColors.gray100,
    bgElevated: AppColors.gray0,
    surface: AppColors.gray0,
    background: AppColors.gray100,
    fg: AppColors.gray1000,
    foreground: AppColors.gray1000,
    muted: AppColors.gray500,
    border: AppColors.gray200,
    borderSecondary: AppColors.gray300,
    disabled: AppColors.gray300,
    primary: AppColors.blue500,
    primaryBg: AppColors.blue50,
    success: AppColors.green500,
    warning: AppColors.orange500,
    danger: AppColors.red500,
    info: AppColors.blue500,
    textPrimary: AppColors.gray1000,
    textSecondary: AppColors.gray700,
    textTertiary: AppColors.gray600,
    textDisabled: AppColors.gray400,
    textInverse: AppColors.gray0,
  );

  static const dark = AppThemeColors(
    bg: Color(0xFF141414),
    bgPage: Color(0xFF0A0A0A),
    bgElevated: Color(0xFF1F1F1F),
    surface: Color(0xFF1F1F1F),
    background: Color(0xFF0A0A0A),
    fg: Color(0xFFE8E8E8),
    foreground: Color(0xFFE8E8E8),
    muted: Color(0xFFA3A3A3),
    border: Color(0xFF303030),
    borderSecondary: Color(0xFF424242),
    disabled: Color(0xFF595959),
    primary: Color(0xFF1668DC),
    primaryBg: Color(0x261668DC),
    success: Color(0xFF49AA19),
    warning: Color(0xFFD89614),
    danger: Color(0xFFDC4444),
    info: Color(0xFF1668DC),
    textPrimary: Color(0xFFE8E8E8),
    textSecondary: Color(0xFFA3A3A3),
    textTertiary: Color(0xFF737373),
    textDisabled: Color(0xFF595959),
    textInverse: Color(0xFF141414),
  );

  static AppThemeColors of(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return brightness == Brightness.dark ? dark : light;
  }
}

/// Palette primary colors for ThemeProvider / colorSchemeSeed.
class PaletteColors {
  PaletteColors._();

  static const Color bluePrimary = AppColors.blue500;
  static const Color redPrimary = AppColors.red500;
  static const Color greenPrimary = AppColors.green500;
  static const Color purplePrimary = AppColors.purple500;
  static const Color cyanPrimary = AppColors.cyan500;
  static const Color orangePrimary = AppColors.orange500;
}

extension AppThemeColorsX on BuildContext {
  AppThemeColors get appColors => AppThemeColors.of(this);
}
