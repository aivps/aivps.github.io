import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ClassScheduleProps {
  className?: string | number;
  gradeLevel?: string | number;
  semester?: string | number;
  subject?: string | number;
  teacher?: string | number;
  room?: string | number;
  dayOfWeek?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 课程表 - field-deep aligned shell */
export const ClassSchedule: React.FC<ClassScheduleProps> = ({
  className,
  gradeLevel,
  semester,
  subject,
  teacher,
  room,
  dayOfWeek,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="课程表"
    status={status}
    fields={[
    { label: '班级', value: className },
    { label: '年级', value: gradeLevel },
    { label: '学期', value: semester },
    { label: '科目', value: subject },
    { label: '教师', value: teacher },
    { label: '教室', value: room },
    { label: '星期', value: dayOfWeek },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ClassSchedule;