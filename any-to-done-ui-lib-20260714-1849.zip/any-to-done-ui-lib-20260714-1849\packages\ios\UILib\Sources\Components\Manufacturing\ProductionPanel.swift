﻿import SwiftUI

/// 生产面板 - field-deep aligned shell (SwiftUI)
public struct ProductionPanel: View {
    public var lineId: String = ""
    public var lineName: String = ""
    public var dailyOutput: String = ""
    public var dailyTarget: String = ""
    public var qualityRate: String = ""
    public var alarmCount: String = ""
    public var status: String = ""

    public init(lineId: String = "", lineName: String = "", dailyOutput: String = "", dailyTarget: String = "", qualityRate: String = "", alarmCount: String = "", status: String = "") {
        self.lineId = lineId
        self.lineName = lineName
        self.dailyOutput = dailyOutput
        self.dailyTarget = dailyTarget
        self.qualityRate = qualityRate
        self.alarmCount = alarmCount
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "生产面板",
            status: status.isEmpty ? nil : status,
            fields: [
            ("产线ID", lineId),
            ("产线", lineName),
            ("当日产量", dailyOutput),
            ("目标", dailyTarget),
            ("良品率", qualityRate),
            ("告警", alarmCount),
            ]
        )
    }
}
