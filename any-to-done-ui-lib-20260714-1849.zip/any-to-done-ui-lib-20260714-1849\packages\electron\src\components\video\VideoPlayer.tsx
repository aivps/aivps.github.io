import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface VideoPlayerProps {
  title?: string;
  src?: string;
  duration?: string;
  status?: string;
  onClick?: () => void;
}

/** VideoPlayer - Electron shell (field keys aligned to React) */
export const VideoPlayer: React.FC<VideoPlayerProps> = (props) => (
  <IndustryCardShell title="VideoPlayer" status={props.status} onClick={props.onClick}>
      {props.title ? <div className="row"><span className="label">title</span><span>{props.title}</span></div> : null}
      {props.src ? <div className="row"><span className="label">src</span><span>{props.src}</span></div> : null}
      {props.duration ? <div className="row"><span className="label">duration</span><span>{props.duration}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default VideoPlayer;