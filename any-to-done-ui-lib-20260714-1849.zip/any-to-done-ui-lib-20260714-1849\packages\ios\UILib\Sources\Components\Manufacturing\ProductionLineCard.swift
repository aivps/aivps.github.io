﻿import SwiftUI

/// 产线 - field-deep aligned shell (SwiftUI)
public struct ProductionLineCard: View {
    public var lineId: String = ""
    public var lineName: String = ""
    public var product: String = ""
    public var target: String = ""
    public var actual: String = ""
    public var status: String = ""
    public var shift: String = ""
    public var efficiency: String = ""

    public init(lineId: String = "", lineName: String = "", product: String = "", target: String = "", actual: String = "", status: String = "", shift: String = "", efficiency: String = "") {
        self.lineId = lineId
        self.lineName = lineName
        self.product = product
        self.target = target
        self.actual = actual
        self.status = status
        self.shift = shift
        self.efficiency = efficiency
    }

    public var body: some View {
        IndustryCardShell(
            title: "产线",
            status: status.isEmpty ? nil : status,
            fields: [
            ("产线ID", lineId),
            ("名称", lineName),
            ("产品", product),
            ("目标", target),
            ("实际", actual),
            ("班次", shift),
            ("效率", efficiency),
            ]
        )
    }
}
