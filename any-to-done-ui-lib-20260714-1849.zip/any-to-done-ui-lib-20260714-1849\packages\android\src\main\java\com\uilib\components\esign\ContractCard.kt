package com.uilib.components.esign

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 合同 - field-deep aligned shell (Compose) */
@Composable
fun ContractCard(
    id: String = "",
    contractNumber: String = "",
    title: String = "",
    parties: String = "",
    amount: String = "",
    status: String = "",
    createdAt: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "合同",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "合同号" to contractNumber,
            "标题" to title,
            "签署方" to parties,
            "金额" to amount,
            "创建日期" to createdAt,
        ),
        modifier = modifier,
    )
}
