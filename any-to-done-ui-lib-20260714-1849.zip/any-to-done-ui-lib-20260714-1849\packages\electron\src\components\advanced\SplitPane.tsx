import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface SplitPaneProps {
  orientation?: string | number;
  primarySize?: string | number;
  minSize?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 分栏 - advanced industry (Electron / desktop) */
export const SplitPane: React.FC<SplitPaneProps> = ({
  orientation,
  primarySize,
  minSize,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="分栏"
    
    fields={[
    { label: '方向', value: orientation },
    { label: '主区尺寸', value: primarySize },
    { label: '最小尺寸', value: minSize },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default SplitPane;