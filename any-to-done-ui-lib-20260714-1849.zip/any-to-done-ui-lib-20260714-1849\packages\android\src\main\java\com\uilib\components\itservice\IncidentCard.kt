﻿package com.uilib.components.itservice

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 故障 - field-deep aligned shell (Compose) */
@Composable
fun IncidentCard(
    incidentId: String = "",
    title: String = "",
    level: String = "",
    status: String = "",
    assignee: String = "",
    createdAt: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "故障",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to incidentId,
            "标题" to title,
            "等级" to level,
            "处理人" to assignee,
            "开始时间" to createdAt,
        ),
        modifier = modifier,
    )
}
