import SwiftUI

/// 分栏 - advanced industry (SwiftUI)
public struct SplitPane: View {
    public var orientation: String = ""
    public var primarySize: String = ""
    public var minSize: String = ""

    public init(orientation: String = "", primarySize: String = "", minSize: String = "") {
        self.orientation = orientation
        self.primarySize = primarySize
        self.minSize = minSize
    }

    public var body: some View {
        IndustryCardShell(
            title: "分栏",
            status: nil,
            fields: [
            ("方向", orientation),
            ("主区尺寸", primarySize),
            ("最小尺寸", minSize),
            ]
        )
    }
}