﻿import SwiftUI

/// 服务单 - field-deep aligned shell (SwiftUI)
public struct ServiceTicketCard: View {
    public var id: String = ""
    public var ticketNumber: String = ""
    public var title: String = ""
    public var priority: String = ""
    public var assignee: String = ""
    public var status: String = ""
    public var client: String = ""

    public init(id: String = "", ticketNumber: String = "", title: String = "", priority: String = "", assignee: String = "", status: String = "", client: String = "") {
        self.id = id
        self.ticketNumber = ticketNumber
        self.title = title
        self.priority = priority
        self.assignee = assignee
        self.status = status
        self.client = client
    }

    public var body: some View {
        IndustryCardShell(
            title: "服务单",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("工单号", ticketNumber),
            ("标题", title),
            ("优先级", priority),
            ("处理人", assignee),
            ("客户", client),
            ]
        )
    }
}
