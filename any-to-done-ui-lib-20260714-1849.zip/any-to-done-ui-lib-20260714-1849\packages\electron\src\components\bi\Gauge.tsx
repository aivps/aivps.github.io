import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface GaugeProps {
  label?: string;
  value?: string;
  min?: string;
  max?: string;
  unit?: string;
  status?: string;
  onClick?: () => void;
}

/** Gauge - Electron shell (field keys aligned to React) */
export const Gauge: React.FC<GaugeProps> = (props) => (
  <IndustryCardShell title="Gauge" status={props.status} onClick={props.onClick}>
      {props.label ? <div className="row"><span className="label">label</span><span>{props.label}</span></div> : null}
      {props.value ? <div className="row"><span className="label">value</span><span>{props.value}</span></div> : null}
      {props.min ? <div className="row"><span className="label">min</span><span>{props.min}</span></div> : null}
      {props.max ? <div className="row"><span className="label">max</span><span>{props.max}</span></div> : null}
      {props.unit ? <div className="row"><span className="label">unit</span><span>{props.unit}</span></div> : null}
  </IndustryCardShell>
);

export default Gauge;