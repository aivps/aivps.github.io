﻿import SwiftUI

/// 报修单 - field-deep aligned shell (SwiftUI)
public struct RepairTicketCard: View {
    public var id: String = ""
    public var title: String = ""
    public var location: String = ""
    public var priority: String = ""
    public var status: String = ""
    public var reporter: String = ""
    public var assignee: String = ""

    public init(id: String = "", title: String = "", location: String = "", priority: String = "", status: String = "", reporter: String = "", assignee: String = "") {
        self.id = id
        self.title = title
        self.location = location
        self.priority = priority
        self.status = status
        self.reporter = reporter
        self.assignee = assignee
    }

    public var body: some View {
        IndustryCardShell(
            title: "报修单",
            status: status.isEmpty ? nil : status,
            fields: [
            ("单号", id),
            ("问题", title),
            ("位置", location),
            ("优先级", priority),
            ("报修人", reporter),
            ("处理人", assignee),
            ]
        )
    }
}
