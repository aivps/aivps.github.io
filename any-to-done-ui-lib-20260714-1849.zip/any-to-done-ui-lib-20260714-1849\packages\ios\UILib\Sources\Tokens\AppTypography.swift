import SwiftUI

public enum AppTypography {
    public static let h1 = Font.system(size: 24, weight: .semibold)
    public static let h2 = Font.system(size: 20, weight: .semibold)
    public static let h3 = Font.system(size: 16, weight: .semibold)
    public static let body = Font.system(size: 14, weight: .regular)
    public static let caption = Font.system(size: 12, weight: .regular)
    public static let label = Font.system(size: 12, weight: .medium)
}