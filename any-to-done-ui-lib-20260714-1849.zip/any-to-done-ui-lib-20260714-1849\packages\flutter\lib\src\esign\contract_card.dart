import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// ContractCard — field-deep aligned to React ContractCard.
/// Canonical: flat props + English enums. Legacy Chinese status / contractNo accepted.
class ContractCard extends StatelessWidget {
  final String id;
  final String contractNumber;
  final String title;
  final List<String> parties;
  final String status; // draft | pending | signing | completed | expired | cancelled
  final double? amount;
  final String currency;
  final String? templateName;
  final String createdAt;
  final String? expiresAt;
  final String? signedAt;
  final int? signedCount;
  final int? totalSigners;
  final VoidCallback? onTap;
  final ValueChanged<String>? onView;
  final ValueChanged<String>? onSign;
  final ValueChanged<String>? onSend;
  final bool disabled;

  /// @deprecated aliases
  final String? contractNo;
  final String? createTime;
  final String? expireTime;
  final String? partyA;
  final String? partyB;
  final String? date;

  const ContractCard({
    super.key,
    this.id = '',
    this.contractNumber = '',
    this.title = '',
    this.parties = const [],
    required this.status,
    this.amount,
    this.currency = '¥',
    this.templateName,
    this.createdAt = '',
    this.expiresAt,
    this.signedAt,
    this.signedCount,
    this.totalSigners,
    this.onTap,
    this.onView,
    this.onSign,
    this.onSend,
    this.disabled = false,
    this.contractNo,
    this.createTime,
    this.expireTime,
    this.partyA,
    this.partyB,
    this.date,
  });

  String get _contractNumber =>
      contractNumber.isNotEmpty ? contractNumber : (contractNo ?? '');
  String get _createdAt =>
      createdAt.isNotEmpty ? createdAt : (createTime ?? date ?? '');
  String? get _expiresAt => expiresAt ?? expireTime;
  List<String> get _parties {
    if (parties.isNotEmpty) return parties;
    return [
      if (partyA != null) partyA!,
      if (partyB != null) partyB!,
    ];
  }

  static const _statusLabels = {
    'draft': '草稿',
    'pending': '待签署',
    'signing': '签署中',
    'completed': '已完成',
    'expired': '已过期',
    'cancelled': '已取消',
    '草稿': '草稿',
    '待签署': '待签署',
    '签署中': '签署中',
    '已完成': '已完成',
    '已过期': '已过期',
    '已作废': '已取消',
    '已取消': '已取消',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'pending':
      case '待签署':
        return colors.warning;
      case 'signing':
      case '签署中':
        return colors.primary;
      case 'completed':
      case '已完成':
        return colors.success;
      case 'expired':
      case 'cancelled':
      case '已过期':
      case '已作废':
      case '已取消':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);
    final displayParties = _parties;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onView?.call(id);
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (_contractNumber.isNotEmpty)
                          Text(_contractNumber, style: AppTypography.caption),
                        Text(title, style: AppTypography.h3),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(_statusLabel,
                        style: AppTypography.caption.copyWith(color: sc)),
                  ),
                ],
              ),
              if (amount != null) ...[
                const SizedBox(height: 8),
                Text(
                  '$currency${amount!.toStringAsFixed(0)}',
                  style: AppTypography.body.copyWith(fontWeight: FontWeight.w600),
                ),
              ],
              if (displayParties.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(displayParties.join(' · '), style: AppTypography.caption),
              ],
              const SizedBox(height: 8),
              Row(
                children: [
                  if (_createdAt.isNotEmpty)
                    Text(_createdAt, style: AppTypography.caption),
                  const Spacer(),
                  if (_expiresAt != null)
                    Text('至 $_expiresAt',
                        style: AppTypography.caption.copyWith(color: colors.warning)),
                ],
              ),
              if (signedCount != null && totalSigners != null) ...[
                const SizedBox(height: 8),
                Text('签署 $signedCount / $totalSigners',
                    style: AppTypography.caption),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
