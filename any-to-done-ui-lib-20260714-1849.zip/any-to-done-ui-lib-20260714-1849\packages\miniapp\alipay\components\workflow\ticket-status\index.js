/** TicketStatus - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'ticketNo': { type: String, value: '' },
    'type': { type: String, value: '' },
    'assignee': { type: String, value: '' },
    'updatedAt': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});