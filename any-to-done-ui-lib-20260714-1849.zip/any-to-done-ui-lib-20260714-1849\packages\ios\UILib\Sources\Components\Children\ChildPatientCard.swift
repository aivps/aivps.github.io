import SwiftUI

/// 患儿 - children industry (SwiftUI)
public struct ChildPatientCard: View {
    public var name: String = ""
    public var age: String = ""
    public var department: String = ""
    public var guardian: String = ""
    public var status: String = ""

    public init(name: String = "", age: String = "", department: String = "", guardian: String = "", status: String = "") {
        self.name = name
        self.age = age
        self.department = department
        self.guardian = guardian
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "患儿",
            status: status.isEmpty ? nil : status,
            fields: [
            ("名称", name),
            ("年龄", age),
            ("科室", department),
            ("监护人", guardian),
            ]
        )
    }
}