/// Enterprise UI Library for Flutter
/// Compatibility entry — prefer enterprise_ui_components.dart
library ui_lib;

export 'enterprise_ui_components.dart';