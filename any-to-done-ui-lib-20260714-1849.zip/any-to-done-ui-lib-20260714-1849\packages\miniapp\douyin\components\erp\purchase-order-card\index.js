/** 采购单 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'orderNumber': { type: String, value: '' },
    'supplier': { type: String, value: '' },
    'totalAmount': { type: String, value: '' },
    'status': { type: String, value: '' },
    'orderDate': { type: String, value: '' },
    'expectedDate': { type: String, value: '' },
    'buyer': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
