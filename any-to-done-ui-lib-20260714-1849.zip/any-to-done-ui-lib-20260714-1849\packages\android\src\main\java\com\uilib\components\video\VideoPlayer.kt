package com.uilib.components.video

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 播放器 - video industry (Compose) */
@Composable
fun VideoPlayer(
    title: String = "",
    src: String = "",
    duration: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "播放器",
        status = status.ifBlank { null },
        fields = listOf(
            "标题" to title,
            "源地址" to src,
            "时长" to duration,
        ),
        modifier = modifier,
    )
}