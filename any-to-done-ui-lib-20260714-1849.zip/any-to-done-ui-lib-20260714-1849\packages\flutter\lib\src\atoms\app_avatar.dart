import 'package:flutter/material.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';

/// 头像尺寸
enum AvatarSize {
  xs,
  sm,
  md,
  lg,
  xl,
}

/// 头像形状
enum AvatarShape {
  circle,
  square,
  rounded,
}

/// AppAvatar 头像组件
class AppAvatar extends StatelessWidget {
  final String? src;
  final String? alt;
  final AvatarSize size;
  final AvatarShape shape;
  final Widget? icon;
  final String? text;

  const AppAvatar({
    super.key,
    this.src,
    this.alt,
    this.size = AvatarSize.md,
    this.shape = AvatarShape.circle,
    this.icon,
    this.text,
  });

  @override
  Widget build(BuildContext context) {
    final sizePx = _getSizePx();

    if (src != null && src!.isNotEmpty) {
      return ClipOval(
        child: Image.network(
          src!,
          width: sizePx,
          height: sizePx,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) => _buildPlaceholder(),
        ),
      );
    }

    if (icon != null) {
      return Container(
        width: sizePx,
        height: sizePx,
        decoration: _getDecoration(),
        child: Center(child: icon),
      );
    }

    return Container(
      width: sizePx,
      height: sizePx,
      decoration: _getDecoration(),
      child: Center(
        child: Text(
          _getInitials(),
          style: TextStyle(
            fontSize: _getFontSize(),
            fontWeight: FontWeight.w600,
            color: AppColors.gray0,
          ),
        ),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Container(
      width: _getSizePx(),
      height: _getSizePx(),
      decoration: _getDecoration(),
      child: Center(
        child: Icon(
          Icons.person,
          size: _getSizePx() * 0.5,
          color: AppColors.gray0,
        ),
      ),
    );
  }

  String _getInitials() {
    if (text == null || text!.isEmpty) return '?';
    final parts = text!.trim().split(' ');
    if (parts.length == 1) return parts[0][0].toUpperCase();
    return '${parts[0][0]}${parts[parts.length - 1][0]}'.toUpperCase();
  }

  double _getSizePx() {
    switch (size) {
      case AvatarSize.xs:
        return 24;
      case AvatarSize.sm:
        return 32;
      case AvatarSize.md:
        return 40;
      case AvatarSize.lg:
        return 56;
      case AvatarSize.xl:
        return 80;
    }
  }

  double _getFontSize() {
    switch (size) {
      case AvatarSize.xs:
        return 12;
      case AvatarSize.sm:
        return 14;
      case AvatarSize.md:
        return 16;
      case AvatarSize.lg:
        return 24;
      case AvatarSize.xl:
        return 32;
    }
  }

  BoxDecoration _getDecoration() {
    return BoxDecoration(
      color: AppColors.primary,
      shape: shape == AvatarShape.circle ? BoxShape.circle : BoxShape.rectangle,
      borderRadius: shape == AvatarShape.rounded
          ? BorderRadius.circular(AppRadius.md)
          : shape == AvatarShape.square
              ? BorderRadius.circular(AppRadius.sm)
              : null,
    );
  }
}

/// AppAvatarGroup 头像组
class AppAvatarGroup extends StatelessWidget {
  final List<AppAvatar> avatars;
  final int max;

  const AppAvatarGroup({
    super.key,
    required this.avatars,
    this.max = 5,
  });

  @override
  Widget build(BuildContext context) {
    final visible = avatars.take(max).toList();
    final overflow = avatars.length - max;

    return Row(
      children: [
        for (int i = 0; i < visible.length; i++)
          Transform.translate(
            offset: Offset(i * -8.0, 0),
            child: visible[i],
          ),
        if (overflow > 0)
          Transform.translate(
            offset: Offset((visible.length) * -8.0, 0),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.gray200,
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  '+$overflow',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.gray700,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
