import 'package:flutter/material.dart';

/// Design Tokens - Colors
/// 六色系 + 灰阶 + 浅色/暗黑主题
class AppColors {
  AppColors._();

  // 六色系
  static const Color primary = Color(0xFF1677FF);
  static const Color danger = Color(0xFFF53F3F);
  static const Color success = Color(0xFF00B42A);
  static const Color purple = Color(0xFF722ED1);
  static const Color cyan = Color(0xFF13C2C2);
  static const Color orange = Color(0xFFFA8C16);

  // 蓝色系
  static const Color blue50 = Color(0xFFE6F4FF);
  static const Color blue100 = Color(0xFFBAE0FF);
  static const Color blue200 = Color(0xFF91CAFF);
  static const Color blue300 = Color(0xFF69B1FF);
  static const Color blue400 = Color(0xFF4096FF);
  static const Color blue500 = Color(0xFF1677FF);
  static const Color blue600 = Color(0xFF0958D9);
  static const Color blue700 = Color(0xFF003EB3);
  static const Color blue800 = Color(0xFF002C8C);
  static const Color blue900 = Color(0xFF001D66);

  // 红色系
  static const Color red50 = Color(0xFFFFF1F0);
  static const Color red100 = Color(0xFFFFCCC7);
  static const Color red200 = Color(0xFFFFA39E);
  static const Color red300 = Color(0xFFFF7875);
  static const Color red400 = Color(0xFFFF4D4F);
  static const Color red500 = Color(0xFFF53F3F);
  static const Color red600 = Color(0xFFDC2828);
  static const Color red700 = Color(0xFFA8071A);
  static const Color red800 = Color(0xFF820014);
  static const Color red900 = Color(0xFF5C0011);

  // 绿色系
  static const Color green50 = Color(0xFFF6FFED);
  static const Color green100 = Color(0xFFD9F7BE);
  static const Color green200 = Color(0xFFB7EB8F);
  static const Color green300 = Color(0xFF95DE64);
  static const Color green400 = Color(0xFF73D13D);
  static const Color green500 = Color(0xFF00B42A);
  static const Color green600 = Color(0xFF389E0D);
  static const Color green700 = Color(0xFF237804);
  static const Color green800 = Color(0xFF135200);
  static const Color green900 = Color(0xFF092B00);

  // 紫色系
  static const Color purple50 = Color(0xFFF9F0FF);
  static const Color purple100 = Color(0xFFEFDBFF);
  static const Color purple200 = Color(0xFFD3ADF7);
  static const Color purple300 = Color(0xFFB37FEB);
  static const Color purple400 = Color(0xFF9254DE);
  static const Color purple500 = Color(0xFF722ED1);
  static const Color purple600 = Color(0xFF531DAB);
  static const Color purple700 = Color(0xFF391085);
  static const Color purple800 = Color(0xFF22075E);
  static const Color purple900 = Color(0xFF120338);

  // 青色系
  static const Color cyan50 = Color(0xFFE6FFFB);
  static const Color cyan100 = Color(0xFFB5F5EC);
  static const Color cyan200 = Color(0xFF87E8DE);
  static const Color cyan300 = Color(0xFF5CDBD3);
  static const Color cyan400 = Color(0xFF36CFC9);
  static const Color cyan500 = Color(0xFF13C2C2);
  static const Color cyan600 = Color(0xFF08979C);
  static const Color cyan700 = Color(0xFF006D75);
  static const Color cyan800 = Color(0xFF00474F);
  static const Color cyan900 = Color(0xFF002329);

  // 橙色系
  static const Color orange50 = Color(0xFFFFF7E6);
  static const Color orange100 = Color(0xFFFFE7BA);
  static const Color orange200 = Color(0xFFFFD591);
  static const Color orange300 = Color(0xFFFFBF69);
  static const Color orange400 = Color(0xFFFFA940);
  static const Color orange500 = Color(0xFFFA8C16);
  static const Color orange600 = Color(0xFFD46B08);
  static const Color orange700 = Color(0xFFAD4E00);
  static const Color orange800 = Color(0xFF873800);
  static const Color orange900 = Color(0xFF612500);

  // 灰阶
  static const Color gray0 = Color(0xFFFFFFFF);
  static const Color gray50 = Color(0xFFFAFAFA);
  static const Color gray100 = Color(0xFFF5F7FA);
  static const Color gray200 = Color(0xFFE8EAED);
  static const Color gray300 = Color(0xFFD9DCE1);
  static const Color gray400 = Color(0xFFC4C9CF);
  static const Color gray500 = Color(0xFF8D939D);
  static const Color gray600 = Color(0xFF6B7280);
  static const Color gray700 = Color(0xFF4B5563);
  static const Color gray800 = Color(0xFF374151);
  static const Color gray900 = Color(0xFF1F2937);
  static const Color gray1000 = Color(0xFF111827);
  static const Color gray1100 = Color(0xFF030712);

  // 语义别名（行业卡片常用）
  static const Color surface = gray0;
  static const Color background = gray100;
  static const Color foreground = gray900;
  static const Color muted = gray500;
  static const Color border = gray200;

  // 浅色主题
  static const Color lightBg = gray100;
  static const Color lightSurface = gray0;
  static const Color lightFg = gray900;
  static const Color lightMuted = gray500;
  static const Color lightBorder = gray200;
  static const Color lightDisabled = gray300;

  // 暗黑主题
  static const Color darkBg = gray1100;
  static const Color darkSurface = gray1000;
  static const Color darkFg = gray0;
  static const Color darkMuted = gray500;
  static const Color darkBorder = gray800;
  static const Color darkDisabled = gray700;
}
