# 截图验收流水线

> 无人值守：仓库根目录 `pnpm visual`  
> 脚本：`scripts/visual-check.ps1` · 目标清单：`scripts/visual-targets.json`  
> 报告：`scripts/visual-report.latest.md`

对 **`demo.html` / `preview.html`** 做固定视口截图，与 `visual-baselines/` 基线做 **SHA256** 对比。  
默认覆盖 **demo 全部可交互行业 section**（light；dark 抽样：`medical` / `global` / `ecommerce` / `video` / `workflow` / `finance` / `advanced` / `erp` / `logistics` / `manufacturing` / `monitor` / `bi` / `portrait` / `legal` / `property` / `education` / `fitness` / `wedding` / `advertising` / `bath` / `it-service` / `esign` / `gaming` / `hardware` / `children` / `k12` / `tools`）、`preview` 全页、小程序三端代理壳（合计约 **60** 帧）。  
小程序端默认走 **静态代理壳** `packages/miniapp/visual-host.html`（Edge headless，390×844），基线落在 `visual-baselines/manual/*_home.png`；有 DevTools 时可用真机/模拟器图覆盖同路径。

交互冒烟（点击 / toast，非截图）：`pnpm interact` → 见 `scripts/interact-check.ps1`。

---

## 1. 快速命令

```bash
# 截图 + 对比（需本机 Edge 或 Chrome）
pnpm visual

# 首次 / 有意改版后：用当前截图覆盖基线
pnpm visual:update

# 只截不比 / 只比不截
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/visual-check.ps1 -CaptureOnly
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/visual-check.ps1 -CompareOnly

# 只跑部分 id
powershell -File scripts/visual-check.ps1 -Only demo_medical_light,demo_global_dark
```

通过标准：`FAIL = 0`。`WARN` 多为「尚无基线」或「无小程序人工图」，不阻塞退出码（仅 FAIL 退出 1）。

---

## 2. 目录约定

| 路径 | 用途 |
|------|------|
| `scripts/visual-targets.json` | 视口尺寸、目标列表、小程序人工项说明 |
| `scripts/visual-out/actual/` | 本轮实际截图（可 gitignore） |
| `visual-baselines/*.png` | 已验收基线（建议入库） |
| `visual-baselines/manual/` | 微信/支付宝/抖音人工 PNG |
| `scripts/visual-report.latest.md` | 最近一次报告 |

命名：`{page}_{section}_{theme}.png`，与 targets 里 `id` 一致，如 `demo_medical_light.png`。

---

## 3. demo 隔离模式（稳定取景）

截图脚本会在仓库根目录临时生成 `.visual-harness-<id>.html`（gitignore），在 `<body>` 注入：

```js
window.__OD_VISUAL__ = { visual: 'medical', theme: 'dark' };
```

`demo.html` 读取后：只显示对应 `section`，隐藏顶栏与侧栏，并可强制浅/暗主题。

本地手测也可直接打开（查询参数 / hash 同样支持）：

```
demo.html?visual=medical&theme=dark
demo.html#visual=global&theme=light
```

`section` id 与侧栏锚点一致：`medical`、`ecommerce`、`global`、`advanced` 等。

> 说明：Windows 上 Chromium headless 对 `file://...?query` / 命令行 `#hash` 不稳定，故流水线用 harness 注入，不依赖 URL 参数。
---

## 4. 小程序（代理壳 + 可选人工）

### 4.1 默认：静态 visual-host（无人值守）

| 项 | 说明 |
|----|------|
| 页面 | `packages/miniapp/visual-host.html` |
| 取景 | harness 注入 `visual=weixin\|alipay\|douyin`，视口 **390×844** |
| 内容 | 与三端 `pages/index` 冒烟卡一致的 shell 镜像（icard + 样本数据） |
| 基线 | `visual-baselines/manual/{weixin,alipay,douyin}_home.png` |
| 命令 | `pnpm visual` / `pnpm visual:update`（targets 已含三项） |

手测可直接打开：

```
packages/miniapp/visual-host.html?platform=weixin
packages/miniapp/visual-host.html?platform=alipay
packages/miniapp/visual-host.html?platform=douyin
```

> **诚实边界**：这是 HTML 壳，**不是**微信/支付宝/抖音运行时；组件 JS 逻辑、真机字体、胶囊栏差异不会体现在代理图上。

### 4.2 可选：DevTools / 真机覆盖

1. 导入 `packages/miniapp/weixin`（或 alipay / douyin）。
2. 模拟器打开首页，布局正常后截图。
3. **覆盖** `visual-baselines/manual/` 同名 PNG。
4. 再跑 `pnpm visual`：SHA256 以你覆盖的图为准。

`pnpm visual:update` 会用代理壳重新生成 manual 基线；若要用真机图，update 后请勿提交代理覆盖。

---

## 5. 何时更新基线

- 有意改版 `demo.html` 对应区块视觉  
- Token / 卡片布局调整且已人工确认  
- 换机导致字体渲染差异、团队约定以本机为真时  

```bash
pnpm visual:update
# 再 git add visual-baselines/*.png
```

**不要**在未看图时无脑 update。

---

## 6. 诚实边界

| 能做 | 不能做 |
|------|--------|
| Edge/Chrome headless 固定视口 PNG | 像素级抗抖动 diff（当前是整图 hash） |
| demo 分 section 隔离 | 自动点交互路径（购物车/审批等状态机） |
| 小程序 visual-host 代理首页三帧 | 微信/支付宝/抖音 **真实** 模拟器无人值守 |
| preview 整页一帧 | Gradle / Xcode / 真机 UI 自动化 |

OS / 字体 / DPI 不同会导致 **无业务改动也 FAIL**。同机 CI 或 Docker 固定字体可降低噪声；跨机优先人工看 `actual` 与 baseline。

---

## 7. 扩展 targets

编辑 `scripts/visual-targets.json`：

```json
{
  "id": "demo_portrait_light",
  "page": "demo.html",
  "visual": "portrait",
  "theme": "light"
}
```

`preview.html` 无 visual 参数时截整页视口即可。
