package com.uilib.components.bi

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 仪表盘 - bi industry (Compose) */
@Composable
fun Gauge(
    label: String = "",
    value: String = "",
    min: String = "",
    max: String = "",
    unit: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "仪表盘",
        status = null,
        fields = listOf(
            "标签" to label,
            "数值" to value,
            "最小值" to min,
            "最大值" to max,
            "单位" to unit,
        ),
        modifier = modifier,
    )
}