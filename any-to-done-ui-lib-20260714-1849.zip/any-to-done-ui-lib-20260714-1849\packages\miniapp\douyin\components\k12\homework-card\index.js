/** HomeworkCard - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'title': { type: String, value: '' },
    'subject': { type: String, value: '' },
    'dueDate': { type: String, value: '' },
    'className': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});