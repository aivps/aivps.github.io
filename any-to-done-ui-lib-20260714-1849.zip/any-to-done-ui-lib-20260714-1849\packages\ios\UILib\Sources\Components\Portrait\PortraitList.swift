import SwiftUI

/// 画像列表 - portrait industry (SwiftUI)
public struct PortraitList: View {
    public var title: String = ""
    public var count: String = ""
    public var segment: String = ""
    public var status: String = ""

    public init(title: String = "", count: String = "", segment: String = "", status: String = "") {
        self.title = title
        self.count = count
        self.segment = segment
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "画像列表",
            status: status.isEmpty ? nil : status,
            fields: [
            ("标题", title),
            ("数量", count),
            ("分群", segment),
            ]
        )
    }
}