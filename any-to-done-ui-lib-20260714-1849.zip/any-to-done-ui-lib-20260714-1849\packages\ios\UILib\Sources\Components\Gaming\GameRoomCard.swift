import SwiftUI

/// 游戏房 - field-deep aligned shell (SwiftUI)
public struct GameRoomCard: View {
    public var id: String = ""
    public var roomNumber: String = ""
    public var gameName: String = ""
    public var playerCount: String = ""
    public var maxPlayers: String = ""
    public var status: String = ""

    public init(id: String = "", roomNumber: String = "", gameName: String = "", playerCount: String = "", maxPlayers: String = "", status: String = "") {
        self.id = id
        self.roomNumber = roomNumber
        self.gameName = gameName
        self.playerCount = playerCount
        self.maxPlayers = maxPlayers
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "游戏房",
            status: status.isEmpty ? nil : status,
            fields: [
                ("ID", id),
                ("房间号", roomNumber),
                ("游戏", gameName),
                ("玩家数", playerCount),
                ("人数上限", maxPlayers),
            ]
        )
    }
}
