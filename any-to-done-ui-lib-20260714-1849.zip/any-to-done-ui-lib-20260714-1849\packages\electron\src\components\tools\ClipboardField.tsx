import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ClipboardFieldProps {
  label?: string;
  value?: string;
  status?: string;
  onClick?: () => void;
}

/** ClipboardField - Electron shell (field keys aligned to React) */
export const ClipboardField: React.FC<ClipboardFieldProps> = (props) => (
  <IndustryCardShell title="ClipboardField" status={props.status} onClick={props.onClick}>
      {props.label ? <div className="row"><span className="label">label</span><span>{props.label}</span></div> : null}
      {props.value ? <div className="row"><span className="label">value</span><span>{props.value}</span></div> : null}
  </IndustryCardShell>
);

export default ClipboardField;