import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface CartItemProps {
  id?: string | number;
  name?: string | number;
  price?: string | number;
  quantity?: string | number;
  sku?: string | number;
  selected?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 购物车项 - medical/ecommerce (Electron, field-deep aligned) */
export const CartItem: React.FC<CartItemProps> = ({
  id,
  name,
  price,
  quantity,
  sku,
  selected,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="购物车项"
    fields={[
    { label: 'ID', value: id },
    { label: '名称', value: name },
    { label: '价格', value: price },
    { label: '数量', value: quantity },
    { label: 'SKU', value: sku },
    { label: '已选', value: selected },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default CartItem;
