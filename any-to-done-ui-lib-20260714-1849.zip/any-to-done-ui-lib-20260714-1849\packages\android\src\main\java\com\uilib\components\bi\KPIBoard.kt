package com.uilib.components.bi

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** KPI - bi industry (Compose) */
@Composable
fun KPIBoard(
    name: String = "",
    value: String = "",
    target: String = "",
    unit: String = "",
    trend: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "KPI",
        status = null,
        fields = listOf(
            "名称" to name,
            "数值" to value,
            "目标" to target,
            "单位" to unit,
            "趋势" to trend,
        ),
        modifier = modifier,
    )
}