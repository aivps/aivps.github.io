// logistics industry exports
export 'inventory_card.dart';
export 'transport_card.dart';
