package com.uilib.components.tools

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 剪贴板 - tools industry (Compose) */
@Composable
fun ClipboardField(
    label: String = "",
    value: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "剪贴板",
        status = null,
        fields = listOf(
            "标签" to label,
            "数值" to value,
        ),
        modifier = modifier,
    )
}