import 'package:flutter/material.dart';
/// VirtualList 虚拟列表壳（基于 ListView.builder）
class VirtualList<T> extends StatelessWidget {
  final List<T> items;
  final Widget Function(BuildContext context, T item, int index) itemBuilder;
  final double? itemExtent;
  final EdgeInsetsGeometry? padding;
  final bool shrinkWrap;

  const VirtualList({
    super.key,
    required this.items,
    required this.itemBuilder,
    this.itemExtent,
    this.padding,
    this.shrinkWrap = false,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: padding,
      itemExtent: itemExtent,
      shrinkWrap: shrinkWrap,
      physics: shrinkWrap ? const NeverScrollableScrollPhysics() : null,
      itemCount: items.length,
      itemBuilder: (context, index) => itemBuilder(context, items[index], index),
    );
  }
}