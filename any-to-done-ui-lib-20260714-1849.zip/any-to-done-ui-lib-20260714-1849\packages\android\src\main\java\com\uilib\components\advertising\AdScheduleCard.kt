package com.uilib.components.advertising

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 投放排期 - advertising industry (Compose) */
@Composable
fun AdScheduleCard(
    campaign: String = "",
    slot: String = "",
    channel: String = "",
    date: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "投放排期",
        status = status.ifBlank { null },
        fields = listOf(
            "活动" to campaign,
            "时段" to slot,
            "渠道" to channel,
            "日期" to date,
        ),
        modifier = modifier,
    )
}