import SwiftUI

/// 报销单 - field-deep aligned shell (SwiftUI)
public struct ExpenseReportCard: View {
    public var reportId: String = ""
    public var reportName: String = ""
    public var applicant: String = ""
    public var department: String = ""
    public var submitDate: String = ""
    public var totalAmount: String = ""
    public var status: String = ""

    public init(reportId: String = "", reportName: String = "", applicant: String = "", department: String = "", submitDate: String = "", totalAmount: String = "", status: String = "") {
        self.reportId = reportId
        self.reportName = reportName
        self.applicant = applicant
        self.department = department
        self.submitDate = submitDate
        self.totalAmount = totalAmount
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "报销单",
            status: status.isEmpty ? nil : status,
            fields: [
            ("单号", reportId),
            ("名称", reportName),
            ("申请人", applicant),
            ("部门", department),
            ("提交日期", submitDate),
            ("金额", totalAmount),
            ]
        )
    }
}