Component({
  properties: {
    current: { type: Number, value: 1 },
    total: { type: Number, value: 0 },
    pageSize: { type: Number, value: 10 },
    showSizeChanger: { type: Boolean, value: false },
  },
  computed: {},
  methods: {
    onPageChange(e) {
      const page = e.currentTarget.dataset.page;
      this.triggerEvent('change', { page });
    },
    onPrev() {
      if (this.data.current > 1) {
        this.triggerEvent('change', { page: this.data.current - 1 });
      }
    },
    onNext() {
      const totalPages = Math.ceil(this.data.total / this.data.pageSize);
      if (this.data.current < totalPages) {
        this.triggerEvent('change', { page: this.data.current + 1 });
      }
    },
  },
});
