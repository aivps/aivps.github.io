import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface DeviceStatusProps {
  deviceId?: string;
  name?: string;
  location?: string;
  status?: string;
  online?: string;
  onClick?: () => void;
}

/** DeviceStatus - Electron shell (field keys aligned to React) */
export const DeviceStatus: React.FC<DeviceStatusProps> = (props) => (
  <IndustryCardShell title="DeviceStatus" status={props.status} onClick={props.onClick}>
      {props.deviceId ? <div className="row"><span className="label">deviceId</span><span>{props.deviceId}</span></div> : null}
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.location ? <div className="row"><span className="label">location</span><span>{props.location}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
      {props.online ? <div className="row"><span className="label">online</span><span>{props.online}</span></div> : null}
  </IndustryCardShell>
);

export default DeviceStatus;
