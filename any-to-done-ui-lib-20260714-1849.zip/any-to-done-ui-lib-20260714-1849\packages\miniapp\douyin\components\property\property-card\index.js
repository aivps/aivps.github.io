/** 房源 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'title': { type: String, value: '' },
    'price': { type: String, value: '' },
    'area': { type: String, value: '' },
    'rooms': { type: String, value: '' },
    'address': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
