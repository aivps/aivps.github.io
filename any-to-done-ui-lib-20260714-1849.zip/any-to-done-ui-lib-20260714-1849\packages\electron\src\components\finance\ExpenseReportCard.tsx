import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ExpenseReportCardProps {
  reportId?: string | number;
  reportName?: string | number;
  applicant?: string | number;
  department?: string | number;
  submitDate?: string | number;
  totalAmount?: string | number;
  status?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 报销单 - field-deep aligned shell */
export const ExpenseReportCard: React.FC<ExpenseReportCardProps> = ({
  reportId,
  reportName,
  applicant,
  department,
  submitDate,
  totalAmount,
  status,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="报销单"
    status={status}
    fields={[
    { label: '单号', value: reportId },
    { label: '名称', value: reportName },
    { label: '申请人', value: applicant },
    { label: '部门', value: department },
    { label: '提交日期', value: submitDate },
    { label: '金额', value: totalAmount },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ExpenseReportCard;