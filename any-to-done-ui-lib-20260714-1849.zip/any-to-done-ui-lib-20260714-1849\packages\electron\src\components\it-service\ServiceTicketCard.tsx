import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ServiceTicketCardProps {
  id?: string | number;
  ticketNumber?: string | number;
  title?: string | number;
  priority?: string | number;
  assignee?: string | number;
  status?: string;
  client?: string | number;
  /** @deprecated use ticketNumber */
  ticketNo?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 服务单 - field-deep aligned shell */
export const ServiceTicketCard: React.FC<ServiceTicketCardProps> = ({
  id,
  ticketNumber,
  title,
  priority,
  assignee,
  status,
  client,
  ticketNo,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="服务单"
    status={status}
    fields={[
      { label: 'ID', value: id },
      { label: '工单号', value: ticketNumber ?? ticketNo },
      { label: '标题', value: title },
      { label: '优先级', value: priority },
      { label: '处理人', value: assignee },
      { label: '客户', value: client },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default ServiceTicketCard;
