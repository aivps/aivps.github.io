import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface TicketStatusProps {
  ticketNo?: string;
  type?: string;
  assignee?: string;
  updatedAt?: string;
  status?: string;
  onClick?: () => void;
}

/** TicketStatus - Electron shell (field keys aligned to React) */
export const TicketStatus: React.FC<TicketStatusProps> = (props) => (
  <IndustryCardShell title="TicketStatus" status={props.status} onClick={props.onClick}>
      {props.ticketNo ? <div className="row"><span className="label">ticketNo</span><span>{props.ticketNo}</span></div> : null}
      {props.type ? <div className="row"><span className="label">type</span><span>{props.type}</span></div> : null}
      {props.assignee ? <div className="row"><span className="label">assignee</span><span>{props.assignee}</span></div> : null}
      {props.updatedAt ? <div className="row"><span className="label">updatedAt</span><span>{props.updatedAt}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default TicketStatus;