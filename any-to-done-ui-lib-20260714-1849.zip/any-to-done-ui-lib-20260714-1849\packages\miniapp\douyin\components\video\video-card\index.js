/** VideoCard - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'title': { type: String, value: '' },
    'duration': { type: String, value: '' },
    'views': { type: String, value: '' },
    'likes': { type: String, value: '' },
    'status': { type: String, value: '' },
    'author': { type: String, value: '' },
    'category': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});