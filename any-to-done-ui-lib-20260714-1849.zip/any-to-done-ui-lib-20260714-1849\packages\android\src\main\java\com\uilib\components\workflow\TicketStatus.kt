package com.uilib.components.workflow

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 工单状态 - workflow industry (Compose) */
@Composable
fun TicketStatus(
    ticketNo: String = "",
    type: String = "",
    assignee: String = "",
    updatedAt: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "工单状态",
        status = status.ifBlank { null },
        fields = listOf(
            "工单号" to ticketNo,
            "类型" to type,
            "处理人" to assignee,
            "更新时间" to updatedAt,
        ),
        modifier = modifier,
    )
}