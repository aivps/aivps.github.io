import SwiftUI

/// 库存 - field-deep aligned shell (SwiftUI)
public struct InventoryCard: View {
    public var id: String = ""
    public var name: String = ""
    public var sku: String = ""
    public var quantity: String = ""
    public var unit: String = ""
    public var location: String = ""
    public var status: String = ""

    public init(id: String = "", name: String = "", sku: String = "", quantity: String = "", unit: String = "", location: String = "", status: String = "") {
        self.id = id
        self.name = name
        self.sku = sku
        self.quantity = quantity
        self.unit = unit
        self.location = location
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "库存",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("名称", name),
            ("SKU", sku),
            ("数量", quantity),
            ("单位", unit),
            ("库位", location),
            ]
        )
    }
}