import SwiftUI

/// 发票 - field-deep aligned shell (SwiftUI)
public struct InvoiceCard: View {
    public var id: String = ""
    public var invoiceNumber: String = ""
    public var type: String = ""
    public var client: String = ""
    public var amount: String = ""
    public var tax: String = ""
    public var total: String = ""
    public var status: String = ""
    public var issueDate: String = ""
    public var dueDate: String = ""

    public init(id: String = "", invoiceNumber: String = "", type: String = "", client: String = "", amount: String = "", tax: String = "", total: String = "", status: String = "", issueDate: String = "", dueDate: String = "") {
        self.id = id
        self.invoiceNumber = invoiceNumber
        self.type = type
        self.client = client
        self.amount = amount
        self.tax = tax
        self.total = total
        self.status = status
        self.issueDate = issueDate
        self.dueDate = dueDate
    }

    public var body: some View {
        IndustryCardShell(
            title: "发票",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("发票号", invoiceNumber),
            ("类型", type),
            ("客户", client),
            ("金额", amount),
            ("税额", tax),
            ("合计", total),
            ("开票日期", issueDate),
            ("到期日", dueDate),
            ]
        )
    }
}