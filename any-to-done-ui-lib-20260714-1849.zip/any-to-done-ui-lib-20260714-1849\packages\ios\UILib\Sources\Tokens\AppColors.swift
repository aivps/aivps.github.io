import SwiftUI

/// Semantic color scheme for light / dark (aligned with React lightTheme / darkTheme).
public struct UiColorScheme: Equatable {
    public let blue: Color
    public let blueLight: Color
    public let red: Color
    public let green: Color
    public let purple: Color
    public let cyan: Color
    public let orange: Color
    public let surface: Color
    public let background: Color
    public let foreground: Color
    public let muted: Color
    public let border: Color
    public let gray100: Color
    public let gray200: Color
    public let gray700: Color
    public let gray900: Color
    public let primary: Color
    public let primaryBg: Color

    public static let light = UiColorScheme(
        blue: Color(red: 0.086, green: 0.467, blue: 1.0),
        blueLight: Color(red: 0.902, green: 0.957, blue: 1.0),
        red: Color(red: 0.961, green: 0.247, blue: 0.247),
        green: Color(red: 0.0, green: 0.706, blue: 0.165),
        purple: Color(red: 0.447, green: 0.180, blue: 0.820),
        cyan: Color(red: 0.075, green: 0.761, blue: 0.761),
        orange: Color(red: 0.980, green: 0.549, blue: 0.086),
        surface: Color.white,
        background: Color(red: 0.961, green: 0.969, blue: 0.980),
        foreground: Color(red: 0.067, green: 0.094, blue: 0.153),
        muted: Color(red: 0.420, green: 0.447, blue: 0.502),
        border: Color(red: 0.910, green: 0.910, blue: 0.910),
        gray100: Color(red: 0.953, green: 0.957, blue: 0.965),
        gray200: Color(red: 0.898, green: 0.906, blue: 0.922),
        gray700: Color(red: 0.216, green: 0.255, blue: 0.318),
        gray900: Color(red: 0.067, green: 0.094, blue: 0.153),
        primary: Color(red: 0.086, green: 0.467, blue: 1.0),
        primaryBg: Color(red: 0.902, green: 0.957, blue: 1.0)
    )

    public static let dark = UiColorScheme(
        blue: Color(red: 0.086, green: 0.408, blue: 0.863),
        blueLight: Color(red: 0.086, green: 0.408, blue: 0.863).opacity(0.15),
        red: Color(red: 0.863, green: 0.267, blue: 0.267),
        green: Color(red: 0.286, green: 0.667, blue: 0.098),
        purple: Color(red: 0.573, green: 0.329, blue: 0.871),
        cyan: Color(red: 0.212, green: 0.812, blue: 0.788),
        orange: Color(red: 0.847, green: 0.588, blue: 0.078),
        surface: Color(red: 0.122, green: 0.122, blue: 0.122),
        background: Color(red: 0.039, green: 0.039, blue: 0.039),
        foreground: Color(red: 0.910, green: 0.910, blue: 0.910),
        muted: Color(red: 0.639, green: 0.639, blue: 0.639),
        border: Color(red: 0.188, green: 0.188, blue: 0.188),
        gray100: Color(red: 0.122, green: 0.122, blue: 0.122),
        gray200: Color(red: 0.188, green: 0.188, blue: 0.188),
        gray700: Color(red: 0.639, green: 0.639, blue: 0.639),
        gray900: Color(red: 0.910, green: 0.910, blue: 0.910),
        primary: Color(red: 0.086, green: 0.408, blue: 0.863),
        primaryBg: Color(red: 0.086, green: 0.408, blue: 0.863).opacity(0.15)
    )
}

private struct UiColorSchemeKey: EnvironmentKey {
    static let defaultValue: UiColorScheme = .light
}

public extension EnvironmentValues {
    var uiColors: UiColorScheme {
        get { self[UiColorSchemeKey.self] }
        set { self[UiColorSchemeKey.self] = newValue }
    }
}

public extension View {
    /// Apply UILib light/dark semantic colors to the view tree.
    func uiLibTheme(isDark: Bool) -> some View {
        environment(\.uiColors, isDark ? .dark : .light)
    }
}

/// Static light defaults (backward compatible). Prefer `@Environment(\.uiColors)`.
public enum AppColors {
    public static let blue = UiColorScheme.light.blue
    public static let blueLight = UiColorScheme.light.blueLight
    public static let red = UiColorScheme.light.red
    public static let green = UiColorScheme.light.green
    public static let purple = UiColorScheme.light.purple
    public static let cyan = UiColorScheme.light.cyan
    public static let orange = UiColorScheme.light.orange
    public static let surface = UiColorScheme.light.surface
    public static let background = UiColorScheme.light.background
    public static let foreground = UiColorScheme.light.foreground
    public static let muted = UiColorScheme.light.muted
    public static let border = UiColorScheme.light.border
    public static let gray100 = UiColorScheme.light.gray100
    public static let gray700 = UiColorScheme.light.gray700
}
