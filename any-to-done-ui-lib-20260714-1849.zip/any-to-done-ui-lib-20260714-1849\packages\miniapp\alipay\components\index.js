/**
 * 小程序组件库入口
 * 企业级跨端UI组件库 - 微信小程序版本
 * Phase 4: industry components (aligned with RN/Flutter)
 */

module.exports = {
  version: '1.0.0',
  components: [
    // Atoms
    'button', 'input', 'card', 'tag', 'switch', 'badge', 'avatar', 'divider', 'tooltip', 'slider',
    // Form
    'checkbox', 'radio', 'select',
    // Feedback
    'modal', 'toast',
    // Navigation
    'steps',
    // Data Display
    'progress', 'tabs', 'pagination',
    // Industry (Phase 4)
    'medical/patient-card',
    'medical/medical-record-card',
    'finance/invoice-card',
    'finance/expense-report-card',
    'ecommerce/product-card',
    'ecommerce/cart-item',
    'hardware/charging-station',
    'hardware/device-status-card',
    'manufacturing/production-panel',
    'manufacturing/production-line-card',
    'wedding/wedding-card',
    'wedding/guest-list-card',
    'legal/case-card',
    'legal/evidence-card',
    'fitness/member-card',
    'fitness/fitness-course-card',
    'property/property-card',
    'property/repair-ticket-card',
    'education/course-card',
    'education/class-schedule',
    'logistics/inventory-card',
    'logistics/transport-card',
    'it-service/service-ticket-card',
    'it-service/incident-card',
    'esign/contract-card',
    'esign/signing-progress',
    'video/video-card',
    'video/video-player',
    'erp/purchase-order-card',
    'erp/sales-order-card',
    'bath/room-status-card',
    'bath/service-menu-card',
    'gaming/game-room-card',
    'gaming/player-list-card',
    'advertising/campaign-card',
    'advertising/ad-schedule-card',
    'children/student-card',
    'children/child-patient-card',
    'k12/homework-card',
    'k12/student-record-card',
    'monitor/server-status',
    'monitor/device-status',
    'workflow/approval-flow',
    'workflow/ticket-status',
    'bi/kpi-board',
    'bi/gauge',
    'advanced/virtual-list',
    'advanced/split-pane',
    'portrait/portrait-kpi',
    'portrait/portrait-list',
    'tools/clipboard-field',
    'tools/watermark',
  ],
};