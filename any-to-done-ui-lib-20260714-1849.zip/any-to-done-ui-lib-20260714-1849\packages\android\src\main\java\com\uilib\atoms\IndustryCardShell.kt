package com.uilib.atoms

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.uilib.tokens.AppMotion
import com.uilib.tokens.AppSpacing
import com.uilib.tokens.AppTypography
import com.uilib.tokens.uiColors

@Composable
fun IndustryCardShell(
    title: String,
    status: String? = null,
    fields: List<Pair<String, String>>,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    val colors = uiColors
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed && onClick != null) AppMotion.pressScale else 1f,
        animationSpec = tween(AppMotion.durationFastMs),
        label = "cardPressScale",
    )
    val borderColor = if (pressed && onClick != null) colors.primary else colors.border

    Column(
        modifier = modifier
            .fillMaxWidth()
            .scale(scale)
            .shadow(if (pressed) 4.dp else 2.dp, RoundedCornerShape(AppSpacing.radiusLg))
            .clip(RoundedCornerShape(AppSpacing.radiusLg))
            .background(colors.surface)
            .border(1.dp, borderColor, RoundedCornerShape(AppSpacing.radiusLg))
            .then(
                if (onClick != null) {
                    Modifier.pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                pressed = true
                                tryAwaitRelease()
                                pressed = false
                            },
                            onTap = { onClick() },
                        )
                    }
                } else Modifier
            )
            .padding(horizontal = AppSpacing.xl, vertical = AppSpacing.lg),
        verticalArrangement = Arrangement.spacedBy(AppSpacing.sm)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = title, style = AppTypography.h3, color = colors.foreground)
            if (!status.isNullOrBlank()) {
                AppTag(text = status)
            }
        }
        fields.filter { it.second.isNotBlank() }.forEach { (label, value) ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = label, style = AppTypography.caption, color = colors.muted)
                Text(text = value, style = AppTypography.body, color = colors.gray700)
            }
        }
    }
}
