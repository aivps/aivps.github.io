import React from 'react';
import { colors, spacing, typography } from '../tokens';

export interface TitleBarProps {
  title: string;
  platform?: 'darwin' | 'win32' | 'linux';
  onMinimize?: () => void;
  onMaximize?: () => void;
  onClose?: () => void;
  style?: React.CSSProperties;
}

/** Frameless Electron window title bar with drag region */
export const TitleBar: React.FC<TitleBarProps> = ({
  title,
  platform = typeof process !== 'undefined' && process.platform === 'darwin' ? 'darwin' : 'win32',
  onMinimize,
  onMaximize,
  onClose,
  style,
}) => {
  const isMac = platform === 'darwin';
  return (
    <header
      style={{
        height: 40,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: `0 ${spacing.md}px`,
        background: colors.surface,
        borderBottom: `1px solid ${colors.border}`,
        WebkitAppRegion: 'drag',
        userSelect: 'none',
        ...style,
      } as React.CSSProperties}
    >
      {isMac ? (
        <div style={{ display: 'flex', gap: 8, WebkitAppRegion: 'no-drag' } as React.CSSProperties}>
          <Traffic light="#FF5F57" onClick={onClose} />
          <Traffic light="#FEBC2E" onClick={onMinimize} />
          <Traffic light="#28C840" onClick={onMaximize} />
        </div>
      ) : (
        <div style={{ width: 80 }} />
      )}
      <span style={{ fontSize: 13, color: colors.muted, fontWeight: 500 }}>{title}</span>
      {!isMac ? (
        <div style={{ display: 'flex', WebkitAppRegion: 'no-drag' } as React.CSSProperties}>
          <WinBtn label="-" onClick={onMinimize} />
          <WinBtn label="[]" onClick={onMaximize} />
          <WinBtn label="x" onClick={onClose} danger />
        </div>
      ) : (
        <div style={{ width: 80 }} />
      )}
    </header>
  );
};

const Traffic: React.FC<{ light: string; onClick?: () => void }> = ({ light, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    aria-label="window control"
    style={{
      width: 12,
      height: 12,
      borderRadius: '50%',
      border: 'none',
      background: light,
      cursor: 'pointer',
      padding: 0,
    }}
  />
);

const WinBtn: React.FC<{ label: string; onClick?: () => void; danger?: boolean }> = ({
  label,
  onClick,
  danger,
}) => (
  <button
    type="button"
    onClick={onClick}
    style={{
      width: 46,
      height: 32,
      border: 'none',
      background: 'transparent',
      color: colors.foreground,
      fontSize: 14,
      cursor: 'pointer',
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.background = danger ? colors.red : colors.gray100;
      if (danger) e.currentTarget.style.color = '#fff';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.background = 'transparent';
      e.currentTarget.style.color = colors.foreground;
    }}
  >
    {label}
  </button>
);

export interface ContextMenuItem {
  id: string;
  label: string;
  disabled?: boolean;
  danger?: boolean;
  separator?: boolean;
}

export interface ContextMenuProps {
  open: boolean;
  x: number;
  y: number;
  items: ContextMenuItem[];
  onSelect: (id: string) => void;
  onClose: () => void;
}

/** Desktop-style context menu for Electron renderer */
export const ContextMenu: React.FC<ContextMenuProps> = ({ open, x, y, items, onSelect, onClose }) => {
  if (!open) return null;
  return (
    <>
      <div
        style={{ position: 'fixed', inset: 0, zIndex: 9998 }}
        onClick={onClose}
        onContextMenu={(e) => {
          e.preventDefault();
          onClose();
        }}
      />
      <ul
        role="menu"
        style={{
          position: 'fixed',
          left: x,
          top: y,
          zIndex: 9999,
          margin: 0,
          padding: `${spacing.sm}px 0`,
          listStyle: 'none',
          minWidth: 180,
          background: colors.surface,
          border: `1px solid ${colors.border}`,
          borderRadius: spacing.radiusMd,
          boxShadow: '0 8px 24px rgba(0,0,0,0.12)',
          fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif',
        }}
      >
        {items.map((item) =>
          item.separator ? (
            <li
              key={item.id}
              style={{ height: 1, background: colors.border, margin: `${spacing.sm}px 0` }}
            />
          ) : (
            <li key={item.id}>
              <button
                type="button"
                role="menuitem"
                disabled={item.disabled}
                onClick={() => {
                  if (!item.disabled) {
                    onSelect(item.id);
                    onClose();
                  }
                }}
                style={{
                  width: '100%',
                  textAlign: 'left',
                  border: 'none',
                  background: 'transparent',
                  padding: `${spacing.sm}px ${spacing.lg}px`,
                  fontSize: typography.body.fontSize,
                  color: item.danger ? colors.red : colors.foreground,
                  cursor: item.disabled ? 'not-allowed' : 'pointer',
                  opacity: item.disabled ? 0.5 : 1,
                }}
                onMouseEnter={(e) => {
                  if (!item.disabled) e.currentTarget.style.background = colors.gray100;
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                }}
              >
                {item.label}
              </button>
            </li>
          )
        )}
      </ul>
    </>
  );
};

export interface WindowControlsProps {
  onMinimize?: () => void;
  onMaximize?: () => void;
  onClose?: () => void;
}

export const WindowControls: React.FC<WindowControlsProps> = ({ onMinimize, onMaximize, onClose }) => (
  <div style={{ display: 'flex' }}>
    <WinBtn label="-" onClick={onMinimize} />
    <WinBtn label="[]" onClick={onMaximize} />
    <WinBtn label="x" onClick={onClose} danger />
  </div>
);