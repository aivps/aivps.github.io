/** ChargingStation - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'stationNumber': { type: String, value: '' },
    'stationType': { type: String, value: '' },
    'power': { type: String, value: '' },
    'status': { type: String, value: '' },
    'vehiclePlate': { type: String, value: '' },
    'batteryLevel': { type: String, value: '' },
    'totalFee': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});