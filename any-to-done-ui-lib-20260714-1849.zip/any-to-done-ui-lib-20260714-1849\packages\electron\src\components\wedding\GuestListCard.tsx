import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface GuestListCardProps {
  name?: string | number;
  tableNumber?: string | number;
  status?: string;
  phone?: string | number;
  relationship?: string | number;
  /** @deprecated use tableNumber */
  tableNo?: string | number;
  /** @deprecated use status */
  rsvp?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 宾客 - field-deep aligned shell (single-row) */
export const GuestListCard: React.FC<GuestListCardProps> = ({
  name,
  tableNumber,
  status,
  phone,
  relationship,
  tableNo,
  rsvp,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="宾客"
    status={status ?? (rsvp != null ? String(rsvp) : undefined)}
    fields={[
      { label: '名称', value: name },
      { label: '关系', value: relationship },
      { label: '桌号', value: tableNumber ?? tableNo },
      { label: '电话', value: phone },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default GuestListCard;
