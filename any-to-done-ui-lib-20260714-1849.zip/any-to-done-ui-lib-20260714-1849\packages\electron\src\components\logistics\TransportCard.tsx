import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface TransportCardProps {
  routeName?: string | number;
  carrier?: string | number;
  status?: string;
  vehicleNo?: string | number;
  origin?: string | number;
  destination?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 运输 - field-deep aligned shell */
export const TransportCard: React.FC<TransportCardProps> = ({
  routeName,
  carrier,
  status,
  vehicleNo,
  origin,
  destination,
  style,
  onContextMenu
}) => (
  <IndustryCardShell
    title="运输"
    status={status}
    fields={[
    { label: '线路', value: routeName },
    { label: '承运商', value: carrier },
    { label: '车号', value: vehicleNo },
    { label: '起点', value: origin },
    { label: '终点', value: destination },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default TransportCard;