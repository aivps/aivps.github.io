/** ChildPatientCard - WeChat Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'age': { type: String, value: '' },
    'gender': { type: String, value: '' },
    'department': { type: String, value: '' },
    'guardian': { type: String, value: '' },
    'status': { type: String, value: '' },
    'chiefComplaint': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});