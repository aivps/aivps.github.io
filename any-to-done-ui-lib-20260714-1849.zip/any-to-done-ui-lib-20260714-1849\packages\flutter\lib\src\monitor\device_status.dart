import 'package:flutter/material.dart';

/// DeviceStatus - field-deep aligned to React src/monitor
class DeviceStatus extends StatelessWidget {
  final String? deviceId;
  final String? name;
  final String? location;
  final String? status;
  final String? online;
  final VoidCallback? onTap;
  final bool disabled;

  const DeviceStatus({
    super.key,
    this.deviceId,
    this.name,
    this.location,
    this.status,
    this.online,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF1F1F1F) : Colors.white;
    final border = isDark ? const Color(0xFF303030) : const Color(0xFFE8E8E8);
    final muted = const Color(0xFF8C8C8C);
    final fg = isDark ? const Color(0xFFE8E8E8) : const Color(0xFF262626);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Material(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('DeviceStatus', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: fg)),
                const SizedBox(height: 12),
                if (deviceId != null && deviceId!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('deviceId', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(deviceId!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (name != null && name!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('name', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(name!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (location != null && location!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('location', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(location!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (status != null && status!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('status', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(status!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (online != null && online!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('online', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(online!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}