/** StudentCard - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'name': { type: String, value: '' },
    'age': { type: String, value: '' },
    'className': { type: String, value: '' },
    'guardian': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});