package com.uilib.components.education

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 课表 - education industry (Compose) */
@Composable
fun ClassSchedule(
    className: String = "",
    weekday: String = "",
    period: String = "",
    room: String = "",
    subject: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "课表",
        status = null,
        fields = listOf(
            "班级" to className,
            "星期" to weekday,
            "节次" to period,
            "教室" to room,
            "科目" to subject,
        ),
        modifier = modifier,
    )
}