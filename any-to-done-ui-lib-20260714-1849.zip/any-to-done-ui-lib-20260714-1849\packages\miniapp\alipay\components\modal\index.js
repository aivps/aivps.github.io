/**
 * 弹窗组件
 */
Component({
  options: {
    addGlobalClass: true,
  },

  properties: {
    // 是否显示
    visible: {
      type: Boolean,
      value: false,
    },
    // 标题
    title: {
      type: String,
      value: '',
    },
    // 是否显示关闭按钮
    closable: {
      type: Boolean,
      value: true,
    },
    // 点击蒙层是否关闭
    maskClosable: {
      type: Boolean,
      value: true,
    },
    // 弹窗宽度
    width: {
      type: String,
      value: '80%',
    },
    // 是否显示底部
    footer: {
      type: Boolean,
      value: true,
    },
    // 确定按钮文字
    okText: {
      type: String,
      value: '确定',
    },
    // 取消按钮文字
    cancelText: {
      type: String,
      value: '取消',
    },
  },

  methods: {
    onMaskTap() {
      if (this.properties.maskClosable) {
        this.onClose();
      }
    },

    onClose() {
      this.triggerEvent('close');
    },

    onCancel() {
      this.triggerEvent('cancel');
      this.onClose();
    },

    onOk() {
      this.triggerEvent('ok');
      this.onClose();
    },

    stopPropagation() {
      // 阻止冒泡
    },
  },
});
