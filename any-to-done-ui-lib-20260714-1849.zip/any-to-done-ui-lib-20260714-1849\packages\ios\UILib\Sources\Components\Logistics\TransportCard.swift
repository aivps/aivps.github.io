import SwiftUI

/// 运输 - field-deep aligned shell (SwiftUI)
public struct TransportCard: View {
    public var routeName: String = ""
    public var carrier: String = ""
    public var status: String = ""
    public var vehicleNo: String = ""
    public var origin: String = ""
    public var destination: String = ""

    public init(routeName: String = "", carrier: String = "", status: String = "", vehicleNo: String = "", origin: String = "", destination: String = "") {
        self.routeName = routeName
        self.carrier = carrier
        self.status = status
        self.vehicleNo = vehicleNo
        self.origin = origin
        self.destination = destination
    }

    public var body: some View {
        IndustryCardShell(
            title: "运输",
            status: status.isEmpty ? nil : status,
            fields: [
            ("线路", routeName),
            ("承运商", carrier),
            ("车号", vehicleNo),
            ("起点", origin),
            ("终点", destination),
            ]
        )
    }
}