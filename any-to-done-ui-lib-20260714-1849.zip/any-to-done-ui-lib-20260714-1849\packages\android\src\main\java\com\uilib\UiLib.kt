package com.uilib

/**
 * Enterprise UI Components for Android (Jetpack Compose).
 * Phase 6: tokens, atoms, and 26 industry groups x 2 components.
 */
object UiLib {
    const val VERSION = "1.0.0"
}