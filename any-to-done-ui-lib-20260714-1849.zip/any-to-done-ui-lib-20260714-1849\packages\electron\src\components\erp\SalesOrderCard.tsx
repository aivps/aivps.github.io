import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface SalesOrderCardProps {
  orderNumber?: string | number;
  customer?: string | number;
  totalAmount?: string | number;
  status?: string;
  orderDate?: string | number;
  deliveryDate?: string | number;
  salesPerson?: string | number;
  /** @deprecated */
  orderNo?: string | number;
  amount?: string | number;
  date?: string | number;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
}

/** 销售单 - field-deep aligned shell */
export const SalesOrderCard: React.FC<SalesOrderCardProps> = ({
  orderNumber,
  customer,
  totalAmount,
  status,
  orderDate,
  deliveryDate,
  salesPerson,
  orderNo,
  amount,
  date,
  style,
  onContextMenu,
}) => (
  <IndustryCardShell
    title="销售单"
    status={status}
    fields={[
      { label: '订单号', value: orderNumber ?? orderNo },
      { label: '客户', value: customer },
      { label: '金额', value: totalAmount ?? amount },
      { label: '下单日期', value: orderDate ?? date },
      { label: '交货日期', value: deliveryDate },
      { label: '销售', value: salesPerson },
    ]}
    style={style}
    onContextMenu={onContextMenu}
  />
);

export default SalesOrderCard;
