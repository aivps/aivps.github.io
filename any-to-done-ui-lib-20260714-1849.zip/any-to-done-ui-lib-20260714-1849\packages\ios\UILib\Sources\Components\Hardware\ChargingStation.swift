import SwiftUI

/// 充电桩 - hardware industry (SwiftUI)
public struct ChargingStation: View {
    public var stationId: String = ""
    public var location: String = ""
    public var powerKw: String = ""
    public var ports: String = ""
    public var status: String = ""

    public init(stationId: String = "", location: String = "", powerKw: String = "", ports: String = "", status: String = "") {
        self.stationId = stationId
        self.location = location
        self.powerKw = powerKw
        self.ports = ports
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "充电桩",
            status: status.isEmpty ? nil : status,
            fields: [
            ("站点 ID", stationId),
            ("位置", location),
            ("功率(kW)", powerKw),
            ("端口", ports),
            ]
        )
    }
}