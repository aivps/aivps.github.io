package com.uilib.components.legal

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 证据 - field-deep aligned shell (Compose) */
@Composable
fun EvidenceCard(
    caseId: String = "",
    name: String = "",
    type: String = "",
    uploadDate: String = "",
    size: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "证据",
        status = status.ifBlank { null },
        fields = listOf(
            "案件" to caseId,
            "名称" to name,
            "类型" to type,
            "上传日期" to uploadDate,
            "大小" to size,
        ),
        modifier = modifier,
    )
}