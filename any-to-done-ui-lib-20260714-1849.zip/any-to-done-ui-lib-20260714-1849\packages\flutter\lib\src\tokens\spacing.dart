import 'package:flutter/material.dart';

/// Design Tokens - Spacing
/// 4px base scale + EdgeInsets / BorderRadius aliases used by industry cards
class AppSpacing {
  AppSpacing._();

  // Numeric scale
  static const double xxs = 2;
  static const double xs = 4;
  static const double sm = 8;
  static const double mdValue = 12;
  static const double base = 16;
  static const double lgValue = 24;
  static const double xlValue = 32;
  static const double xxl = 48;
  static const double xxxl = 64;

  // EdgeInsets aliases (industry cards use padding: AppSpacing.lg etc.)
  static const EdgeInsets xsInsets = EdgeInsets.all(xs);
  static const EdgeInsets smInsets = EdgeInsets.all(sm);
  static const EdgeInsets md = EdgeInsets.all(mdValue);
  static const EdgeInsets lg = EdgeInsets.all(base);
  static const EdgeInsets xl = EdgeInsets.all(lgValue);

  // BorderRadius aliases
  static final BorderRadius borderRadiusSm = BorderRadius.circular(AppRadius.sm);
  static final BorderRadius borderRadiusMd = BorderRadius.circular(AppRadius.base);
  static final BorderRadius borderRadiusLg = BorderRadius.circular(AppRadius.md);
  static final BorderRadius borderRadiusXl = BorderRadius.circular(AppRadius.lg);
}

/// 圆角
class AppRadius {
  AppRadius._();

  static const double none = 0;
  static const double sm = 4;
  static const double base = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double full = 999;
}

/// 阴影
class AppShadow {
  AppShadow._();

  static List<BoxShadow> get sm => [
        BoxShadow(
          color: const Color(0x0D000000),
          blurRadius: 2,
          offset: const Offset(0, 1),
        ),
      ];

  static List<BoxShadow> get base => [
        BoxShadow(
          color: const Color(0x1A000000),
          blurRadius: 4,
          offset: const Offset(0, 2),
        ),
      ];

  static List<BoxShadow> get md => [
        BoxShadow(
          color: const Color(0x1F000000),
          blurRadius: 8,
          offset: const Offset(0, 4),
        ),
      ];

  static List<BoxShadow> get lg => [
        BoxShadow(
          color: const Color(0x26000000),
          blurRadius: 16,
          offset: const Offset(0, 8),
        ),
      ];

  static List<BoxShadow> get xl => [
        BoxShadow(
          color: const Color(0x33000000),
          blurRadius: 32,
          offset: const Offset(0, 16),
        ),
      ];
}

/// Alias used by industry components (`AppShadows.sm`)
class AppShadows {
  AppShadows._();

  static List<BoxShadow> get sm => AppShadow.sm;
  static List<BoxShadow> get base => AppShadow.base;
  static List<BoxShadow> get md => AppShadow.md;
  static List<BoxShadow> get lg => AppShadow.lg;
  static List<BoxShadow> get xl => AppShadow.xl;
}
