import 'package:flutter/material.dart';
import '../tokens/colors.dart';

class AppTabs extends StatelessWidget {
  final List<TabItem> tabs;
  final int currentIndex;
  final ValueChanged<int> onChanged;
  final TabType type;

  const AppTabs({
    super.key,
    required this.tabs,
    required this.currentIndex,
    required this.onChanged,
    this.type = TabType.line,
  });

  @override
  Widget build(BuildContext context) {
    if (type == TabType.card) {
      return Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: List.generate(tabs.length, (i) {
            final active = i == currentIndex;
            return Expanded(
              child: GestureDetector(
                onTap: () => onChanged(i),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  decoration: BoxDecoration(
                    color: active ? Colors.white : Colors.transparent,
                    borderRadius: BorderRadius.circular(6),
                    boxShadow: active
                        ? [BoxShadow(color: Colors.black.withValues(alpha: 0.08), blurRadius: 4)]
                        : null,
                  ),
                  child: Text(
                    tabs[i].label,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: active ? FontWeight.w500 : FontWeight.normal,
                      color: active ? AppColors.primary : Colors.grey[600],
                    ),
                  ),
                ),
              ),
            );
          }),
        ),
      );
    }

    return DefaultTabController(
      length: tabs.length,
      initialIndex: currentIndex,
      child: Column(
        children: [
          TabBar(
            onTap: onChanged,
            labelColor: AppColors.primary,
            unselectedLabelColor: Colors.grey[500],
            indicatorColor: AppColors.primary,
            tabs: tabs.map((t) => Tab(text: t.label)).toList(),
          ),
        ],
      ),
    );
  }
}

class TabItem {
  final String label;
  final String? key;
  final IconData? icon;
  final int? badge;

  const TabItem({required this.label, this.key, this.icon, this.badge});
}

enum TabType { line, card }
