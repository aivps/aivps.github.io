/** 发票 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'invoiceNumber': { type: String, value: '' },
    'type': { type: String, value: '' },
    'client': { type: String, value: '' },
    'amount': { type: String, value: '' },
    'tax': { type: String, value: '' },
    'total': { type: String, value: '' },
    'status': { type: String, value: '' },
    'issueDate': { type: String, value: '' },
    'dueDate': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});