import SwiftUI

/// KPI - bi industry (SwiftUI)
public struct KPIBoard: View {
    public var name: String = ""
    public var value: String = ""
    public var target: String = ""
    public var unit: String = ""
    public var trend: String = ""

    public init(name: String = "", value: String = "", target: String = "", unit: String = "", trend: String = "") {
        self.name = name
        self.value = value
        self.target = target
        self.unit = unit
        self.trend = trend
    }

    public var body: some View {
        IndustryCardShell(
            title: "KPI",
            status: nil,
            fields: [
            ("名称", name),
            ("数值", value),
            ("目标", target),
            ("单位", unit),
            ("趋势", trend),
            ]
        )
    }
}