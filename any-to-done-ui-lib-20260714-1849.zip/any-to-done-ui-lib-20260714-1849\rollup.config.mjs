import { createRequire } from 'node:module';
import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import typescript from '@rollup/plugin-typescript';
import terser from '@rollup/plugin-terser';
import peerDepsExternal from 'rollup-plugin-peer-deps-external';
import dts from 'rollup-plugin-dts';
import postcss from 'rollup-plugin-postcss';

const require = createRequire(import.meta.url);
const packageJson = require('./package.json');

const plugins = [
  peerDepsExternal(),
  resolve(),
  commonjs(),
  typescript({
    tsconfig: './tsconfig.json',
    declaration: true,
    declarationDir: 'dist/types',
  }),
  postcss({
    extract: 'styles.css',
    minimize: true,
  }),
  terser(),
];

export default [
  {
    input: 'src/index.ts',
    output: [
      {
        file: packageJson.main,
        format: 'cjs',
        sourcemap: true,
      },
      {
        file: packageJson.module,
        format: 'esm',
        sourcemap: true,
      },
    ],
    plugins,
    external: ['react', 'react-dom'],
  },
  {
    input: 'src/tokens/index.ts',
    output: [
      {
        file: 'dist/tokens/index.js',
        format: 'cjs',
        sourcemap: true,
      },
      {
        file: 'dist/tokens/index.mjs',
        format: 'esm',
        sourcemap: true,
      },
    ],
    plugins: [typescript({ tsconfig: './tsconfig.json' }), terser()],
  },
  {
    input: 'src/hooks/index.ts',
    output: [
      {
        file: 'dist/hooks/index.js',
        format: 'cjs',
        sourcemap: true,
      },
      {
        file: 'dist/hooks/index.mjs',
        format: 'esm',
        sourcemap: true,
      },
    ],
    plugins,
    external: ['react', 'react-dom'],
  },
  {
    input: 'src/atoms/index.ts',
    output: [
      {
        file: 'dist/atoms/index.js',
        format: 'cjs',
        sourcemap: true,
      },
      {
        file: 'dist/atoms/index.mjs',
        format: 'esm',
        sourcemap: true,
      },
    ],
    plugins,
    external: ['react', 'react-dom'],
  },
  {
    input: 'src/composite/index.ts',
    output: [
      {
        file: 'dist/composite/index.js',
        format: 'cjs',
        sourcemap: true,
      },
      {
        file: 'dist/composite/index.mjs',
        format: 'esm',
        sourcemap: true,
      },
    ],
    plugins,
    external: ['react', 'react-dom'],
  },
  {
    input: 'src/global/index.ts',
    output: [
      {
        file: 'dist/global/index.js',
        format: 'cjs',
        sourcemap: true,
      },
      {
        file: 'dist/global/index.mjs',
        format: 'esm',
        sourcemap: true,
      },
    ],
    plugins,
    external: ['react', 'react-dom'],
  },
  {
    input: 'src/index.ts',
    output: {
      file: 'dist/index.d.ts',
      format: 'esm',
    },
    plugins: [dts()],
    external: [/\.css$/],
  },
];
