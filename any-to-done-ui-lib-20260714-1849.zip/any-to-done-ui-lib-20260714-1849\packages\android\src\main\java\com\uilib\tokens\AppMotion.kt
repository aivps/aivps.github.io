package com.uilib.tokens

/**
 * Motion tokens — press scale + duration (aligned with React motion).
 */
object AppMotion {
    const val durationFastMs = 120
    const val durationNormalMs = 200
    const val pressScale = 0.98f
}
