import 'package:flutter/material.dart';
import '../tokens/breakpoints.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// React-aligned visual variants
enum InputVariant {
  outlined,
  filled,
  borderless,
}

/// 输入框尺寸
enum InputSize {
  sm,
  md,
  lg,
}

/// 输入框状态
enum InputStatus {
  defaultStatus,
  error,
  success,
  warning,
}

/// AppInput — shallow API aligned to React Input
class AppInput extends StatefulWidget {
  final InputVariant variant;
  final InputSize size;
  final InputStatus status;
  final String? label;
  final String? placeholder;
  final String? helperText;
  final String? errorMessage;
  final String? successMessage;
  final String? warningMessage;
  final Widget? prefix;
  final Widget? suffix;
  final bool clearable;
  final bool disabled;
  final bool readOnly;
  final bool loading;
  final bool obscureText;
  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onClear;
  final TextInputType? keyboardType;
  final int maxLines;
  final String? initialValue;

  const AppInput({
    super.key,
    this.variant = InputVariant.outlined,
    this.size = InputSize.md,
    this.status = InputStatus.defaultStatus,
    this.label,
    this.placeholder,
    this.helperText,
    this.errorMessage,
    this.successMessage,
    this.warningMessage,
    this.prefix,
    this.suffix,
    this.clearable = false,
    this.disabled = false,
    this.readOnly = false,
    this.loading = false,
    this.obscureText = false,
    this.controller,
    this.onChanged,
    this.onClear,
    this.keyboardType,
    this.maxLines = 1,
    this.initialValue,
  });

  @override
  State<AppInput> createState() => _AppInputState();
}

class _AppInputState extends State<AppInput> {
  late TextEditingController _controller;
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _controller = widget.controller ?? TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    if (widget.controller == null) {
      _controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.label != null) ...[
          Text(
            widget.label!,
            style: AppTypography.bodySmall.copyWith(
              color: AppColors.gray700,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: AppSpacing.xs),
        ],
        GestureDetector(
          onTap: () {
            if (!widget.disabled && !widget.readOnly && !widget.loading) {
              FocusScope.of(context).requestFocus(FocusNode());
              setState(() => _isFocused = true);
            }
          },
          child: Container(
            height: _getHeight(),
            decoration: _getDecoration(),
            child: Row(
              children: [
                if (widget.prefix != null) ...[
                  Padding(
                    padding: const EdgeInsets.only(left: AppSpacing.mdValue),
                    child: widget.prefix,
                  ),
                ],
                Expanded(
                  child: TextField(
                    controller: _controller,
                    enabled: !widget.disabled && !widget.readOnly && !widget.loading,
                    readOnly: widget.readOnly,
                    obscureText: widget.obscureText,
                    onChanged: widget.onChanged,
                    keyboardType: widget.keyboardType,
                    maxLines: widget.maxLines,
                    style: _getTextStyle(),
                    decoration: InputDecoration(
                      hintText: widget.placeholder,
                      hintStyle: TextStyle(color: AppColors.gray400),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: AppSpacing.mdValue,
                        vertical: AppSpacing.sm,
                      ),
                    ),
                  ),
                ),
                if (widget.loading)
                  const Padding(
                    padding: EdgeInsets.only(right: AppSpacing.mdValue),
                    child: SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    ),
                  ),
                if (widget.suffix != null) ...[
                  Padding(
                    padding: const EdgeInsets.only(right: AppSpacing.mdValue),
                    child: widget.suffix,
                  ),
                ],
                if (widget.clearable &&
                    _controller.text.isNotEmpty &&
                    !widget.loading)
                  GestureDetector(
                    onTap: () {
                      _controller.clear();
                      widget.onClear?.call();
                      widget.onChanged?.call('');
                    },
                    child: const Padding(
                      padding: EdgeInsets.only(right: AppSpacing.mdValue),
                      child: Icon(Icons.close, size: 16, color: AppColors.gray400),
                    ),
                  ),
              ],
            ),
          ),
        ),
        if (_messageText != null) ...[
          const SizedBox(height: AppSpacing.xs),
          Text(
            _messageText!,
            style: AppTypography.caption.copyWith(
              color: _getHelperTextColor(),
            ),
          ),
        ],
      ],
    );
  }

  String? get _messageText =>
      widget.errorMessage ??
      widget.successMessage ??
      widget.warningMessage ??
      widget.helperText;

  BoxDecoration _getDecoration() {
    final borderColor = _getBorderColor();
    switch (widget.variant) {
      case InputVariant.filled:
        return BoxDecoration(
          color: _getBackgroundColor() == AppColors.gray0
              ? AppColors.gray100
              : _getBackgroundColor(),
          border: Border(
            bottom: BorderSide(color: borderColor, width: _isFocused ? 2 : 1),
          ),
          borderRadius: BorderRadius.circular(AppRadius.base),
        );
      case InputVariant.borderless:
        return BoxDecoration(
          color: Colors.transparent,
          border: Border.all(color: Colors.transparent),
        );
      case InputVariant.outlined:
        return BoxDecoration(
          color: _getBackgroundColor(),
          border: Border.all(
            color: borderColor,
            width: _isFocused ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(AppRadius.base),
        );
    }
  }

  double _getHeight() {
    switch (widget.size) {
      case InputSize.sm:
        return 32;
      case InputSize.md:
        return 40;
      case InputSize.lg:
        return TouchTargets.comfortable;
    }
  }

  TextStyle _getTextStyle() {
    switch (widget.size) {
      case InputSize.sm:
        return AppTypography.caption;
      case InputSize.md:
        return AppTypography.bodySmall;
      case InputSize.lg:
        return AppTypography.bodyMedium;
    }
  }

  Color _getBorderColor() {
    if (_isFocused) return AppColors.primary;
    switch (widget.status) {
      case InputStatus.error:
        return AppColors.danger;
      case InputStatus.success:
        return AppColors.success;
      case InputStatus.warning:
        return AppColors.orange;
      default:
        return AppColors.gray300;
    }
  }

  Color _getBackgroundColor() {
    if (widget.disabled) return AppColors.gray100;
    if (widget.readOnly) return AppColors.gray50;
    return AppColors.gray0;
  }

  Color _getHelperTextColor() {
    if (widget.errorMessage != null) return AppColors.danger;
    if (widget.successMessage != null) return AppColors.success;
    if (widget.warningMessage != null) return AppColors.orange;
    switch (widget.status) {
      case InputStatus.error:
        return AppColors.danger;
      case InputStatus.success:
        return AppColors.success;
      case InputStatus.warning:
        return AppColors.orange;
      default:
        return AppColors.gray500;
    }
  }
}
