/** 合同 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'contractNumber': { type: String, value: '' },
    'title': { type: String, value: '' },
    'parties': { type: String, value: '' },
    'amount': { type: String, value: '' },
    'status': { type: String, value: '' },
    'createdAt': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
