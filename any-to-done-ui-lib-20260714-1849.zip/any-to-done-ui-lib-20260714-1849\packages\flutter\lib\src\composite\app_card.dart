import 'package:flutter/material.dart';
/// Card component with header, body, footer
class AppCard extends StatelessWidget {
  final String? title;
  final String? subtitle;
  final Widget? child;
  final Widget? header;
  final Widget? footer;
  final Widget? extra;
  final bool hoverable;
  final EdgeInsetsGeometry? padding;

  const AppCard({
    super.key,
    this.title,
    this.subtitle,
    this.child,
    this.header,
    this.footer,
    this.extra,
    this.hoverable = false,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: hoverable ? 2 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          if (title != null || header != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              child: Row(
                children: [
                  Expanded(
                    child: header ??
                        Row(
                          children: [
                            Text(
                              title ?? '',
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            if (subtitle != null) ...[
                              const SizedBox(width: 8),
                              Text(
                                subtitle!,
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Colors.grey[500],
                                ),
                              ),
                            ],
                          ],
                        ),
                  ),
                  if (extra != null) extra!,
                ],
              ),
            ),
          if (title != null || header != null)
            const Divider(height: 1),
          Padding(
            padding: padding ?? const EdgeInsets.all(20),
            child: child,
          ),
          if (footer != null) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              child: footer!,
            ),
          ],
        ],
      ),
    );
  }
}
