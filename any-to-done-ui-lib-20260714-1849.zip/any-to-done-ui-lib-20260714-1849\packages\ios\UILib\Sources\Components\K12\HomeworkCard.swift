import SwiftUI

/// 作业 - k12 industry (SwiftUI)
public struct HomeworkCard: View {
    public var title: String = ""
    public var subject: String = ""
    public var dueDate: String = ""
    public var className: String = ""
    public var status: String = ""

    public init(title: String = "", subject: String = "", dueDate: String = "", className: String = "", status: String = "") {
        self.title = title
        self.subject = subject
        self.dueDate = dueDate
        self.className = className
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "作业",
            status: status.isEmpty ? nil : status,
            fields: [
            ("标题", title),
            ("科目", subject),
            ("截止日期", dueDate),
            ("班级", className),
            ]
        )
    }
}