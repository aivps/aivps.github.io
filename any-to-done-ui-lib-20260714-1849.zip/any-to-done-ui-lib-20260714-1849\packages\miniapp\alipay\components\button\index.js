/**
 * Button — shallow API aligned to React atoms.
 * Canonical: variant primary|secondary|text|danger|ghost; size xs|sm|md|lg; circle; error.
 * Legacy: type (alias of variant), outline→secondary, link→text, shape.circle→circle.
 */
Component({
  options: {
    multipleSlots: true,
    addGlobalClass: true,
  },

  properties: {
    /** React-aligned variant (preferred) */
    variant: {
      type: String,
      value: '',
    },
    /** @deprecated use variant */
    type: {
      type: String,
      value: 'primary',
    },
    size: {
      type: String,
      value: 'md', // xs, sm, md, lg
    },
    /** Circular button (React-aligned) */
    circle: {
      type: Boolean,
      value: false,
    },
    /** @deprecated use circle; round remains platform extension */
    shape: {
      type: String,
      value: 'default', // default, round, circle
    },
    disabled: {
      type: Boolean,
      value: false,
    },
    loading: {
      type: Boolean,
      value: false,
    },
    error: {
      type: Boolean,
      value: false,
    },
    block: {
      type: Boolean,
      value: false,
    },
    formType: {
      type: String,
      value: '',
    },
    openType: {
      type: String,
      value: '',
    },
  },

  data: {
    resolvedVariant: 'primary',
    isCircle: false,
    isRound: false,
    isOutlineLegacy: false,
  },

  observers: {
    'variant, type, circle, shape': function (variant, type, circle, shape) {
      const raw = variant || type || 'primary';
      let resolved = raw;
      let isOutlineLegacy = false;
      if (raw === 'outline') {
        resolved = 'secondary';
        isOutlineLegacy = true;
      } else if (raw === 'link') {
        resolved = 'text';
      }
      this.setData({
        resolvedVariant: resolved,
        isCircle: circle || shape === 'circle',
        isRound: shape === 'round' && !(circle || shape === 'circle'),
        isOutlineLegacy,
      });
    },
  },

  lifetimes: {
    attached() {
      const { variant, type, circle, shape } = this.properties;
      const raw = variant || type || 'primary';
      let resolved = raw;
      let isOutlineLegacy = false;
      if (raw === 'outline') {
        resolved = 'secondary';
        isOutlineLegacy = true;
      } else if (raw === 'link') {
        resolved = 'text';
      }
      this.setData({
        resolvedVariant: resolved,
        isCircle: circle || shape === 'circle',
        isRound: shape === 'round' && !(circle || shape === 'circle'),
        isOutlineLegacy,
      });
    },
  },

  methods: {
    onTap(e) {
      const { disabled, loading } = this.properties;
      if (disabled || loading) return;
      this.triggerEvent('tap', e.detail);
    },
  },
});
