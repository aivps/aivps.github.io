﻿import SwiftUI

/// 故障 - field-deep aligned shell (SwiftUI)
public struct IncidentCard: View {
    public var incidentId: String = ""
    public var title: String = ""
    public var level: String = ""
    public var status: String = ""
    public var assignee: String = ""
    public var createdAt: String = ""

    public init(incidentId: String = "", title: String = "", level: String = "", status: String = "", assignee: String = "", createdAt: String = "") {
        self.incidentId = incidentId
        self.title = title
        self.level = level
        self.status = status
        self.assignee = assignee
        self.createdAt = createdAt
    }

    public var body: some View {
        IndustryCardShell(
            title: "故障",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", incidentId),
            ("标题", title),
            ("等级", level),
            ("处理人", assignee),
            ("开始时间", createdAt),
            ]
        )
    }
}
