/** 运输 - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'routeName': { type: String, value: '' },
    'carrier': { type: String, value: '' },
    'status': { type: String, value: '' },
    'vehicleNo': { type: String, value: '' },
    'origin': { type: String, value: '' },
    'destination': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});