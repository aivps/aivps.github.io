package com.uilib.components.medical

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 患者 - industry (Compose, field-deep aligned) */
@Composable
fun PatientCard(
    id: String = "",
    name: String = "",
    gender: String = "",
    age: String = "",
    phone: String = "",
    department: String = "",
    visitType: String = "",
    status: String = "",
    queueNumber: String = "",
    visitTime: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "患者",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "姓名" to name,
            "性别" to gender,
            "年龄" to age,
            "电话" to phone,
            "科室" to department,
            "挂号类型" to visitType,
            "排队号" to queueNumber,
            "就诊时间" to visitTime,
        ),
        modifier = modifier,
    )
}
