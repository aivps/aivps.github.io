import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// PatientCard — field-deep aligned to React PatientCard.
/// Canonical: flat props + English enums. Legacy Chinese status/gender accepted.
class PatientCard extends StatelessWidget {
  final String id;
  final String name;
  final int age;
  final String gender; // male | female | 男 | 女
  final String? phone;
  final String department;
  final String visitType; // normal | emergency | followup
  final String status; // waiting | consulting | ...
  final int? queueNumber;
  final int? waitingCount;
  final List<String>? allergies;
  final String? visitTime;
  /// Platform extension
  final String? doctor;
  /// @deprecated use visitTime
  final String? visitDate;
  final VoidCallback? onTap;
  final ValueChanged<String>? onCall;
  final ValueChanged<String>? onComplete;
  final ValueChanged<String>? onView;
  final bool disabled;

  const PatientCard({
    super.key,
    this.id = '',
    required this.name,
    required this.age,
    required this.gender,
    this.phone,
    required this.department,
    this.visitType = 'normal',
    required this.status,
    this.queueNumber,
    this.waitingCount,
    this.allergies,
    this.visitTime,
    this.doctor,
    this.visitDate,
    this.onTap,
    this.onCall,
    this.onComplete,
    this.onView,
    this.disabled = false,
  });

  static const _statusLabels = {
    'waiting': '候诊中',
    'consulting': '就诊中',
    'examining': '检查中',
    'prescribed': '已开药',
    'completed': '已完成',
    '待诊': '候诊中',
    '候诊中': '候诊中',
    '就诊中': '就诊中',
    '检查中': '检查中',
    '已开药': '已开药',
    '已完成': '已完成',
    '已取消': '已取消',
  };

  static const _genderLabels = {
    'male': '男',
    'female': '女',
    '男': '男',
    '女': '女',
  };

  static const _visitTypeLabels = {
    'normal': '普通',
    'emergency': '急诊',
    'followup': '复诊',
  };

  String get _statusLabel => _statusLabels[status] ?? status;
  String get _genderLabel => _genderLabels[gender] ?? gender;
  String get _visitTypeLabel => _visitTypeLabels[visitType] ?? visitType;
  String? get _visitDisplay => visitTime ?? visitDate;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'waiting':
      case '待诊':
      case '候诊中':
        return colors.warning;
      case 'consulting':
      case 'examining':
      case '就诊中':
      case '检查中':
        return colors.primary;
      case 'prescribed':
      case 'completed':
      case '已开药':
      case '已完成':
        return colors.success;
      case '已取消':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final statusColor = _statusColor(colors);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onView?.call(id);
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Flexible(
                    child: Row(
                      children: [
                        Flexible(
                          child: Text(
                            name,
                            style: AppTypography.h3
                                .copyWith(color: colors.textPrimary),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '$_genderLabel · ${age}岁',
                          style: AppTypography.body
                              .copyWith(color: colors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style:
                          AppTypography.caption.copyWith(color: statusColor),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _buildInfoRow(colors, '科室', department),
              _buildInfoRow(colors, '挂号类型', _visitTypeLabel),
              if (doctor != null && doctor!.isNotEmpty)
                _buildInfoRow(colors, '医生', doctor!),
              if (phone != null && phone!.isNotEmpty)
                _buildInfoRow(colors, '电话', phone!),
              if (_visitDisplay != null && _visitDisplay!.isNotEmpty)
                _buildInfoRow(colors, '就诊时间', _visitDisplay!),
              if (queueNumber != null)
                _buildInfoRow(colors, '排队号', '$queueNumber'),
              if (onCall != null || onComplete != null) ...[
                const SizedBox(height: 8),
                Row(
                  children: [
                    if (onCall != null)
                      TextButton(
                        onPressed: disabled ? null : () => onCall!(id),
                        child: const Text('叫号'),
                      ),
                    if (onComplete != null)
                      TextButton(
                        onPressed: disabled ? null : () => onComplete!(id),
                        child: const Text('完成'),
                      ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(AppThemeColors colors, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Text(label,
              style: AppTypography.caption.copyWith(color: colors.muted)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style:
                  AppTypography.body.copyWith(color: colors.textPrimary),
            ),
          ),
        ],
      ),
    );
  }
}
