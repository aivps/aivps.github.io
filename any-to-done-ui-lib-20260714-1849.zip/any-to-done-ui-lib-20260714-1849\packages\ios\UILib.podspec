Pod::Spec.new do |s|
  s.name             = 'UILib'
  s.version          = '1.0.0'
  s.summary          = 'Enterprise cross-platform UI components for iOS'
  s.description      = <<-DESC
    Enterprise cross-platform UI components for iOS,
    supporting iPhone and iPad with SwiftUI.
  DESC
  s.homepage         = 'https://github.com/your-org/ui-lib'
  s.license          = { :type => 'MIT', :file => 'LICENSE' }
  s.author           = { 'Your Name' => 'your@email.com' }
  s.source           = { :git => 'https://github.com/your-org/ui-lib.git', :tag => s.version.to_s }

  s.ios.deployment_target = '14.0'
  s.swift_versions = ['5.0']

  s.source_files = 'UILib/Sources/**/*.swift'
  s.resources = ['UILib/Resources/**/*.xcassets']

  s.frameworks = 'SwiftUI', 'UIKit'
end
