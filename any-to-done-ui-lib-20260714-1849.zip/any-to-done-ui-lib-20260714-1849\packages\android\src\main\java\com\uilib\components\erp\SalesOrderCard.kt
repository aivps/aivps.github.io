﻿package com.uilib.components.erp

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 销售单 - field-deep aligned shell (Compose) */
@Composable
fun SalesOrderCard(
    orderNumber: String = "",
    customer: String = "",
    totalAmount: String = "",
    status: String = "",
    orderDate: String = "",
    deliveryDate: String = "",
    salesPerson: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "销售单",
        status = status.ifBlank { null },
        fields = listOf(
            "订单号" to orderNumber,
            "客户" to customer,
            "金额" to totalAmount,
            "下单日期" to orderDate,
            "交货日期" to deliveryDate,
            "销售" to salesPerson,
        ),
        modifier = modifier,
    )
}
