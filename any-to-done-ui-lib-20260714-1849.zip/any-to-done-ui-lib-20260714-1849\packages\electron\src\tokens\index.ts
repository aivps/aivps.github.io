/**
 * Electron design tokens — aligned with React lightTheme / darkTheme.
 * Industry cards read semantic colors via ThemeProvider or getThemeColors().
 */

export type ThemeMode = 'light' | 'dark';

export const palettes = {
  blue: {
    primary: '#1677FF',
    light: '#4096FF',
    dark: '#0958D9',
    bg: '#E6F4FF',
    border: '#91CAFF',
  },
  red: {
    primary: '#F53F3F',
    light: '#FF7D00',
    dark: '#CB2B3E',
    bg: '#FFECE8',
    border: '#FFA39E',
  },
  green: {
    primary: '#00B42A',
    light: '#52C41A',
    dark: '#389E0D',
    bg: '#E8FBE8',
    border: '#95DE64',
  },
  purple: {
    primary: '#722ED1',
    light: '#9254DE',
    dark: '#531DAB',
    bg: '#F3E8FF',
    border: '#B37FEB',
  },
  cyan: {
    primary: '#13C2C2',
    light: '#36CFC9',
    dark: '#08979C',
    bg: '#E6FFFB',
    border: '#87E8DE',
  },
  orange: {
    primary: '#FA8C16',
    light: '#FFA940',
    dark: '#D46B08',
    bg: '#FFF7E6',
    border: '#FFD591',
  },
} as const;

export type ThemePalette = keyof typeof palettes;

/** Semantic color tokens (React-aligned) */
export interface SemanticColors {
  bg: string;
  bgPage: string;
  bgElevated: string;
  bgMask: string;
  fg: string;
  fgSecondary: string;
  fgTertiary: string;
  fgPlaceholder: string;
  fgInverse: string;
  border: string;
  borderSecondary: string;
  primary: string;
  primaryHover: string;
  primaryActive: string;
  primaryBg: string;
  primaryBorder: string;
  success: string;
  successBg: string;
  warning: string;
  warningBg: string;
  danger: string;
  dangerBg: string;
  info: string;
  infoBg: string;
  textPrimary: string;
  textSecondary: string;
  textTertiary: string;
  textDisabled: string;
  textInverse: string;
  link: string;
  linkHover: string;
  linkActive: string;
  shadowSm: string;
  shadowMd: string;
  shadowLg: string;
  /** Card aliases */
  surface: string;
  background: string;
  foreground: string;
  muted: string;
  /** Brand shortcuts */
  blue: string;
  blueLight: string;
  red: string;
  green: string;
  purple: string;
  cyan: string;
  orange: string;
  gray100: string;
  gray200: string;
  gray700: string;
  gray900: string;
}

export const lightTheme: SemanticColors = {
  bg: '#FFFFFF',
  bgPage: '#F5F7FA',
  bgElevated: '#FFFFFF',
  bgMask: 'rgba(0, 0, 0, 0.45)',
  fg: '#111827',
  fgSecondary: '#4B5563',
  fgTertiary: '#6B7280',
  fgPlaceholder: '#A9AEB8',
  fgInverse: '#FFFFFF',
  border: '#EBEDF0',
  borderSecondary: '#D4D7DE',
  primary: '#1677FF',
  primaryHover: '#4096FF',
  primaryActive: '#0958D9',
  primaryBg: '#E6F4FF',
  primaryBorder: '#91CAFF',
  success: '#00B42A',
  successBg: '#E8FBE8',
  warning: '#FA8C16',
  warningBg: '#FFF7E6',
  danger: '#F53F3F',
  dangerBg: '#FFECE8',
  info: '#1677FF',
  infoBg: '#E6F4FF',
  textPrimary: '#111827',
  textSecondary: '#4B5563',
  textTertiary: '#6B7280',
  textDisabled: '#A9AEB8',
  textInverse: '#FFFFFF',
  link: '#1677FF',
  linkHover: '#4096FF',
  linkActive: '#0958D9',
  shadowSm: '0 1px 2px rgba(0, 0, 0, 0.06)',
  shadowMd: '0 4px 12px rgba(0, 0, 0, 0.08)',
  shadowLg: '0 8px 24px rgba(0, 0, 0, 0.12)',
  surface: '#FFFFFF',
  background: '#F5F7FA',
  foreground: '#111827',
  muted: '#6B7280',
  blue: '#1677FF',
  blueLight: '#E6F4FF',
  red: '#F53F3F',
  green: '#00B42A',
  purple: '#722ED1',
  cyan: '#13C2C2',
  orange: '#FA8C16',
  gray100: '#F3F4F6',
  gray200: '#E5E7EB',
  gray700: '#374151',
  gray900: '#111827',
};

export const darkTheme: SemanticColors = {
  bg: '#141414',
  bgPage: '#0A0A0A',
  bgElevated: '#1F1F1F',
  bgMask: 'rgba(0, 0, 0, 0.65)',
  fg: '#E8E8E8',
  fgSecondary: '#A3A3A3',
  fgTertiary: '#737373',
  fgPlaceholder: '#595959',
  fgInverse: '#141414',
  border: '#303030',
  borderSecondary: '#424242',
  primary: '#1668DC',
  primaryHover: '#3C89E8',
  primaryActive: '#1554AD',
  primaryBg: 'rgba(22, 104, 220, 0.15)',
  primaryBorder: '#1668DC',
  success: '#49AA19',
  successBg: 'rgba(73, 170, 25, 0.15)',
  warning: '#D89614',
  warningBg: 'rgba(216, 150, 20, 0.15)',
  danger: '#DC4444',
  dangerBg: 'rgba(220, 68, 68, 0.15)',
  info: '#1668DC',
  infoBg: 'rgba(22, 104, 220, 0.15)',
  textPrimary: '#E8E8E8',
  textSecondary: '#A3A3A3',
  textTertiary: '#737373',
  textDisabled: '#595959',
  textInverse: '#141414',
  link: '#1668DC',
  linkHover: '#3C89E8',
  linkActive: '#1554AD',
  shadowSm: '0 1px 2px rgba(0, 0, 0, 0.3)',
  shadowMd: '0 4px 12px rgba(0, 0, 0, 0.4)',
  shadowLg: '0 8px 24px rgba(0, 0, 0, 0.5)',
  surface: '#1F1F1F',
  background: '#0A0A0A',
  foreground: '#E8E8E8',
  muted: '#A3A3A3',
  blue: '#1668DC',
  blueLight: 'rgba(22, 104, 220, 0.15)',
  red: '#DC4444',
  green: '#49AA19',
  purple: '#9254DE',
  cyan: '#36CFC9',
  orange: '#D89614',
  gray100: '#1F1F1F',
  gray200: '#303030',
  gray700: '#A3A3A3',
  gray900: '#E8E8E8',
};

/** @deprecated Prefer getThemeColors(mode) or useTheme(). Backward-compatible light defaults. */
export const colors = {
  blue: lightTheme.blue,
  blueLight: lightTheme.blueLight,
  red: lightTheme.red,
  green: lightTheme.green,
  purple: lightTheme.purple,
  cyan: lightTheme.cyan,
  orange: lightTheme.orange,
  surface: lightTheme.surface,
  background: lightTheme.background,
  foreground: lightTheme.foreground,
  muted: lightTheme.muted,
  border: lightTheme.border,
  gray100: lightTheme.gray100,
  gray200: lightTheme.gray200,
  gray700: lightTheme.gray700,
  gray900: lightTheme.gray900,
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  radiusSm: 4,
  radiusMd: 8,
  radiusLg: 12,
  radiusXl: 16,
} as const;

export const typography = {
  h1: { fontSize: 24, fontWeight: 600, lineHeight: 1.33 },
  h2: { fontSize: 20, fontWeight: 600, lineHeight: 1.4 },
  h3: { fontSize: 16, fontWeight: 600, lineHeight: 1.5 },
  body: { fontSize: 14, fontWeight: 400, lineHeight: 1.43 },
  caption: { fontSize: 12, fontWeight: 400, lineHeight: 1.33 },
} as const;

/** Light interaction motion (aligned with React src/tokens/motion) */
export const motion = {
  duration: { fast: 120, normal: 200, slow: 320 },
  easing: { standard: 'cubic-bezier(0.2, 0, 0, 1)' },
  scale: { press: 0.98 },
  transitions: {
    control:
      'background-color 120ms cubic-bezier(0.2, 0, 0, 1), border-color 120ms cubic-bezier(0.2, 0, 0, 1), box-shadow 120ms cubic-bezier(0.2, 0, 0, 1), transform 120ms cubic-bezier(0.2, 0, 0, 1), opacity 120ms cubic-bezier(0.2, 0, 0, 1)',
    card: 'box-shadow 200ms cubic-bezier(0.2, 0, 0, 1), border-color 200ms cubic-bezier(0.2, 0, 0, 1), transform 200ms cubic-bezier(0.2, 0, 0, 1)',
  },
} as const;

export function getThemeColors(mode: ThemeMode = 'light'): SemanticColors {
  return mode === 'dark' ? darkTheme : lightTheme;
}

/** CSS custom properties for host document / webview */
export function generateCSSVariables(mode: ThemeMode = 'light'): Record<string, string> {
  const t = getThemeColors(mode);
  return {
    '--ui-bg': t.bg,
    '--ui-bg-page': t.bgPage,
    '--ui-bg-elevated': t.bgElevated,
    '--ui-surface': t.surface,
    '--ui-background': t.background,
    '--ui-fg': t.fg,
    '--ui-foreground': t.foreground,
    '--ui-muted': t.muted,
    '--ui-border': t.border,
    '--ui-border-secondary': t.borderSecondary,
    '--ui-primary': t.primary,
    '--ui-primary-hover': t.primaryHover,
    '--ui-primary-active': t.primaryActive,
    '--ui-primary-bg': t.primaryBg,
    '--ui-success': t.success,
    '--ui-success-bg': t.successBg,
    '--ui-warning': t.warning,
    '--ui-warning-bg': t.warningBg,
    '--ui-danger': t.danger,
    '--ui-danger-bg': t.dangerBg,
    '--ui-text-primary': t.textPrimary,
    '--ui-text-secondary': t.textSecondary,
    '--ui-text-tertiary': t.textTertiary,
    '--ui-text-disabled': t.textDisabled,
    '--ui-shadow-sm': t.shadowSm,
    '--ui-shadow-md': t.shadowMd,
    '--ui-shadow-lg': t.shadowLg,
    '--ui-gray-100': t.gray100,
    '--ui-gray-200': t.gray200,
    '--ui-gray-700': t.gray700,
    '--ui-gray-900': t.gray900,
  };
}

export function applyThemeToDocument(mode: ThemeMode, root: HTMLElement = document.documentElement) {
  const vars = generateCSSVariables(mode);
  Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v));
  root.setAttribute('data-theme', mode);
}
