package com.uilib.components.children

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 学员 - children industry (Compose) */
@Composable
fun StudentCard(
    name: String = "",
    age: String = "",
    className: String = "",
    guardian: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "学员",
        status = status.ifBlank { null },
        fields = listOf(
            "名称" to name,
            "年龄" to age,
            "班级" to className,
            "监护人" to guardian,
        ),
        modifier = modifier,
    )
}