import 'package:flutter/material.dart';

/// TicketStatus - field-deep aligned to React src/workflow
class TicketStatus extends StatelessWidget {
  final String? ticketNo;
  final String? type;
  final String? assignee;
  final String? updatedAt;
  final String? status;
  final VoidCallback? onTap;
  final bool disabled;

  const TicketStatus({
    super.key,
    this.ticketNo,
    this.type,
    this.assignee,
    this.updatedAt,
    this.status,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF1F1F1F) : Colors.white;
    final border = isDark ? const Color(0xFF303030) : const Color(0xFFE8E8E8);
    final muted = const Color(0xFF8C8C8C);
    final fg = isDark ? const Color(0xFFE8E8E8) : const Color(0xFF262626);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Material(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TicketStatus', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: fg)),
                const SizedBox(height: 12),
                if (ticketNo != null && ticketNo!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('ticketNo', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(ticketNo!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (type != null && type!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('type', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(type!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (assignee != null && assignee!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('assignee', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(assignee!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (updatedAt != null && updatedAt!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('updatedAt', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(updatedAt!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (status != null && status!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('status', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(status!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}