package com.uilib.components.gaming

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 玩家 - field-deep aligned shell (Compose) */
@Composable
fun PlayerListCard(
    nickname: String = "",
    level: String = "",
    coins: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "玩家",
        status = status.ifBlank { null },
        fields = listOf(
            "昵称" to nickname,
            "等级" to level,
            "金币" to coins,
        ),
        modifier = modifier,
    )
}
