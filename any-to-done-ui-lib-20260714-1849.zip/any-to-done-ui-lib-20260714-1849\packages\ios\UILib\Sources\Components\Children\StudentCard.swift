import SwiftUI

/// 学员 - children industry (SwiftUI)
public struct StudentCard: View {
    public var name: String = ""
    public var age: String = ""
    public var className: String = ""
    public var guardian: String = ""
    public var status: String = ""

    public init(name: String = "", age: String = "", className: String = "", guardian: String = "", status: String = "") {
        self.name = name
        self.age = age
        self.className = className
        self.guardian = guardian
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "学员",
            status: status.isEmpty ? nil : status,
            fields: [
            ("名称", name),
            ("年龄", age),
            ("班级", className),
            ("监护人", guardian),
            ]
        )
    }
}