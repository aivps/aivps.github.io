# 行业卡字段级 API 契约（React 为准）

> **用途**：各端行业卡 **字段深对齐** 的单一真相源。  
> **深对齐**：prop / attribute 名、枚举值、核心回调语义与 React 一致；展示文案可中文。  
> **权威实现**：根目录 `src/{industry}/*`  
> **浅对齐**（原子）：见 `docs/api-contract-atoms.md`

---

## 约定

1. **Canonical 优先**：新代码只用 React 契约里的字段名与英文枚举。
2. **Legacy 别名**：旧嵌套对象 / 中文枚举 / 旧回调名可继续传入，组件内 normalize。
3. **展示层中文**：`status` 等枚举在 UI 上映射中文 label；**prop 值保持英文**。
4. **平台扩展**：允许额外字段（如 `doctor`、`idCard`），不反向污染 React。
5. **Shell 卡**（Electron / WC / 小程序 / Android / iOS）：扁平 string 字段即可，字段 **key** 与下表 canonical 对齐。
6. **嵌套 vs 扁平**：以 React 为准——React 用 `product` / `item` 则保留；React 扁平则各端扁平。

---

## 枚举与 label 映射（通用）

| 领域 | Canonical | UI label |
|------|-----------|----------|
| gender | `male` / `female` | 男 / 女 |
| patient status | `waiting` / `consulting` / `examining` / `prescribed` / `completed` | 候诊中 / 就诊中 / 检查中 / 已开药 / 已完成 |
| visitType | `normal` / `emergency` / `followup` | 普通 / 急诊 / 复诊 |
| recordType | `visit` / `admission` / `surgery` / `lab` / `imaging` / `prescription` | 门诊记录 / 住院记录 / 手术记录 / 检验报告 / 影像报告 / 处方 |

**Legacy status（Patient）**

| Legacy | Canonical |
|--------|-----------|
| `待诊` / `候诊中` | `waiting` |
| `就诊中` | `consulting` |
| `检查中` | `examining` |
| `已开药` | `prescribed` |
| `已完成` | `completed` |
| `已取消` | `completed`（展示仍可用 danger，见实现） |
| `男` / `女` | `male` / `female` |

---

## PatientCard（medical）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` | string | 患者 ID |
| `name` | string | — |
| `gender` | `male` \| `female` | — |
| `age` | number | — |
| `phone` | string? | — |
| `department` | string | — |
| `visitType` | `normal` \| `emergency` \| `followup` | — |
| `status` | PatientStatus | 见上表 |
| `queueNumber` | number? | — |
| `waitingCount` | number? | — |
| `allergies` | string[]? | — |
| `visitTime` | string? | 就诊时间 |
| `onCall` / `onComplete` / `onView` | fn? | 移动端可用 `onPress` 作通用点击 |
| `disabled` | boolean? | — |

**扩展（允许）**：`doctor`、`idCard`、`visitDate`（legacy → `visitTime`）。

**Vue**：`packages/vue/src/medical/PatientCard.vue` — 可选嵌套 `patient`；`@call` / `@complete` / `@view`；中文 status/visitType/gender normalize。

**Legacy → Canonical**

| Legacy | Canonical |
|--------|-----------|
| `patient: PatientInfo` | 展开为扁平 props（Vue 亦支持嵌套 `patient`） |
| `onEdit` | 映射 `onView` 或保留为扩展 |
| `onPress` | 平台通用点击（≈ `onView`） |
| `visitDate` | `visitTime` |

---

## MedicalRecordCard（medical）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `recordId` | string | — |
| `patientName` | string | — |
| `patientId` | string | — |
| `recordType` | enum 见上 | — |
| `date` | string | — |
| `department` / `doctor` / `diagnosis` / `notes` | string? | — |
| `attachments` | array? | 移动端可省略 |
| `onDownload` / `onView` | fn? | — |
| `disabled` | boolean? | — |

**Legacy**：`record: MedicalRecordInfo` → 展开扁平。

**Vue**：`packages/vue/src/medical/MedicalRecordCard.vue` — 可选嵌套 `record`；`@download` / `@view`；`recordType` 中文 normalize。

---

## ProductCard（ecommerce）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `product` | `{ id, name, price, originalPrice?, image?, sales?, rating?, tags? }` | 嵌套 |
| `layout` | `horizontal` \| `vertical` | 默认 `vertical` |
| `showSales` / `showRating` | boolean? | — |
| `onAddToCart` | `(id) => void` | — |
| `onClick` | `(id) => void` | RN：`onPress` |

**Legacy**

| Legacy | Canonical |
|--------|-----------|
| `layout: 'grid' \| 'list'` | `vertical` / `horizontal` |
| `onAddCart` | `onAddToCart` |
| `onPress` | `onClick` |
| 扁平 `name`+`price`+`imageUrl`（Flutter） | 合成 `product` 或双轨 |

---

## CartItem（ecommerce）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `item` | `{ id, name, price, quantity, image?, sku?, selected? }` | 嵌套 |
| `onQuantityChange` | `(id, qty) => void` | — |
| `onRemove` | `(id) => void` | — |
| `onSelect` | `(id, selected) => void` | — |

**Legacy**：`skuText` → `sku`；`onToggleSelect` / `onIncrease` / `onDecrease` 仍可用。

---

## InvoiceCard（finance）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` | string | — |
| `invoiceNumber` | string | — |
| `type` | `sales` \| `purchase` \| `expense` | UI：销售/采购/费用发票 |
| `client` | string | — |
| `amount` / `tax` / `total` | number | — |
| `currency` | string? | 默认 `¥` |
| `status` | `draft` \| `issued` \| `sent` \| `paid` \| `overdue` \| `cancelled` | 草稿/已开具/已发送/已收款/逾期/已作废 |
| `issueDate` / `dueDate` / `paidDate` | string? | — |
| `items` | array? | 明细行 |
| `onView` / `onSend` / `onMarkPaid` | fn? | — |

**Legacy**：`invoiceNo` → `invoiceNumber`；`vendor`/`buyer` → `client`；`date` → `issueDate`；`taxAmount` → `tax`；嵌套 `invoice`；中文 status（待开票/已开票…）。

**Vue**：`packages/vue/src/finance/InvoiceCard.vue` — 可选嵌套 `invoice`；`@view` / `@send` / `@mark-paid`。

---

## ExpenseReportCard（finance）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `reportId` / `reportName` | string | — |
| `applicant` / `department` | string | — |
| `submitDate` | string | — |
| `totalAmount` | number | — |
| `status` | `draft` \| `submitted` \| `reviewing` \| `approved` \| `rejected` \| `paid` | — |
| `items` | ExpenseItem[] | — |
| `approver` / `approveDate` / `rejectReason` | ? | — |
| `onSubmit` / `onApprove` / `onReject` / `onViewDetail` | fn? | — |

**Legacy**：嵌套 `report`；`reportNo` → `reportId`；`amount` → `totalAmount`；`date` → `submitDate`；中文 status。

**Vue**：`packages/vue/src/finance/ExpenseReportCard.vue` — 可选嵌套 `report`；`@submit` / `@approve` / `@reject` / `@view-detail`。

---

## CaseCard（legal）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` | string | — |
| `caseNumber` | string | — |
| `caseType` | string | 展示用类型文案 |
| `title` / `client` | string | — |
| `opposingParty` | string? | — |
| `status` | `pending` \| `processing` \| `trial` \| `judgment` \| `closed` | 待受理/办理中/审理中/待判决/已结案 |
| `filingDate` / `courtDate` | string | — |
| `lawyer` / `deadline` / `nextStep` | string? | — |
| `onDetail` / `onUpdate` | fn? | — |

**Legacy**：嵌套 `caseInfo`；`caseNo` → `caseNumber`；`type` → `caseType`；`nextDate` → `courtDate`；中文 status。

**Vue**：`packages/vue/src/legal/CaseCard.vue` — 可选嵌套 `caseInfo`；`@detail` / `@update`；中文 status normalize。

---

## EvidenceCard（legal）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `caseId` | string? | — |
| `items` | `{ name, type, uploadDate, size? }[]` | 列表 |
| `onUpload` | fn? | — |

**Shell 单条展示**：`caseId`, `name`, `type`, `uploadDate`, `size`, `status`。  
**Legacy**：嵌套 `evidence` 单条 → 合成 `items`。

**Vue**：`packages/vue/src/legal/EvidenceCard.vue` — `items[]` 或扁平单条；`@upload` / `@item-click`。

---

## CourseCard（education）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `image` | string? | — |
| `title` | string | — |
| `teacher` / `price` / `originalPrice` / `duration` | string? | — |
| `studentCount` | number? | — |
| `rating` | number? | — |
| `tags` | string[]? | — |
| `status` | `enrolling` \| `ongoing` \| `ended` | 招生中/进行中/已结束 |
| `onClick` | fn? | RN：`onPress` |

**Legacy**：嵌套 `course`；`name` → `title`；`enrolled` → `studentCount`；`schedule` → `duration`；中文 status。

**Vue**：`packages/vue/src/education/CourseCard.vue` — 可选嵌套 `course`；`@click` / `@press`；中文 status normalize。

---

## ClassSchedule（education）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `className` / `gradeLevel` / `semester` | string? | — |
| `schedule` | ClassScheduleItem[] | 见下 |
| `onClassClick` | fn? | — |

**ClassScheduleItem**：`id`, `subject`, `teacher`, `room`, `dayOfWeek`, `startPeriod`, `endPeriod`, `startTime`, `endTime`, `type`。

**Legacy**：嵌套 `scheduleInfo` / `slots`；`term` → `semester`；`weekday` → `dayOfWeek`。

**Vue**：`packages/vue/src/education/ClassSchedule.vue` — 可选 `scheduleInfo` + `schedule[]`；`@class-click`；扁平单节次 shell 可合成。

---

## InventoryCard（logistics）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `name` / `sku` | string | — |
| `quantity` | number | — |
| `unit` | string | — |
| `location` | string? | — |
| `warningThreshold` | number? | 默认 10 |
| `status` | `normal` \| `low` \| `out` | 可自动推导 |
| `onReorder` / `onView` | fn? | — |

**Legacy**：嵌套 `inventory`；`warehouse` → `location`；`minStock` → `warningThreshold`。

**Vue**：`packages/vue/src/logistics/InventoryCard.vue` — 可选嵌套 `inventory`；`@view` / `@reorder`；status 可按 quantity 推导。

---

## TransportCard（logistics）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `routeName` / `carrier` | string | — |
| `status` | `pending` \| `in_transit` \| `delivered` \| `exception` | 可含 `loading` 扩展 |
| `routes` | TransportRoute[] | — |
| `vehicleNo` | string? | — |
| `onPress` / `onRoutePress` | fn? | — |

**Legacy**：嵌套 `transport`；`waybillNo` → `routeName`；`from`/`to` → origin/destination。

**Vue**：`packages/vue/src/logistics/TransportCard.vue` — 可选嵌套 `transport`；`@press` / `@view` / `@route-press`。

---

## Shell 平台字段 key（phase6 同步）

生成器 `scripts/phase6-industries.json` 的 `fields` 应使用 **canonical 英文 key**（与 React / 上表一致）。  
中文仅出现在 label（`scripts/labels.zh.json`）。

| 组件 | Canonical fields（深对齐后） |
|------|------------------------------|
| PatientCard | `id`, `name`, `gender`, `age`, `phone`, `department`, `visitType`, `status`, `queueNumber`, `visitTime` |
| MedicalRecordCard | `recordId`, `patientName`, `patientId`, `recordType`, `date`, `department`, `doctor`, `diagnosis`, `status` |
| ProductCard | `id`, `name`, `price`, `originalPrice`, `sales`, `image`, `status` |
| CartItem | `id`, `name`, `price`, `quantity`, `sku`, `selected` |
| InvoiceCard | `id`, `invoiceNumber`, `type`, `client`, `amount`, `tax`, `total`, `status`, `issueDate`, `dueDate` |
| ExpenseReportCard | `reportId`, `reportName`, `applicant`, `department`, `submitDate`, `totalAmount`, `status` |
| CaseCard | `id`, `caseNumber`, `caseType`, `title`, `client`, `lawyer`, `filingDate`, `courtDate`, `status` |
| EvidenceCard | `caseId`, `name`, `type`, `uploadDate`, `size`, `status` |
| CourseCard | `title`, `teacher`, `price`, `duration`, `studentCount`, `status` |
| ClassSchedule | `className`, `gradeLevel`, `semester`, `subject`, `teacher`, `room`, `dayOfWeek` |
| InventoryCard | `id`, `name`, `sku`, `quantity`, `unit`, `location`, `status` |
| TransportCard | `routeName`, `carrier`, `status`, `vehicleNo`, `origin`, `destination` |
| PurchaseOrderCard | `id`, `orderNumber`, `supplier`, `totalAmount`, `status`, `orderDate`, `expectedDate`, `buyer` |
| SalesOrderCard | `orderNumber`, `customer`, `totalAmount`, `status`, `orderDate`, `deliveryDate`, `salesPerson` |
| ProductionLineCard | `lineId`, `lineName`, `product`, `target`, `actual`, `status`, `shift`, `efficiency` |
| ProductionPanel | `lineId`, `lineName`, `dailyOutput`, `dailyTarget`, `qualityRate`, `alarmCount`, `status` |
| PropertyCard | `id`, `title`, `price`, `area`, `rooms`, `address`, `status` |
| RepairTicketCard | `id`, `title`, `location`, `priority`, `status`, `reporter`, `assignee` |
| ServiceTicketCard | `id`, `ticketNumber`, `title`, `priority`, `assignee`, `status`, `client` |
| IncidentCard | `incidentId`, `title`, `level`, `status`, `assignee`, `createdAt` |
| ContractCard | `id`, `contractNumber`, `title`, `parties`, `amount`, `status`, `createdAt` |
| SigningProgress | `contractId`, `contractTitle`, `progress`, `signed`, `total`, `status` |
| MemberCard | `id`, `name`, `phone`, `cardType`, `expireDate`, `remainingSessions`, `status` |
| FitnessCourseCard | `name`, `coach`, `time`, `duration`, `capacity`, `enrolled`, `status` |
| GameRoomCard | `id`, `roomNumber`, `gameName`, `playerCount`, `maxPlayers`, `status` |
| PlayerListCard | `nickname`, `level`, `coins`, `status` |
| WeddingCard | `id`, `couple`, `date`, `venue`, `guestCount`, `status` |
| GuestListCard | `name`, `tableNumber`, `status`, `phone`, `relationship` |

其余行业卡：字段 key 继续以 phase6 + React 同名 props 为准，逐步收敛；**不**把中文当 prop 名。

---

## PurchaseOrderCard（erp）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `orderNumber` | string | — |
| `supplier` | string | — |
| `orderDate` / `expectedDate` | string? | — |
| `totalAmount` | number | — |
| `currency` | string? | 默认 `¥` |
| `status` | `draft` \| `submitted` \| `approved` \| `ordered` \| `partial_received` \| `received` \| `closed` \| `cancelled` | 草稿/已提交/已审批/已下单/部分到货/已收货/已关闭/已取消 |
| `items` | array \| number? | 明细或数量 |
| `buyer` / `warehouse` | string? | — |
| `onApprove` / `onReceive` / `onView` / `onCancel` | fn? | — |

**Legacy**：`orderNo` → `orderNumber`；`vendor` → `supplier`；`amount` → `totalAmount`；`date`/`createTime` → `orderDate`；`expectDate` → `expectedDate`；嵌套 `order`；中文 status。

**Vue**：`packages/vue/src/erp/PurchaseOrderCard.vue` — 可选嵌套 `order`；`@approve` / `@receive` / `@view` / `@cancel`。

---

## SalesOrderCard（erp）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `orderNumber` / `customer` | string | — |
| `orderDate` / `deliveryDate` | string? | — |
| `totalAmount` | number | — |
| `status` | `draft` \| `confirmed` \| `processing` \| `shipped` \| `delivered` \| `invoiced` \| `completed` \| `cancelled` | — |
| `items` | array? | — |
| `salesPerson` / `shippingAddress` | string? | — |
| `onShip` / `onInvoice` / `onView` / `onCancel` | fn? | — |

**Legacy**：`orderNo` → `orderNumber`；`amount` → `totalAmount`；`date` → `orderDate`；`shipping` → `shipped`；嵌套 `order`。

**Vue**：`packages/vue/src/erp/SalesOrderCard.vue` — 可选嵌套 `order`；`@ship` / `@invoice` / `@view` / `@cancel`。

---

## ProductionLineCard（manufacturing）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `lineName` / `lineId` | string | — |
| `product` | string | — |
| `target` / `actual` | number | — |
| `unit` | string | — |
| `status` | `running` \| `idle` \| `maintenance` \| `fault` \| `stopped` | 生产中/空闲/维护中/故障/已停止 |
| `efficiency` / `defectRate` | number | — |
| `operator` / `shift` | string? | — |
| `onStart` / `onStop` / `onReport` | fn? | — |

**Legacy**：`name` → `lineName`；`id` → `lineId`；嵌套 `line`；`outputToday`/`targetToday` → actual/target。

**Vue**：`packages/vue/src/manufacturing/ProductionLineCard.vue` — 可选嵌套 `line`；`@start` / `@stop` / `@report`。

---

## ProductionPanel（manufacturing）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `lineId` / `lineName` | string | — |
| `stations` | `{ id, name, status, operator?, output?, target? }[]` | — |
| `dailyOutput` / `dailyTarget` | number? | — |
| `qualityRate` / `runHours` / `alarmCount` | number? | — |
| `onStationClick` / `onAlarmClick` / `onRefresh` | fn? | — |

**Legacy**：`output` → `dailyOutput`；`target` → `dailyTarget`；`oee` → `qualityRate`。

**Vue**：`packages/vue/src/manufacturing/ProductionPanel.vue` — 可选嵌套 `panel`；`@station-click` / `@alarm-click` / `@refresh`。

---

## PropertyCard（property）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `title` | string | — |
| `price` / `area` | number | — |
| `rooms` / `halls` | number? | — |
| `address` | string | — |
| `status` | `for_sale` \| `sold` \| `reserved` | UI：待售/已售/预订 |
| `images` / `tags` | array? | — |
| `onClick` | fn? | RN：`onPress` |

**Legacy**：`name` → `title`；中文 status（待售/在售/已售/预订）。

**Vue**：`packages/vue/src/property/PropertyCard.vue` — 可选嵌套 `property`；`@click` / `@press`；中文 status normalize。

---

## RepairTicketCard（property）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `title` / `location` | string | — |
| `status` | `pending` \| `assigned` \| `in_progress` \| `completed` \| `verified` | — |
| `priority` | `low` \| `medium` \| `high` \| `urgent` | — |
| `reporter` / `assignee` / `createdAt` / `description` | ? | — |
| `onAssign` / `onComplete` / `onView` | fn? | — |

**Legacy**：`ticketNo` → `id`；`issue` → `title`；嵌套 `ticket`。

**Vue**：`packages/vue/src/property/RepairTicketCard.vue` — 可选嵌套 `ticket`；`@assign` / `@complete` / `@view`；中文 status/priority normalize。

---

## ServiceTicketCard（it-service）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `ticketNumber` / `title` | string | — |
| `client` / `serviceType` | string | — |
| `status` | `open` \| `assigned` \| `in_progress` \| `resolved` \| `closed` | — |
| `priority` | `low` \| `medium` \| `high` \| `critical` | — |
| `assignee` / `createdAt` / `updatedAt` / `slaDeadline` | ? | — |
| `onAccept` / `onResolve` / `onView` | fn? | — |

**Legacy**：`ticketNo` → `ticketNumber`；中文 status/priority；嵌套 `ticket`。

**Vue**：`packages/vue/src/it-service/ServiceTicketCard.vue` — 可选嵌套 `ticket`；`@accept` / `@resolve` / `@view`。

---

## IncidentCard（it-service）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `title` | string | — |
| `level` | `P1` \| `P2` \| `P3` \| `P4` | — |
| `status` | `open` \| `investigating` \| `resolved` \| `closed` | — |
| `assignee` / `createdAt` / `description` | ? | — |
| `onAction` | fn? | — |

**Legacy**：`severity` → `level`；`startedAt` → `createdAt`；`impact` → `description`；`incidentId` 为 shell 扩展。

**Vue**：`packages/vue/src/it-service/IncidentCard.vue` — 可选嵌套 `incident`；`@action` / `@press` / `@view`。

---

## ContractCard（esign）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `contractNumber` | string | — |
| `title` | string | — |
| `parties` | string[] | shell 可用逗号拼接 string |
| `status` | `draft` \| `pending` \| `signing` \| `completed` \| `expired` \| `cancelled` | 草稿/待签署/签署中/已完成/已过期/已取消 |
| `amount` / `currency` | number? / string? | 默认 `¥` |
| `templateName` | string? | — |
| `createdAt` / `expiresAt` / `signedAt` | string? | — |
| `signProgress` | `{ total, signed }`? | — |
| `onView` / `onSign` / `onSend` | fn? | — |

**Legacy**：`contractNo` → `contractNumber`；`createTime` → `createdAt`；`expireTime` → `expiresAt`；嵌套 `contract`；中文 status（待签署/签署中/已完成…）。

**Vue**：`packages/vue/src/esign/ContractCard.vue` — 可选嵌套 `contract`；`@view` / `@sign` / `@send`。

---

## SigningProgress（esign）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `contractTitle` / `contractId` | string | — |
| `signers` | `Signer[]` | `{ id, name, role, status, signedAt? }` |
| `overallStatus` | `draft` \| `pending` \| `partial` \| `completed` \| `expired` \| `rejected` | shell 可用 `status` |
| `progress` | number | 0–100 |
| `createdAt` / `expiresAt` | string? | — |
| `onRemind` / `onSign` / `onViewContract` | fn? | — |

**Legacy**：嵌套 `progressInfo` / `steps` → `signers`；`overallProgress` → `progress`；`contractNo` → `contractId`；signer `done`/`current` → `signed`/`pending`。

**Vue**：`packages/vue/src/esign/SigningProgress.vue` — 可选嵌套 `progressInfo`；`@remind` / `@sign` / `@view-contract`。

---

## MemberCard（fitness）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `name` / `phone` | string | — |
| `memberCard` | `{ type, startDate, endDate, remainingSessions? }` | shell 扁平：`cardType` / `expireDate` / `remainingSessions` |
| `status` | `active` \| `expired` \| `frozen` \| `pending` | 有效/已过期/冻结/待续费 |
| `lastVisit` / `nextCourse` | ? | — |
| `onBook` / `onRenew` / `onView` | fn? | — |

**Legacy**：嵌套 `member`；`cardType` → `memberCard.type`；`expireDate` → `endDate`；`remainTimes` → `remainingSessions`；中文 status（正常/冻结/过期）。

**Vue**：`packages/vue/src/fitness/MemberCard.vue` — 可选嵌套 `member` + `memberCard`；`@book` / `@renew` / `@view`。

---

## FitnessCourseCard / CourseCard（fitness）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `name` | string | shell / Flutter 包名 `FitnessCourseCard`；legacy `title` |
| `coach` / `time` / `duration` | string | — |
| `capacity` / `enrolled` | number | 可推导 full |
| `category` | string? | — |
| `onBook` | fn? | — |

**Legacy**：嵌套 `course`；`title` → `name`；`startTime` → `time`；`durationMin` → `duration`。

**Vue**：`packages/vue/src/fitness/FitnessCourseCard.vue` — 可选嵌套 `course`；`@book`；满员隐藏预约。

---

## GameRoomCard（gaming）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `roomNumber` | string | — |
| `roomType` | `dou dizhu` \| `mahjong` \| `poker` \| `chess` \| `custom` | UI 中文 label |
| `gameName` | string | — |
| `playerCount` / `maxPlayers` | number | — |
| `status` | `waiting` \| `playing` \| `full` \| `closed` | 等待中/进行中/已满/已关闭 |
| `hostName` / `isVip` / `roomCardCost` | ? | React 另有中文 prop `房卡消耗`（扩展） |
| `onJoin` / `onClose` / `onView` | fn? | — |

**Legacy**：`roomNo`/`roomId` → `roomNumber`；`game` → `gameName`；`players` → `playerCount`；中文 status（空闲/游戏中/已满…）。

**Vue**：`packages/vue/src/gaming/GameRoomCard.vue` — 可选嵌套 `room`；`@join` / `@close` / `@view`；`roomCardCost` / `房卡消耗`。

---

## PlayerListCard（gaming）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `players` | `PlayerItem[]` | shell 单行：`nickname`/`level`/`coins`/`status` |
| `title` / `totalOnline` | ? | — |
| PlayerItem | `id`, `nickname`, `level`, `coins`, `status` | status: `online` \| `offline` \| `playing` |
| `onPlayerClick` / `onBan` | fn? | — |

**Legacy**：`name` → `nickname`；`score` → `coins`；`away` → `offline`。

**Vue**：`packages/vue/src/gaming/PlayerListCard.vue` — `players[]` 或扁平单条；`@player-click` / `@ban`。

---

## WeddingCard（wedding）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` | string | — |
| `couple` | `{ groom, bride }` | shell 可用 string `新人名` |
| `date` / `time?` / `venue` | string | — |
| `status` | `booked` \| `confirmed` \| `completed` \| `cancelled` | 已预约/已确认/已完成/已取消 |
| `package` / `guestCount` / `confirmedCount` / `budget` / `paidAmount` / `phone` | ? | — |
| `onDetail` / `onEdit` / `onConfirm` | fn? | — |

**Legacy**：`coupleName` → 解析为 couple；中文 status（已预订/进行中…）。

**Vue**：`packages/vue/src/wedding/WeddingCard.vue` — 可选嵌套 `wedding`；`@detail` / `@edit` / `@confirm`。

---

## GuestListCard（wedding）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `guests` | `Guest[]` | shell 单行字段 |
| Guest | `name`, `relationship`, `tableNumber?`, `status`, `plusOne?` | status: `confirmed` \| `pending` \| `declined` |
| `title` | string? | 默认「宾客名单」 |

**Legacy**：`tableNo` → `tableNumber`；`rsvp`/`accepted` → `status`/`confirmed`；单 guest 模式仍可用。

**Vue**：`packages/vue/src/wedding/GuestListCard.vue` — `guests[]` 或扁平单条；`@guest-click` / `@confirm`。

---

## ChargingStation（hardware）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `stationNumber` | string | — |
| `stationType` | `AC` \| `DC` | — |
| `power` | number | kW |
| `status` | `idle` \| `charging` \| `completed` \| `fault` \| `offline` | — |
| `vehiclePlate` / `batteryLevel` / `totalFee` | ? | — |
| `onStart` / `onStop` / `onView` | fn? | — |

**Legacy**：中文 status（空闲/充电中/已完成/故障/离线）；可选嵌套 `station`。

**Vue**：`packages/vue/src/hardware/ChargingStation.vue` — 可选嵌套 `station`；`@start` / `@stop` / `@view`。

## DeviceStatusCard（hardware）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `name` | string | — |
| `type` | string | charger / elevator / … |
| `location` | string? | — |
| `status` | `online` \| `offline` \| `warning` \| `fault` \| `maintenance` | — |
| `lastHeartbeat` / `battery` / `metrics` | ? | — |
| `onView` / `onControl` | fn? | — |

**Legacy**：中文 status；`deviceName`/`deviceType`；可选嵌套 `device`。

**Vue**：`packages/vue/src/hardware/DeviceStatusCard.vue` — 可选嵌套 `device`；`@view` / `@control`。

## VideoCard（video）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `title` | string | — |
| `duration` / `thumbnail` / `author` / `category` | ? | — |
| `views` / `likes` | number? | — |
| `status` | `published` \| `draft` \| `processing` \| `failed` | — |
| `onClick` / `onDelete` | fn? | — |

**Legacy**：中文 status（已发布/草稿/处理中/失败）；可选嵌套 `video`。

**Vue**：`packages/vue/src/video/VideoCard.vue` — 可选嵌套 `video`；`@click` / `@delete`。

## VideoPlayer（video）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `src` | string | 视频源 |
| `poster` / `title` / `duration` | ? | — |
| `status` | `idle` \| `loading` \| `playing` \| `paused` \| `error` \| `ended` | — |
| `autoPlay` / `controls` / `loop` / `muted` / `speed` | ? | — |
| `onStatusChange` / `onTimeUpdate` / `onEnded` | fn? | — |

**Vue**：`packages/vue/src/video/VideoPlayer.vue` — 可选嵌套 `player`；`@status-change` / `@time-update` / `@play` / `@pause` / `@ended`（演示可用 mock 进度，不依赖真实 `<video>`）。

## CampaignCard（advertising）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `name` | string | — |
| `platform` | string | douyin / wechat / … |
| `budget` / `spent` | number | — |
| `impressions` / `clicks` / `conversions` | number? | — |
| `status` | `draft` \| `pending` \| `running` \| `paused` \| `ended` | — |
| `onView` / `onPause` / `onResume` | fn? | — |

**Legacy**：中文 status（草稿/投放中/已暂停…）；可选嵌套 `campaign`。

**Vue**：`packages/vue/src/advertising/CampaignCard.vue` — 可选嵌套 `campaign`；`@view` / `@pause` / `@resume`。

## AdScheduleCard（advertising）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `adId` / `adName` / `channel` | string | — |
| `startDate` / `endDate` | string | — |
| `budget` | number | — |
| `status` | `pending` \| `running` \| `paused` \| `ended` | 待投放/投放中/已暂停/已结束 |
| `impressions` / `clicks` / `ctr` | number? | — |
| `onEdit` / `onPause` / `onDelete` | fn? | Vue 另有 `@resume` |

**Legacy**：`id`/`name` → `adId`/`adName`；`date` 可拆周期；中文 status。

**Vue**：`packages/vue/src/advertising/AdScheduleCard.vue` — 可选嵌套 `schedule`；`@edit` / `@pause` / `@resume` / `@delete`。

## ChildPatientCard（children）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `name` / `age` | — | age 可 number 或 string |
| `gender` | male \| female | — |
| `guardian` / `parentName` / `department` / `chiefComplaint` | ? | — |
| `status` | waiting \| consulting \| examining \| prescribed \| completed | 同 medical |
| `onView` / `onCall` | fn? | — |

**Legacy**：中文 status；`guardian` → `parentName`；可选嵌套 `patient`。

**Vue**：`packages/vue/src/children/ChildPatientCard.vue` — 可选嵌套 `patient`；`@view` / `@call`。

## StudentCard（children）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `name` / `studentId` / `className` | string | className 为班级文案 |
| `gender` | male \| female | — |
| `grade` | A \| B \| C \| D | 成绩等级 |
| `attendance` | present \| absent \| late \| leave | 考勤 |
| `parentName` / `phone` / `avatar` | ? | — |
| `onClick` | fn? | — |

**Vue**：`packages/vue/src/children/StudentCard.vue` — 可选嵌套 `student`；`@click` / `@view`。

## RoomStatusCard（bath）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `id` / `roomNumber` / `roomType` | string | shell 可用 roomNo |
| `status` | vacant \| occupied \| reserved \| cleaning \| maintenance | — |
| `guestName` / `checkInTime` / `amount` | ? | — |
| `onCheckIn` / `onCheckOut` / `onView` / `onClean` | fn? | — |

**Legacy**：中文 status；`roomNo` → `roomNumber`；可选嵌套 `room`。

**Vue**：`packages/vue/src/bath/RoomStatusCard.vue` — 可选嵌套 `room`；`@check-in` / `@check-out` / `@view` / `@clean`。

## ServiceMenuCard（bath）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `services` | `ServiceItem[]` | `{ id, name, category, duration, price, available, description? }` |
| `selectedIds` | string[]? | — |
| `onSelect` | `(service) => void` | Vue：`@select` |

**Legacy**：扁平单条 `name`/`price`/`duration`/`category` 可合成单服务列表。

**Vue**：`packages/vue/src/bath/ServiceMenuCard.vue` — `services[]` 或扁平单条；`@select`。

## HomeworkCard（k12）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `homeworkId` / `title` / `subject` / `teacher` / `dueDate` | string | — |
| `submittedCount` / `totalStudents` | number | — |
| `status` | pending \| submitted \| graded | — |
| `score` | number? | 已批改时 |
| `onDetail` | fn? | Vue 另有 `@submit` |

**Vue**：`packages/vue/src/k12/HomeworkCard.vue` — 可选嵌套 `homework`；`@detail` / `@submit`。

## StudentRecordCard（k12）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `name` / `studentId` | string | — |
| `grade` / `classNameLabel` | string? | shell 可用 `className_` |
| `status` | active \| leave \| graduated \| suspended | — |
| `gpa` / `attendanceRate` | number? | — |
| `homework` | `{ subject, status, score? }[]`? | — |
| `onView` | fn? | — |

**Vue**：`packages/vue/src/k12/StudentRecordCard.vue` — 可选嵌套 `student`；`@view`。

## ApprovalFlow（workflow）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `nodes` | `ApprovalNode[]` | `{ id, label, status, approver?, avatar?, time?, comment? }` |
| `nodes[].status` | pending \| approved \| rejected \| processing \| skipped | UI：待审批/已通过/已驳回/审批中/已跳过 |
| `title` | string? | — |
| `onNodeClick` | `(id) => void` | Vue：`@node-click` |

**Shell / phase6 扁平**：`title` `applicant` `currentStep` `totalSteps` `status`（无 `nodes` 时展示摘要）。

## TicketStatus（workflow）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `ticket` | `{ id, title, status, priority, assignee?, createdAt }` | 嵌套 |
| `ticket.status` | open \| in_progress \| resolved \| closed | UI：待处理/处理中/已解决/已关闭 |
| `ticket.priority` | low \| medium \| high \| urgent | UI：低/中/高/紧急 |
| `compact` | boolean? | 默认 false |

**Legacy / shell**：`ticketNo`→`id`；`type`/`title`；`updatedAt`→`createdAt`；中文 status。

## PermissionTree（workflow）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `data` | `TreeNode[]` | `{ id, label, checked?, children? }` |
| `title` | string? | — |
| `selectable` | boolean? | 默认 true |
| `onCheck` | `(id, checked) => void` | Vue：`@check` |

## SKUSelector（ecommerce）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `options` | `{ name, values: { label, available, image? }[] }[]` | — |
| `selected` | `Record<string, string>` | 组名 → 选中 label |
| `onSelect` | `(group, value) => void` | Vue：`@select` |

## ServerStatus（monitor）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `servers` | `{ id, name, ip, status, cpu, memory, disk, uptime? }[]` | status: `online` \| `offline` \| `warning` \| `error` |
| `title` | string? | 区块标题 |
| 扁平 legacy | `id`/`name`/`ip`/`cpu`/`memory`/`disk`/`status`/`uptime` | 单机合成一条 |
| `@view` / `@click` | `(id) => void` | 点击服务器卡片 |

## DeviceStatus（monitor）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `device` | 可选嵌套 | Vue 加深 |
| `id` / `name` / `type` / `ip` / `status` | 与 React 一致 | type: `server` \| `switch` \| `storage` \| `other` |
| `cpu` / `memory` / `disk` / `uptime` | number / string | — |
| phase6 legacy | `deviceId` / `location` / `online` | 可 normalize |
| `@click` / `@view` / `@control` | `(id) => void` | Vue 可选控制按钮 |

## KPIBoard（bi）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `items` | `{ title, value, unit?, trend?, trendValue?, color?, icon? }[]` | trend: `up` \| `down` \| `flat` |
| `columns` | number? | 默认 4 |
| 扁平 legacy | `title`/`value`/`unit`/`trend`/`trendValue` | 单指标 |
| `@item-click` / `@view` | `(item, index)` | Vue |

## Gauge（bi）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `value` / `min` / `max` | number | 默认 0–100 |
| `title` | string? | phase6 `label` 作别名 |
| `unit` / `size` / `color` / `showLabel` | 可选 | SVG 半环 |

## PortraitKPI（portrait）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `items` | `{ id, label, value, unit?, change?, icon?, color? }[]` | — |
| `layout` | `vertical` \| `grid` | `portrait` 强制 vertical |
| 扁平 legacy | `label`/`value`/`unit`/`delta` | delta → change |
| `@item-click` | `(item)` | Vue |

## PortraitList（portrait）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `items` | `{ id, title?, subtitle?, segment?, status? }[]` | 需 `id` |
| `loading` / `emptyText` / `virtualScroll` / `itemHeight` | 可选 | — |
| 扁平 legacy | `title`/`count`/`segment`/`status` | 合成单行 |
| `@item-click` / `@view` | `(item, index)` | Vue |

## ClipboardField（tools）· 对齐 React `Clipboard`

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `text` | string | phase6 `value` 别名 |
| `label` / `buttonLabel` | string? | 默认「复制」 |
| `@success` / `@error` / `@copy` | 回调 | 复制反馈 |

## Watermark（tools）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `text` / `image` | string? | 默认「保密」 |
| `rotate` | number? | phase6 `angle` 别名 |
| `opacity` / `fontSize` / `color` / `gap` | 可选 | 默认 slot 内容区 |

## VirtualList（advanced）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `items` | `T[]` | Vue 加深；无 `items` 时用 `itemCount` 生成占位 |
| `itemHeight` / `height` | number | 行高 / 视口高（px） |
| `overscan` | number? | 默认 5 |
| `animateItems` | boolean? | 默认 true；尊重 reduced-motion |
| phase6 legacy | `itemCount` / `itemHeight` / `overscan` | 扁平壳字段 |
| 默认 slot | `{ item, index }` | Vue 行渲染；无 slot 时展示 title/label |
| `@item-click` / `@view` | `(item, index)` | Vue |
| `@scroll` | `(scrollTop)` | Vue |

## SplitPane（advanced）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `direction` | `horizontal` \| `vertical` | phase6 `orientation` 别名（中文可 normalize） |
| `defaultSplit` | number? | 主栏默认 %，默认 50 |
| `minLeft` / `minRight` | number? | 最小 px，默认 100 |
| phase6 legacy | `primarySize` / `minSize` | primarySize 可 `%`；minSize 双侧共用 |
| `v-model` / `modelValue` | number? | 受控 split % |
| slots | `#left` / `#right`（或 `#primary` / `#secondary`） | 对齐 React left/right |
| `@resize` / `@resize-end` | `(split: number)` | 拖拽中 / 结束 |
| 交互 | 鼠标 / 触摸 / 方向键 | separator 可键盘微调 |

## ThemeProvider（global）

| Prop / 事件 / API | React (canonical) | 备注 |
|-------------------|-------------------|------|
| `defaultMode` | `light` \| `dark` | 无 storage 时可跟随系统 |
| `defaultPalette` | `blue`…`orange` | 六色系；中文可 normalize |
| `storageKey` | string? | 默认 `ui-theme` |
| `applyToRoot` | boolean? | Vue：默认 true 写 `documentElement` |
| provide / `useTheme` | mode / palette / setMode / setPalette / toggleMode | Vue provide/inject |
| `@change` / `@update:mode` | 可选 | Vue 加深事件 |
| `generateCSSVariables` / `getThemeCSSVars` | 工具 | 与 React tokens 色变量对齐 |

## BreakpointDetector（global）

| Prop / 事件 / API | React (canonical) | 备注 |
|-------------------|-------------------|------|
| `mockWidth` / `mockHeight` | — | Vue 演示/测试覆盖视口 |
| provide / `useBreakpoint` | device / width / height / isMobile… / isTouch | 对齐 React 设备枚举 |
| `useResponsive` | 按 device 取值 | 同 React |
| `@change` | `{ device, interaction, width, height }` | Vue |

## EmptyState（global）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| `type` | `noData` \| `noPermission` \| `loadFailed` \| `networkError` | 中文可 normalize |
| `title` / `description` | string? | 默认中文文案 |
| `message` | — | phase6 / 描述别名 |
| `actionLabel` + `@action` / `@retry` | action 节点 | Vue 默认按钮；slot `#action` / `#icon` |

## GlobalLoading（global）

| Prop | React (canonical) | 备注 |
|------|-------------------|------|
| `visible` | boolean | 别名 `loading` / `show` |
| `tip` | string? | 别名 `text` / `message` |
| `fullScreen` | boolean? | 全屏固定遮罩 + Teleport body |

## ErrorBoundary（global）

| Prop / 事件 | React (canonical) | 备注 |
|-------------|-------------------|------|
| 子树错误捕获 | class boundary | Vue `onErrorCaptured` |
| `#fallback` | fallback 节点 | slot 参数 `{ error, retry }` |
| `@error` / `@retry` | onError | 重试清除 hasError |

## PortalContainer（global）

| Prop / API | React (canonical) | 备注 |
|------------|-------------------|------|
| `zIndex` | number? | 基准 z，默认 1000 |
| `portalId` | string? | 默认 `portal-root` 挂载点 |
| `usePortal` | getNextZIndex / register / unregister | provide/inject |

## 覆盖进度

| 端 | 14 行业批次 (medical…wedding) | 剩余行业 (hardware…tools) + advanced + global |
|----|-------------------------------|-----------------------------------------------|
| RN | 深对齐 | 字段深对齐骨架 |
| Flutter | 深对齐 | 字段深对齐骨架 |
| 微信 / 支付宝 / 抖音 | shell 字段 key | shell 字段 key 已同步 |
| WC / Electron | shell 字段 key | shell 字段 key 已同步 |
| phase6 json | 已对齐 | 已对齐 |
| Vue | 高交互加深 | **monitor / bi / portrait / tools / advanced / global 已加深** |

**已完成**：Vue 行业卡嵌套 API 加深至 ecommerce…tools + advanced（VirtualList / SplitPane）+ global 基建；`demo.html` 对应可交互演示。

**冒烟基建**：`pnpm smoke`（`scripts/smoke-check.ps1`）静态校验三端小程序宿主 + phase6 52 卡 + Android/iOS/Flutter/RN；清单见 `docs/smoke-checklist.md`。小程序可导入 `packages/miniapp/{weixin,alipay,douyin}` 打开冒烟页。

**可选后续**：在装有 DevTools / Android Studio / Xcode 的机器上完成人工真机勾选；截图验收流水线。
