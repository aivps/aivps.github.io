﻿import SwiftUI

/// 购物车项 - industry (SwiftUI, field-deep aligned)
public struct CartItem: View {
    public var id: String = ""
    public var name: String = ""
    public var price: String = ""
    public var quantity: String = ""
    public var sku: String = ""
    public var selected: String = ""

    public init(id: String = "", name: String = "", price: String = "", quantity: String = "", sku: String = "", selected: String = "") {
        self.id = id
        self.name = name
        self.price = price
        self.quantity = quantity
        self.sku = sku
        self.selected = selected
    }

    public var body: some View {
        IndustryCardShell(
            title: "购物车项",
            status: nil,
            fields: [
            ("ID", id),
            ("名称", name),
            ("价格", price),
            ("数量", quantity),
            ("SKU", sku),
            ("已选", selected),
            ]
        )
    }
}
