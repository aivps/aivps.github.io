import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface ServiceMenuCardProps {
  name?: string;
  price?: string;
  duration?: string;
  category?: string;
  status?: string;
  onClick?: () => void;
}

/** ServiceMenuCard - Electron shell (field keys aligned to React) */
export const ServiceMenuCard: React.FC<ServiceMenuCardProps> = (props) => (
  <IndustryCardShell title="ServiceMenuCard" status={props.status} onClick={props.onClick}>
      {props.name ? <div className="row"><span className="label">name</span><span>{props.name}</span></div> : null}
      {props.price ? <div className="row"><span className="label">price</span><span>{props.price}</span></div> : null}
      {props.duration ? <div className="row"><span className="label">duration</span><span>{props.duration}</span></div> : null}
      {props.category ? <div className="row"><span className="label">category</span><span>{props.category}</span></div> : null}
  </IndustryCardShell>
);

export default ServiceMenuCard;