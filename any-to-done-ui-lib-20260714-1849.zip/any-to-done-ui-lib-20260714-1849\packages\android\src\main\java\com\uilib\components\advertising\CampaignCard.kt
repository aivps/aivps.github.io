package com.uilib.components.advertising

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 广告活动 - advertising industry (Compose) */
@Composable
fun CampaignCard(
    name: String = "",
    budget: String = "",
    spent: String = "",
    impressions: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "广告活动",
        status = status.ifBlank { null },
        fields = listOf(
            "名称" to name,
            "预算" to budget,
            "已花费" to spent,
            "曝光量" to impressions,
        ),
        modifier = modifier,
    )
}