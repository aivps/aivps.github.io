package com.uilib.components.monitor

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 服务器 - monitor industry (Compose) */
@Composable
fun ServerStatus(
    hostname: String = "",
    cpu: String = "",
    memory: String = "",
    disk: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "服务器",
        status = status.ifBlank { null },
        fields = listOf(
            "主机名" to hostname,
            "CPU" to cpu,
            "内存" to memory,
            "磁盘" to disk,
        ),
        modifier = modifier,
    )
}