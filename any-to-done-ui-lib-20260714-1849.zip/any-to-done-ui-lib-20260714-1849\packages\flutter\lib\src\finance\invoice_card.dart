import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// InvoiceCard — field-deep aligned to React InvoiceCard.
/// Canonical: flat props + English enums. Legacy Chinese status accepted.
class InvoiceCard extends StatelessWidget {
  final String id;
  final String invoiceNumber;
  final String type; // sales | purchase | expense
  final String client;
  final double amount;
  final double tax;
  final double total;
  final String currency;
  final String status; // draft | issued | sent | paid | overdue | cancelled
  final String issueDate;
  final String? dueDate;
  final String? paidDate;
  final VoidCallback? onTap;
  final ValueChanged<String>? onView;
  final ValueChanged<String>? onSend;
  final ValueChanged<String>? onMarkPaid;
  final bool disabled;

  /// @deprecated aliases
  final String? invoiceNo;
  final String? buyer;
  final String? vendor;
  final String? date;
  final double? taxAmount;

  const InvoiceCard({
    super.key,
    this.id = '',
    this.invoiceNumber = '',
    this.type = 'sales',
    this.client = '',
    this.amount = 0,
    this.tax = 0,
    this.total = 0,
    this.currency = '¥',
    required this.status,
    this.issueDate = '',
    this.dueDate,
    this.paidDate,
    this.onTap,
    this.onView,
    this.onSend,
    this.onMarkPaid,
    this.disabled = false,
    this.invoiceNo,
    this.buyer,
    this.vendor,
    this.date,
    this.taxAmount,
  });

  String get _invoiceNumber =>
      invoiceNumber.isNotEmpty ? invoiceNumber : (invoiceNo ?? '');
  String get _client => client.isNotEmpty
      ? client
      : (buyer ?? vendor ?? '');
  String get _issueDate =>
      issueDate.isNotEmpty ? issueDate : (date ?? '');
  double get _tax => tax > 0 ? tax : (taxAmount ?? 0);
  double get _total => total > 0 ? total : amount + _tax;

  static const _statusLabels = {
    'draft': '草稿',
    'issued': '已开具',
    'sent': '已发送',
    'paid': '已收款',
    'overdue': '逾期',
    'cancelled': '已作废',
    '待开票': '草稿',
    '已开票': '已开具',
    '已作废': '已作废',
    '已红冲': '已作废',
  };

  static const _typeLabels = {
    'sales': '销售发票',
    'purchase': '采购发票',
    'expense': '费用发票',
  };

  String get _statusLabel => _statusLabels[status] ?? status;
  String get _typeLabel => _typeLabels[type] ?? type;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'draft':
      case '待开票':
      case 'cancelled':
      case '已作废':
      case '已红冲':
        return colors.muted;
      case 'issued':
      case 'sent':
      case '已开票':
        return colors.primary;
      case 'paid':
        return colors.success;
      case 'overdue':
        return colors.danger;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onView?.call(id);
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _invoiceNumber,
                          style: AppTypography.body
                              .copyWith(fontWeight: FontWeight.w600),
                        ),
                        Text(_typeLabel, style: AppTypography.caption),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style: AppTypography.caption.copyWith(color: sc),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: AppSpacing.md,
                decoration: BoxDecoration(
                  color: colors.bgPage,
                  borderRadius: AppSpacing.borderRadiusMd,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('合计', style: AppTypography.body),
                    Text(
                      '$currency${_total.toStringAsFixed(2)}',
                      style: AppTypography.h3,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              _buildInfoRow('客户', _client),
              _buildInfoRow('开票日期', _issueDate),
              if (dueDate != null) _buildInfoRow('到期日', dueDate!),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          SizedBox(
            width: 72,
            child: Text(label, style: AppTypography.caption),
          ),
          Expanded(child: Text(value, style: AppTypography.body)),
        ],
      ),
    );
  }
}
