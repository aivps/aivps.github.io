import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// GameRoomCard — field-deep aligned to React GameRoomCard.
/// status: waiting | playing | full | closed
class GameRoomCard extends StatelessWidget {
  final String id;
  final String roomNumber;
  final String roomType;
  final String gameName;
  final int playerCount;
  final int maxPlayers;
  final String status;
  final String? hostName;
  final bool isVip;
  final double? roomCardCost;
  final VoidCallback? onTap;
  final ValueChanged<String>? onJoin;
  final ValueChanged<String>? onClose;
  final ValueChanged<String>? onView;
  final bool disabled;

  /// @deprecated aliases
  final String? roomName;
  final String? roomNo;
  final String? game;
  final int? players;

  const GameRoomCard({
    super.key,
    this.id = '',
    this.roomNumber = '',
    this.roomType = 'custom',
    this.gameName = '',
    this.playerCount = 0,
    required this.maxPlayers,
    required this.status,
    this.hostName,
    this.isVip = false,
    this.roomCardCost,
    this.onTap,
    this.onJoin,
    this.onClose,
    this.onView,
    this.disabled = false,
    this.roomName,
    this.roomNo,
    this.game,
    this.players,
  });

  String get _roomNumber => roomNumber.isNotEmpty
      ? roomNumber
      : (roomNo ?? roomName ?? '');
  String get _gameName =>
      gameName.isNotEmpty ? gameName : (game ?? roomType);
  int get _playerCount => players ?? playerCount;

  static const _statusLabels = {
    'waiting': '等待中',
    'playing': '进行中',
    'full': '已满',
    'closed': '已关闭',
    '空闲': '等待中',
    '等待中': '等待中',
    '游戏中': '进行中',
    '进行中': '进行中',
    '已满': '已满',
    '维护中': '已关闭',
    '关闭': '已关闭',
    '已关闭': '已关闭',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'waiting':
      case '空闲':
      case '等待中':
        return colors.success;
      case 'playing':
      case '游戏中':
      case '进行中':
        return colors.primary;
      case 'full':
      case '已满':
        return colors.warning;
      case 'closed':
      case '维护中':
      case '关闭':
      case '已关闭':
        return colors.muted;
      default:
        return colors.muted;
    }
  }

  bool get _canJoin {
    final s = status;
    final waiting = s == 'waiting' || s == '空闲' || s == '等待中';
    return waiting && _playerCount < maxPlayers;
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onView?.call(id);
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '$_roomNumber${isVip ? ' · VIP' : ''}',
                          style: AppTypography.h3,
                        ),
                        Text(_gameName, style: AppTypography.body),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(_statusLabel,
                        style: AppTypography.caption.copyWith(color: sc)),
                  ),
                ],
              ),
              if (hostName != null) ...[
                const SizedBox(height: 4),
                Text('房主: $hostName', style: AppTypography.caption),
              ],
              const SizedBox(height: 8),
              Text('玩家 $_playerCount / $maxPlayers', style: AppTypography.body),
              LinearProgressIndicator(
                value: maxPlayers > 0 ? _playerCount / maxPlayers : 0,
                backgroundColor: colors.border,
                color: colors.primary,
              ),
              if (onJoin != null && _canJoin) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: disabled ? null : () => onJoin!(id),
                    child: const Text('加入'),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
