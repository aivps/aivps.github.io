import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// CourseCard — field-deep aligned to React education CourseCard.
class CourseCard extends StatelessWidget {
  final String? image;
  final String title;
  final String? teacher;
  final String? price;
  final String? originalPrice;
  final String? duration;
  final int? studentCount;
  final double? rating;
  final List<String> tags;
  final String status; // enrolling | ongoing | ended
  final VoidCallback? onTap;
  final VoidCallback? onClick;
  final bool disabled;

  /// @deprecated campus aliases
  final String? name;
  final String? schedule;
  final int? enrolled;
  final String? classroom;

  const CourseCard({
    super.key,
    this.image,
    this.title = '',
    this.teacher,
    this.price,
    this.originalPrice,
    this.duration,
    this.studentCount,
    this.rating,
    this.tags = const [],
    this.status = 'enrolling',
    this.onTap,
    this.onClick,
    this.disabled = false,
    this.name,
    this.schedule,
    this.enrolled,
    this.classroom,
  });

  String get _title => title.isNotEmpty ? title : (name ?? '');
  String? get _duration => duration ?? schedule;
  int? get _students => studentCount ?? enrolled;

  static const _statusLabels = {
    'enrolling': '招生中',
    'ongoing': '进行中',
    'ended': '已结束',
    '进行中': '进行中',
    '未开始': '招生中',
    '已结束': '已结束',
  };

  String get _statusLabel => _statusLabels[status] ?? status;

  Color _statusColor(AppThemeColors colors) {
    switch (status) {
      case 'enrolling':
      case '未开始':
        return colors.success;
      case 'ongoing':
      case '进行中':
        return colors.primary;
      case 'ended':
      case '已结束':
        return colors.muted;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final sc = _statusColor(colors);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled
            ? null
            : () {
                onTap?.call();
                onClick?.call();
              },
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _title,
                          style: AppTypography.body
                              .copyWith(fontWeight: FontWeight.w600),
                        ),
                        if (teacher != null)
                          Text(teacher!, style: AppTypography.caption),
                      ],
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: sc.withValues(alpha: 0.1),
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Text(
                      _statusLabel,
                      style: AppTypography.caption.copyWith(color: sc),
                    ),
                  ),
                ],
              ),
              if (_duration != null || _students != null) ...[
                const SizedBox(height: 8),
                Text(
                  [
                    if (_duration != null) _duration,
                    if (_students != null) '$_students 人',
                    if (classroom != null) classroom,
                  ].whereType<String>().join(' · '),
                  style: AppTypography.caption,
                ),
              ],
              if (price != null) ...[
                const SizedBox(height: 8),
                Text(
                  price!,
                  style: AppTypography.h3.copyWith(color: colors.danger),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
