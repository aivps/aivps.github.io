package com.uilib.components.education

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 课程 - field-deep aligned shell (Compose) */
@Composable
fun CourseCard(
    title: String = "",
    teacher: String = "",
    price: String = "",
    duration: String = "",
    studentCount: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "课程",
        status = status.ifBlank { null },
        fields = listOf(
            "标题" to title,
            "讲师" to teacher,
            "价格" to price,
            "时长" to duration,
            "学员数" to studentCount,
        ),
        modifier = modifier,
    )
}