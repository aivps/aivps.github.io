import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';

/// ProductionLineCard - manufacturing line shell (UTF-8 safe).
class ProductionLineCard extends StatelessWidget {
  final String id;
  final String name;
  final String status;
  final double? oee;
  final int? output;
  final VoidCallback? onTap;
  final bool disabled;

  const ProductionLineCard({
    super.key,
    this.id = '',
    this.name = '',
    required this.status,
    this.oee,
    this.output,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: InkWell(
        onTap: disabled ? null : onTap,
        borderRadius: AppSpacing.borderRadiusLg,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            border: Border.all(color: colors.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      name.isNotEmpty ? name : id,
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: colors.foreground),
                    ),
                  ),
                  Text(status, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: colors.success)),
                ],
              ),
              if (oee != null || output != null) ...[
                const SizedBox(height: 8),
                Text(
                  [
                    if (oee != null) 'OEE ${(oee! * 100).toStringAsFixed(1)}%',
                    if (output != null) 'Output $output',
                  ].join(' · '),
                  style: TextStyle(fontSize: 13, color: colors.muted),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
