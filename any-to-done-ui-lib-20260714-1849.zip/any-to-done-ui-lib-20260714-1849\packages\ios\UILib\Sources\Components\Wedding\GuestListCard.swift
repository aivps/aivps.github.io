import SwiftUI

/// 宾客 - field-deep aligned shell (SwiftUI)
public struct GuestListCard: View {
    public var name: String = ""
    public var tableNumber: String = ""
    public var status: String = ""
    public var phone: String = ""
    public var relationship: String = ""

    public init(name: String = "", tableNumber: String = "", status: String = "", phone: String = "", relationship: String = "") {
        self.name = name
        self.tableNumber = tableNumber
        self.status = status
        self.phone = phone
        self.relationship = relationship
    }

    public var body: some View {
        IndustryCardShell(
            title: "宾客",
            status: status.isEmpty ? nil : status,
            fields: [
                ("名称", name),
                ("关系", relationship),
                ("桌号", tableNumber),
                ("电话", phone),
            ]
        )
    }
}
