/// Motion tokens — duration / press scale for Button / Card / List.
class AppMotion {
  AppMotion._();

  static const Duration instant = Duration.zero;
  static const Duration fast = Duration(milliseconds: 120);
  static const Duration normal = Duration(milliseconds: 200);
  static const Duration slow = Duration(milliseconds: 320);
  static const Duration stagger = Duration(milliseconds: 40);

  /// Pressed control scale
  static const double pressScale = 0.98;
}
