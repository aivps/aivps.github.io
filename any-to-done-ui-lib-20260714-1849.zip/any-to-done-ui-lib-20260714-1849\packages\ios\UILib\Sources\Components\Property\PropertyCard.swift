﻿import SwiftUI

/// 房源 - field-deep aligned shell (SwiftUI)
public struct PropertyCard: View {
    public var id: String = ""
    public var title: String = ""
    public var price: String = ""
    public var area: String = ""
    public var rooms: String = ""
    public var address: String = ""
    public var status: String = ""

    public init(id: String = "", title: String = "", price: String = "", area: String = "", rooms: String = "", address: String = "", status: String = "") {
        self.id = id
        self.title = title
        self.price = price
        self.area = area
        self.rooms = rooms
        self.address = address
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "房源",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("标题", title),
            ("价格", price),
            ("面积", area),
            ("户型", rooms),
            ("地址", address),
            ]
        )
    }
}
