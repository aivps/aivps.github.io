import React, { useState } from 'react';
import { spacing, typography, motion } from '../tokens';
import { useTheme } from '../theme/ThemeProvider';

export interface IndustryCardShellProps {
  title: string;
  status?: string;
  /** Structured field rows (preferred when not using children). */
  fields?: Array<{ label: string; value?: string | number | null }>;
  /** Free-form body content (generator shells pass row divs). */
  children?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
  onContextMenu?: (e: React.MouseEvent) => void;
  onClick?: (e: React.MouseEvent) => void;
}

export const IndustryCardShell: React.FC<IndustryCardShellProps> = ({
  title,
  status,
  fields,
  children,
  className,
  style,
  onContextMenu,
  onClick,
}) => {
  const { colors } = useTheme();
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  const fieldRows =
    fields
      ?.filter((f) => f.value !== undefined && f.value !== null && String(f.value) !== '')
      .map((f) => (
        <div key={f.label} style={{ display: 'flex', justifyContent: 'space-between', gap: 12 }}>
          <span style={{ fontSize: 12, color: colors.muted }}>{f.label}</span>
          <span
            style={{
              fontSize: 13,
              color: colors.gray700,
              textAlign: 'right',
              wordBreak: 'break-all',
            }}
          >
            {String(f.value)}
          </span>
        </div>
      )) ?? null;

  return (
    <article
      className={className}
      onContextMenu={onContextMenu}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => {
        setHovered(false);
        setPressed(false);
      }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        background: colors.surface,
        border: `1px solid ${hovered ? colors.primary : colors.border}`,
        borderRadius: spacing.radiusLg,
        padding: `${spacing.lg}px ${spacing.xl}px`,
        boxShadow: hovered ? colors.shadowMd : colors.shadowSm,
        fontFamily: 'system-ui, -apple-system, "Segoe UI", sans-serif',
        transition: motion.transitions.card,
        transform: pressed ? `scale(${motion.scale.press})` : 'scale(1)',
        cursor: onClick ? 'pointer' : undefined,
        ...style,
      }}
    >
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: spacing.md,
        }}
      >
        <h3
          style={{
            margin: 0,
            fontSize: typography.h3.fontSize,
            fontWeight: typography.h3.fontWeight,
            color: colors.foreground,
          }}
        >
          {title}
        </h3>
        {status ? (
          <span
            style={{
              fontSize: 12,
              fontWeight: 600,
              color: colors.primary,
              background: colors.primaryBg,
              padding: '2px 8px',
              borderRadius: spacing.radiusSm,
              transition: motion.transitions.control,
            }}
          >
            {status}
          </span>
        ) : null}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: spacing.sm }}>
        {fieldRows}
        {children}
      </div>
    </article>
  );
};
