/** 患者 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'gender': { type: String, value: '' },
    'age': { type: String, value: '' },
    'phone': { type: String, value: '' },
    'department': { type: String, value: '' },
    'visitType': { type: String, value: '' },
    'status': { type: String, value: '' },
    'queueNumber': { type: String, value: '' },
    'visitTime': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});
