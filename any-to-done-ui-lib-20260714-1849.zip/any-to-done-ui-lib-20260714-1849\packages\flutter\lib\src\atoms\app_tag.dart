import 'package:flutter/material.dart';
import '../tokens/colors.dart';
import '../tokens/spacing.dart';
/// 标签颜色
enum TagColor {
  defaultType,
  primary,
  success,
  warning,
  danger,
  info,
  purple,
}

/// 标签尺寸
enum TagSize {
  sm,
  md,
  lg,
}

/// 标签变体
enum TagVariant {
  solid,
  outlined,
  light,
}

/// AppTag 标签组件
class AppTag extends StatelessWidget {
  final TagColor color;
  final TagSize size;
  final TagVariant variant;
  final bool closable;
  final VoidCallback? onClose;
  final Widget? icon;
  final String label;

  const AppTag({
    super.key,
    this.color = TagColor.defaultType,
    this.size = TagSize.md,
    this.variant = TagVariant.light,
    this.closable = false,
    this.onClose,
    this.icon,
    required this.label,
  });

  @override
  Widget build(BuildContext context) {
    final colors = _getColors();

    return Container(
      height: _getHeight(),
      padding: EdgeInsets.symmetric(horizontal: _getHorizontalPadding()),
      decoration: BoxDecoration(
        color: variant == TagVariant.outlined ? Colors.transparent : colors.bg,
        border: Border.all(color: colors.border),
        borderRadius: BorderRadius.circular(AppRadius.sm),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            icon!,
            const SizedBox(width: AppSpacing.xs),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: _getFontSize(),
              fontWeight: FontWeight.w500,
              color: colors.text,
            ),
          ),
          if (closable) ...[
            const SizedBox(width: AppSpacing.xs),
            GestureDetector(
              onTap: onClose,
              child: Icon(
                Icons.close,
                size: 12,
                color: colors.text,
              ),
            ),
          ],
        ],
      ),
    );
  }

  _TagColors _getColors() {
    final colorMap = {
      TagColor.defaultType: _TagColors(AppColors.gray100, AppColors.gray700, AppColors.gray300),
      TagColor.primary: _TagColors(AppColors.blue50, AppColors.blue700, AppColors.blue300),
      TagColor.success: _TagColors(AppColors.green50, AppColors.green700, AppColors.green300),
      TagColor.warning: _TagColors(AppColors.orange50, AppColors.orange700, AppColors.orange300),
      TagColor.danger: _TagColors(AppColors.red50, AppColors.red700, AppColors.red300),
      TagColor.info: _TagColors(AppColors.cyan50, AppColors.cyan700, AppColors.cyan300),
      TagColor.purple: _TagColors(AppColors.purple50, AppColors.purple700, AppColors.purple300),
    };

    final solidColorMap = {
      TagColor.defaultType: _TagColors(AppColors.gray600, AppColors.gray0, Colors.transparent),
      TagColor.primary: _TagColors(AppColors.primary, AppColors.gray0, Colors.transparent),
      TagColor.success: _TagColors(AppColors.success, AppColors.gray0, Colors.transparent),
      TagColor.warning: _TagColors(AppColors.orange, AppColors.gray0, Colors.transparent),
      TagColor.danger: _TagColors(AppColors.danger, AppColors.gray0, Colors.transparent),
      TagColor.info: _TagColors(AppColors.cyan, AppColors.gray0, Colors.transparent),
      TagColor.purple: _TagColors(AppColors.purple, AppColors.gray0, Colors.transparent),
    };

    return variant == TagVariant.solid
        ? solidColorMap[color]!
        : colorMap[color]!;
  }

  double _getHeight() {
    switch (size) {
      case TagSize.sm:
        return 20;
      case TagSize.md:
        return 24;
      case TagSize.lg:
        return 32;
    }
  }

  double _getHorizontalPadding() {
    switch (size) {
      case TagSize.sm:
        return AppSpacing.xs;
      case TagSize.md:
        return AppSpacing.sm;
      case TagSize.lg:
        return AppSpacing.mdValue;
    }
  }

  double _getFontSize() {
    switch (size) {
      case TagSize.sm:
        return 12;
      case TagSize.md:
        return 14;
      case TagSize.lg:
        return 16;
    }
  }
}

class _TagColors {
  final Color bg;
  final Color text;
  final Color border;

  _TagColors(this.bg, this.text, this.border);
}
