package com.uilib.components.fitness

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 健身课 - field-deep aligned shell (Compose) */
@Composable
fun FitnessCourseCard(
    name: String = "",
    coach: String = "",
    time: String = "",
    duration: String = "",
    capacity: String = "",
    enrolled: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "健身课",
        status = status.ifBlank { null },
        fields = listOf(
            "名称" to name,
            "教练" to coach,
            "时间" to time,
            "时长" to duration,
            "容量" to capacity,
            "已报" to enrolled,
        ),
        modifier = modifier,
    )
}
