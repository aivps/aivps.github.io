import React from 'react';
import { IndustryCardShell } from '../../atoms/IndustryCardShell';

export interface PortraitListProps {
  title?: string;
  count?: string;
  segment?: string;
  status?: string;
  onClick?: () => void;
}

/** PortraitList - Electron shell (field keys aligned to React) */
export const PortraitList: React.FC<PortraitListProps> = (props) => (
  <IndustryCardShell title="PortraitList" status={props.status} onClick={props.onClick}>
      {props.title ? <div className="row"><span className="label">title</span><span>{props.title}</span></div> : null}
      {props.count ? <div className="row"><span className="label">count</span><span>{props.count}</span></div> : null}
      {props.segment ? <div className="row"><span className="label">segment</span><span>{props.segment}</span></div> : null}
      {props.status ? <div className="row"><span className="label">status</span><span>{props.status}</span></div> : null}
  </IndustryCardShell>
);

export default PortraitList;