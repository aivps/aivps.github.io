/** 案件 - Douyin Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'caseNumber': { type: String, value: '' },
    'caseType': { type: String, value: '' },
    'title': { type: String, value: '' },
    'client': { type: String, value: '' },
    'lawyer': { type: String, value: '' },
    'filingDate': { type: String, value: '' },
    'courtDate': { type: String, value: '' },
    'status': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});