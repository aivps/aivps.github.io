import SwiftUI

/// 课表 - education industry (SwiftUI)
public struct ClassSchedule: View {
    public var className: String = ""
    public var weekday: String = ""
    public var period: String = ""
    public var room: String = ""
    public var subject: String = ""

    public init(className: String = "", weekday: String = "", period: String = "", room: String = "", subject: String = "") {
        self.className = className
        self.weekday = weekday
        self.period = period
        self.room = room
        self.subject = subject
    }

    public var body: some View {
        IndustryCardShell(
            title: "课表",
            status: nil,
            fields: [
            ("班级", className),
            ("星期", weekday),
            ("节次", period),
            ("教室", room),
            ("科目", subject),
            ]
        )
    }
}