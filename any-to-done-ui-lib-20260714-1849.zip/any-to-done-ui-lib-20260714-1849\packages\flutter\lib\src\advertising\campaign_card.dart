import 'package:flutter/material.dart';

/// CampaignCard - field-deep aligned to React src/advertising
class CampaignCard extends StatelessWidget {
  final String? id;
  final String? name;
  final String? platform;
  final String? budget;
  final String? spent;
  final String? impressions;
  final String? clicks;
  final String? status;
  final VoidCallback? onTap;
  final bool disabled;

  const CampaignCard({
    super.key,
    this.id,
    this.name,
    this.platform,
    this.budget,
    this.spent,
    this.impressions,
    this.clicks,
    this.status,
    this.onTap,
    this.disabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final surface = isDark ? const Color(0xFF1F1F1F) : Colors.white;
    final border = isDark ? const Color(0xFF303030) : const Color(0xFFE8E8E8);
    final muted = const Color(0xFF8C8C8C);
    final fg = isDark ? const Color(0xFFE8E8E8) : const Color(0xFF262626);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Material(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: disabled ? null : onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('CampaignCard', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: fg)),
                const SizedBox(height: 12),
                if (id != null && id!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('id', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(id!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (name != null && name!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('name', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(name!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (platform != null && platform!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('platform', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(platform!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (budget != null && budget!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('budget', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(budget!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (spent != null && spent!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('spent', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(spent!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (impressions != null && impressions!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('impressions', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(impressions!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (clicks != null && clicks!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('clicks', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(clicks!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
                if (status != null && status!.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 6),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('status', style: TextStyle(fontSize: 12, color: muted)),
                        Flexible(child: Text(status!, style: TextStyle(fontSize: 14, color: fg), textAlign: TextAlign.right)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}