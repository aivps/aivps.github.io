# AGENTS.md — 本仓库 AI 协作约定

## 语言

- 与用户对话：中文  
- 代码注释 / Commit message：英文  

## 改代码前

1. 先读 `docs/LLM.md`（最短路由，省 Token）。  
2. 字段/枚举以 `docs/api-contract-industry-cards.md` 为准。  
3. 实现权威源是根目录 `src/`（React Web），不是 `packages/react` 副本。  

## 禁止

- 在 `src/` 引入 `react-native` 或其它非 Web 依赖。  
- 用中文当 prop / attribute 名。  
- 无目标全仓扫描大文件（尤其 `component-library-plan.md` 全文）。  

## 演示

- 行业卡：`demo.html`  
- 原子组件：`preview.html`  

## 包管理

- 优先 `pnpm`（若环境无 lock 则以现有 `package.json` 为准）。  
