import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

class ClassScheduleItem {
  final String id;
  final String subject;
  final String teacher;
  final String room;
  final int? dayOfWeek;
  final int? startPeriod;
  final int? endPeriod;
  final String startTime;
  final String endTime;
  final String? type;
  final String? weekday;

  const ClassScheduleItem({
    required this.id,
    required this.subject,
    required this.teacher,
    required this.room,
    this.dayOfWeek,
    this.startPeriod,
    this.endPeriod,
    required this.startTime,
    required this.endTime,
    this.type,
    this.weekday,
  });
}

/// ClassSchedule — field-deep aligned to React ClassSchedule.
class ClassSchedule extends StatelessWidget {
  final String? className;
  final String? gradeLevel;
  final String? semester;
  final List<ClassScheduleItem> schedule;
  final ValueChanged<ClassScheduleItem>? onClassClick;
  final bool disabled;

  /// @deprecated
  final String? term;

  const ClassSchedule({
    super.key,
    this.className,
    this.gradeLevel,
    this.semester,
    this.schedule = const [],
    this.onClassClick,
    this.disabled = false,
    this.term,
  });

  String get _semester => semester ?? term ?? '';

  static const _days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];

  String _dayLabel(ClassScheduleItem item) {
    if (item.weekday != null) return item.weekday!;
    if (item.dayOfWeek != null &&
        item.dayOfWeek! >= 1 &&
        item.dayOfWeek! <= 7) {
      return _days[item.dayOfWeek! - 1];
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Container(
        padding: AppSpacing.lg,
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: AppSpacing.borderRadiusLg,
          boxShadow: AppShadows.sm,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              className?.isNotEmpty == true ? className! : '课程表',
              style: AppTypography.h3,
            ),
            if (gradeLevel != null || _semester.isNotEmpty)
              Text(
                [gradeLevel, _semester].whereType<String>().join(' · '),
                style: AppTypography.caption,
              ),
            const SizedBox(height: 8),
            ...schedule.map(
              (slot) => GestureDetector(
                onTap: disabled ? null : () => onClassClick?.call(slot),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(color: colors.border, width: 0.5),
                    ),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              slot.subject,
                              style: AppTypography.body
                                  .copyWith(fontWeight: FontWeight.w600),
                            ),
                            Text(
                              '${slot.teacher} · ${slot.room}',
                              style: AppTypography.caption,
                            ),
                          ],
                        ),
                      ),
                      Text(
                        '${_dayLabel(slot)} ${slot.startTime}-${slot.endTime}',
                        style: AppTypography.caption,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
