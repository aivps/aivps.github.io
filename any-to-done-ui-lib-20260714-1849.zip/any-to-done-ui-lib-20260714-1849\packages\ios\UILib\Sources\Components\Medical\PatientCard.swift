﻿import SwiftUI

/// 患者 - industry (SwiftUI, field-deep aligned)
public struct PatientCard: View {
    public var id: String = ""
    public var name: String = ""
    public var gender: String = ""
    public var age: String = ""
    public var phone: String = ""
    public var department: String = ""
    public var visitType: String = ""
    public var status: String = ""
    public var queueNumber: String = ""
    public var visitTime: String = ""

    public init(id: String = "", name: String = "", gender: String = "", age: String = "", phone: String = "", department: String = "", visitType: String = "", status: String = "", queueNumber: String = "", visitTime: String = "") {
        self.id = id
        self.name = name
        self.gender = gender
        self.age = age
        self.phone = phone
        self.department = department
        self.visitType = visitType
        self.status = status
        self.queueNumber = queueNumber
        self.visitTime = visitTime
    }

    public var body: some View {
        IndustryCardShell(
            title: "患者",
            status: status.isEmpty ? nil : status,
            fields: [
            ("ID", id),
            ("姓名", name),
            ("性别", gender),
            ("年龄", age),
            ("电话", phone),
            ("科室", department),
            ("挂号类型", visitType),
            ("排队号", queueNumber),
            ("就诊时间", visitTime),
            ]
        )
    }
}
