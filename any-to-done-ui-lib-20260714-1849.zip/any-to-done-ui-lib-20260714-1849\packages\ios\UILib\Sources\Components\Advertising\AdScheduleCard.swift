import SwiftUI

/// 投放排期 - advertising industry (SwiftUI)
public struct AdScheduleCard: View {
    public var campaign: String = ""
    public var slot: String = ""
    public var channel: String = ""
    public var date: String = ""
    public var status: String = ""

    public init(campaign: String = "", slot: String = "", channel: String = "", date: String = "", status: String = "") {
        self.campaign = campaign
        self.slot = slot
        self.channel = channel
        self.date = date
        self.status = status
    }

    public var body: some View {
        IndustryCardShell(
            title: "投放排期",
            status: status.isEmpty ? nil : status,
            fields: [
            ("活动", campaign),
            ("时段", slot),
            ("渠道", channel),
            ("日期", date),
            ]
        )
    }
}