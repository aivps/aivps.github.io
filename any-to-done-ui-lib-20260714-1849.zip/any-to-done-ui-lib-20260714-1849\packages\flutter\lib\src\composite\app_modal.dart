import 'package:flutter/material.dart';
class AppModal extends StatelessWidget {
  final String? title;
  final Widget child;
  final Widget? footer;
  final bool visible;
  final VoidCallback? onClose;
  final double? width;

  const AppModal({
    super.key,
    this.title,
    required this.child,
    this.footer,
    this.visible = false,
    this.onClose,
    this.width,
  });

  static Future<T?> show<T>(
    BuildContext context, {
    String? title,
    required Widget child,
    Widget? footer,
    double? width,
  }) {
    return showGeneralDialog<T>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Modal',
      transitionDuration: const Duration(milliseconds: 200),
      pageBuilder: (ctx, anim, secondary) {
        return AppModal(
          title: title,
          footer: footer,
          width: width,
          onClose: () => Navigator.of(ctx).pop(),
          child: child,
        );
      },
      transitionBuilder: (ctx, anim, secondary, widget) {
        return ScaleTransition(
          scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
          child: FadeTransition(opacity: anim, child: widget),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: width ?? 400,
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.8,
          ),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.12), blurRadius: 40)],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (title != null)
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 16, 16, 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          title!,
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                      ),
                      GestureDetector(
                        onTap: onClose,
                        child: Icon(Icons.close, color: Colors.grey[500], size: 20),
                      ),
                    ],
                  ),
                ),
              if (title != null) const Divider(height: 1),
              Flexible(child: Padding(padding: const EdgeInsets.all(24), child: child)),
              if (footer != null) ...[
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 12, 24, 12),
                  child: footer!,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
