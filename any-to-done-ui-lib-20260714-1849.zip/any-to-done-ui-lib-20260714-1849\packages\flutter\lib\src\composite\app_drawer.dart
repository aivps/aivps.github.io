import 'package:flutter/material.dart';
class AppDrawer extends StatelessWidget {
  final String? title;
  final Widget child;
  final Widget? footer;
  final double width;
  final DrawerPlacement placement;

  const AppDrawer({
    super.key,
    this.title,
    required this.child,
    this.footer,
    this.width = 400,
    this.placement = DrawerPlacement.right,
  });

  static void show(
    BuildContext context, {
    String? title,
    required Widget child,
    Widget? footer,
    double width = 400,
    DrawerPlacement placement = DrawerPlacement.right,
  }) {
    showGeneralDialog(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Drawer',
      transitionDuration: const Duration(milliseconds: 250),
      pageBuilder: (ctx, anim, secondary) {
        return AppDrawer(
          title: title,
          footer: footer,
          width: width,
          placement: placement,
          child: child,
        );
      },
      transitionBuilder: (ctx, anim, secondary, widget) {
        final offset = placement == DrawerPlacement.right ? 1.0 : -1.0;
        return SlideTransition(
          position: Tween<Offset>(begin: Offset(offset, 0), end: Offset.zero)
              .animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
          child: widget,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: placement == DrawerPlacement.right
          ? Alignment.centerRight
          : Alignment.centerLeft,
      child: Material(
        color: Colors.transparent,
        child: Container(
          width: width,
          height: double.infinity,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.1), blurRadius: 8)],
          ),
          child: Column(
            children: [
              if (title != null)
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 16, 16, 12),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(title!,
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.of(context).pop(),
                        child: Icon(Icons.close, color: Colors.grey[500], size: 20),
                      ),
                    ],
                  ),
                ),
              if (title != null) const Divider(height: 1),
              Expanded(child: Padding(padding: const EdgeInsets.all(24), child: child)),
              if (footer != null) ...[
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 12, 24, 12),
                  child: footer!,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

enum DrawerPlacement { left, right }
