/// Button - 按钮组件
/// 支持主按钮/次要按钮/文字按钮/危险按钮

import 'package:flutter/material.dart';

enum ButtonVariant { primary, secondary, text, danger, ghost }
enum ButtonSize { xs, sm, md, lg }

class UIButton extends StatelessWidget {
  final ButtonVariant variant;
  final ButtonSize size;
  final bool isLoading;
  final bool isDisabled;
  final Widget? child;
  final VoidCallback? onPressed;
  final IconData? icon;

  const UIButton({
    Key? key,
    this.variant = ButtonVariant.primary,
    this.size = ButtonSize.md,
    this.isLoading = false,
    this.isDisabled = false,
    this.child,
    this.onPressed,
    this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return SizedBox(
      height: _getHeight(),
      child: ElevatedButton(
        onPressed: isDisabled || isLoading ? null : onPressed,
        style: _getStyle(theme, isDark),
        child: _buildChild(theme),
      ),
    );
  }

  double _getHeight() {
    switch (size) {
      case ButtonSize.xs:
        return 24;
      case ButtonSize.sm:
        return 32;
      case ButtonSize.md:
        return 40;
      case ButtonSize.lg:
        return 48;
    }
  }

  ButtonStyle _getStyle(ThemeData theme, bool isDark) {
    Color backgroundColor;
    Color foregroundColor;
    BorderSide? border;

    switch (variant) {
      case ButtonVariant.primary:
        backgroundColor = theme.colorScheme.primary;
        foregroundColor = Colors.white;
        border = null;
        break;
      case ButtonVariant.secondary:
        backgroundColor = isDark ? const Color(0xFF1F1F1F) : Colors.white;
        foregroundColor = isDark ? Colors.white : const Color(0xFF1F2937);
        border = BorderSide(
          color: isDark ? const Color(0xFF303030) : const Color(0xFFEBEDF0),
        );
        break;
      case ButtonVariant.text:
        backgroundColor = Colors.transparent;
        foregroundColor = theme.colorScheme.primary;
        border = null;
        break;
      case ButtonVariant.danger:
        backgroundColor = const Color(0xFFF53F3F);
        foregroundColor = Colors.white;
        border = null;
        break;
      case ButtonVariant.ghost:
        backgroundColor = Colors.transparent;
        foregroundColor = isDark ? Colors.white : const Color(0xFF1F2937);
        border = null;
        break;
    }

    return ElevatedButton.styleFrom(
      backgroundColor: backgroundColor,
      foregroundColor: foregroundColor,
      elevation: 0,
      padding: EdgeInsets.symmetric(horizontal: _getHorizontalPadding()),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4),
        side: border ?? BorderSide.none,
      ),
    );
  }

  double _getHorizontalPadding() {
    switch (size) {
      case ButtonSize.xs:
        return 8;
      case ButtonSize.sm:
        return 12;
      case ButtonSize.md:
        return 16;
      case ButtonSize.lg:
        return 24;
    }
  }

  Widget _buildChild(ThemeData theme) {
    if (isLoading) {
      return SizedBox(
        width: 14,
        height: 14,
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation<Color>(
            variant == ButtonVariant.primary ? Colors.white : theme.colorScheme.primary,
          ),
        ),
      );
    }

    if (icon != null && child != null) {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16),
          const SizedBox(width: 8),
          child!,
        ],
      );
    }

    return child ?? const SizedBox.shrink();
  }
}
