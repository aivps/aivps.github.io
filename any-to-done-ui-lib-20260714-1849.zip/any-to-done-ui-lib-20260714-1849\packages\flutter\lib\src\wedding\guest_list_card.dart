import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

/// Guest — aligned to React Guest
class Guest {
  final String name;
  final String relationship;
  final dynamic tableNumber;
  final String status; // confirmed | pending | declined
  final bool plusOne;
  final String? phone;

  const Guest({
    required this.name,
    this.relationship = '',
    this.tableNumber,
    this.status = 'pending',
    this.plusOne = false,
    this.phone,
  });
}

/// GuestListCard — field-deep aligned to React GuestListCard (list mode).
/// Also supports single-guest shell mode via name/tableNumber/status props.
class GuestListCard extends StatelessWidget {
  final List<Guest> guests;
  final String title;
  final VoidCallback? onTap;
  final bool disabled;

  /// Single-guest shell mode (phase6)
  final String? name;
  final dynamic tableNumber;
  final String? status;
  final String? phone;
  final String? relationship;
  final String? rsvp;
  final String? tableNo;
  final int? partySize;
  final String? rsvpStatus;
  final String? side;

  const GuestListCard({
    super.key,
    this.guests = const [],
    this.title = '宾客名单',
    this.onTap,
    this.disabled = false,
    this.name,
    this.tableNumber,
    this.status,
    this.phone,
    this.relationship,
    this.rsvp,
    this.tableNo,
    this.partySize,
    this.rsvpStatus,
    this.side,
  });

  List<Guest> get _list {
    if (guests.isNotEmpty) return guests;
    if (name != null && name!.isNotEmpty) {
      final raw = status ?? rsvp ?? rsvpStatus ?? 'pending';
      return [
        Guest(
          name: name!,
          relationship: relationship ?? side ?? '',
          tableNumber: tableNumber ?? tableNo,
          status: _canonicalize(raw),
          phone: phone,
        ),
      ];
    }
    return const [];
  }

  static String _canonicalize(String raw) {
    const map = {
      'confirmed': 'confirmed',
      'pending': 'pending',
      'declined': 'declined',
      'accepted': 'confirmed',
      '已确认': 'confirmed',
      '待确认': 'pending',
      '待回复': 'pending',
      '已谢绝': 'declined',
      '已拒绝': 'declined',
      '已婉拒': 'declined',
    };
    return map[raw] ?? raw;
  }

  static const _statusLabels = {
    'confirmed': '已确认',
    'pending': '待确认',
    'declined': '已谢绝',
  };

  Color _statusColor(AppThemeColors colors, String status) {
    switch (_canonicalize(status)) {
      case 'confirmed':
        return colors.success;
      case 'pending':
        return colors.warning;
      default:
        return colors.muted;
    }
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final list = _list;
    final confirmed =
        list.where((g) => _canonicalize(g.status) == 'confirmed').length;
    final pending =
        list.where((g) => _canonicalize(g.status) == 'pending').length;
    final declined =
        list.where((g) => _canonicalize(g.status) == 'declined').length;

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: GestureDetector(
        onTap: disabled ? null : onTap,
        child: Container(
          padding: AppSpacing.lg,
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: AppSpacing.borderRadiusLg,
            boxShadow: AppShadows.sm,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(title, style: AppTypography.h3),
                  Text('共 ${list.length} 人', style: AppTypography.caption),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text('已确认 $confirmed',
                      style: AppTypography.caption
                          .copyWith(color: colors.success)),
                  const SizedBox(width: 12),
                  Text('待确认 $pending',
                      style: AppTypography.caption
                          .copyWith(color: colors.warning)),
                  const SizedBox(width: 12),
                  Text('已谢绝 $declined',
                      style: AppTypography.caption
                          .copyWith(color: colors.muted)),
                ],
              ),
              const SizedBox(height: 12),
              ...list.map((g) {
                final s = _canonicalize(g.status);
                final c = _statusColor(colors, s);
                final label = _statusLabels[s] ?? g.status;
                return Container(
                  margin: const EdgeInsets.only(bottom: 4),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: colors.bgPage,
                    borderRadius: AppSpacing.borderRadiusSm,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Text(g.name,
                                style: AppTypography.body
                                    .copyWith(fontWeight: FontWeight.w500)),
                            if (g.relationship.isNotEmpty) ...[
                              const SizedBox(width: 8),
                              Text(g.relationship,
                                  style: AppTypography.caption),
                            ],
                            if (g.plusOne) ...[
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4, vertical: 1),
                                decoration: BoxDecoration(
                                  color: colors.primary,
                                  borderRadius: BorderRadius.circular(3),
                                ),
                                child: Text('+1',
                                    style: AppTypography.caption.copyWith(
                                        color: colors.textInverse,
                                        fontSize: 10)),
                              ),
                            ],
                          ],
                        ),
                      ),
                      if (g.tableNumber != null)
                        Text('桌${g.tableNumber}',
                            style: AppTypography.caption),
                      const SizedBox(width: 8),
                      Text(label,
                          style: AppTypography.caption.copyWith(color: c)),
                    ],
                  ),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}
