import 'package:flutter/material.dart';
import '../tokens/theme_colors.dart';
import '../tokens/spacing.dart';
import '../tokens/typography.dart';

class EvidenceItem {
  final String name;
  final String type;
  final String uploadDate;
  final String? size;

  const EvidenceItem({
    required this.name,
    required this.type,
    required this.uploadDate,
    this.size,
  });
}

/// EvidenceCard — field-deep aligned to React EvidenceCard (caseId + items).
class EvidenceCard extends StatelessWidget {
  final String? caseId;
  final List<EvidenceItem> items;
  final VoidCallback? onUpload;
  final VoidCallback? onTap;
  final bool disabled;

  /// @deprecated single-item legacy
  final String? evidenceId;
  final String? name;
  final String? type;
  final String? date;
  final String? status;

  const EvidenceCard({
    super.key,
    this.caseId,
    this.items = const [],
    this.onUpload,
    this.onTap,
    this.disabled = false,
    this.evidenceId,
    this.name,
    this.type,
    this.date,
    this.status,
  });

  List<EvidenceItem> get _items {
    if (items.isNotEmpty) return items;
    if (name != null && type != null) {
      return [
        EvidenceItem(
          name: name!,
          type: type!,
          uploadDate: date ?? '',
        ),
      ];
    }
    return const [];
  }

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final list = _items;

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Container(
        padding: AppSpacing.lg,
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: AppSpacing.borderRadiusLg,
          boxShadow: AppShadows.sm,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  caseId != null ? '证据材料 ($caseId)' : '证据材料',
                  style: AppTypography.body
                      .copyWith(fontWeight: FontWeight.w600),
                ),
                if (onUpload != null)
                  TextButton(
                    onPressed: disabled ? null : onUpload,
                    child: const Text('+ 上传'),
                  ),
              ],
            ),
            if (list.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Center(
                  child: Text(
                    '暂无证据材料',
                    style: AppTypography.caption
                        .copyWith(color: colors.muted),
                  ),
                ),
              )
            else
              ...list.map(
                (item) => GestureDetector(
                  onTap: disabled ? null : onTap,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 6),
                    padding: AppSpacing.smInsets,
                    decoration: BoxDecoration(
                      color: colors.bgPage,
                      borderRadius: AppSpacing.borderRadiusSm,
                    ),
                    child: Row(
                      children: [
                        const Text('📄'),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            item.name,
                            style: AppTypography.body
                                .copyWith(fontWeight: FontWeight.w500),
                          ),
                        ),
                        Text(item.type, style: AppTypography.caption),
                        const SizedBox(width: 8),
                        Text(item.uploadDate, style: AppTypography.caption),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
