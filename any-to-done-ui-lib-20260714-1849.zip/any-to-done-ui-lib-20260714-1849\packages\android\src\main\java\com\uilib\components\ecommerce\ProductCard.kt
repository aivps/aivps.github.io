package com.uilib.components.ecommerce

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 商品 - industry (Compose, field-deep aligned) */
@Composable
fun ProductCard(
    id: String = "",
    name: String = "",
    price: String = "",
    originalPrice: String = "",
    sales: String = "",
    image: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "商品",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "名称" to name,
            "价格" to price,
            "原价" to originalPrice,
            "销量" to sales,
            "图片" to image,
        ),
        modifier = modifier,
    )
}
