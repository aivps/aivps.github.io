/** DeviceStatusCard - Alipay Mini Program (field-deep aligned) */
Component({
  options: { addGlobalClass: true },
  properties: {
    'id': { type: String, value: '' },
    'name': { type: String, value: '' },
    'type': { type: String, value: '' },
    'location': { type: String, value: '' },
    'status': { type: String, value: '' },
    'lastHeartbeat': { type: String, value: '' },
    'battery': { type: String, value: '' },
  },
  methods: {
    onTap() { this.triggerEvent('tap', { ...this.properties }); },
  },
});