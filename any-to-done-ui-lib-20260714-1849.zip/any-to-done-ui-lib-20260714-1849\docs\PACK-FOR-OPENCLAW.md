己# 打包给 OpenClaw — 排除清单与交付目录

> 用途：把本组件库打成可外发的 **完整源码 zip**（不含依赖安装产物），连同目标站/程序一并交给 OpenClaw 执行 `docs/OPENCLAW-UI-UNIFY-PROMPT.md`。  
> 一键脚本：仓库根执行 `pnpm pack:openclaw` 或  
> `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/pack-for-openclaw.ps1`

---

## 1. 推荐外发结构

```
any-to-done-ui-handoff/
├── OPENCLAW.md                          ← agent 先读
├── docs/
│   ├── OPENCLAW-UI-UNIFY-PROMPT.md      ← 主提示词（第 8 节复制即用）
│   ├── PACK-FOR-OPENCLAW.md             ← 本文件
│   └── LLM.md
├── ui-lib/                              ← 本仓库源码（已排除垃圾）
│   ├── src/
│   ├── packages/
│   ├── docs/
│   ├── scripts/                         ← 保留 smoke/visual/interact/qa
│   ├── visual-baselines/                ← 默认保留（视觉回归基线）
│   ├── demo.html
│   ├── preview.html
│   ├── package.json
│   ├── pnpm-lock.yaml
│   └── …
└── target-app/                          ← 你另附的目标站/程序（WordPress 等）
    └── （对方完整源码；同样建议去掉 node_modules/vendor 大缓存）
```

对 OpenClaw 一句话：

> 读 `OPENCLAW.md`，执行 `docs/OPENCLAW-UI-UNIFY-PROMPT.md` 第 8 节，做到 END 交付，不要提问。`ui-lib` 为组件库，`target-app` 为待换 UI 程序。

---

## 2. 排除清单（默认 **必排除**）

| 路径 / 模式 | 原因 |
|-------------|------|
| `node_modules/` | 体积巨大；对方 `pnpm install` 即可 |
| `**/node_modules/` | 子包残留依赖 |
| `dist/` · `build/` · `out/` · `.next/` · `.nuxt/` · `coverage/` | 构建产物，可重生 |
| `.git/` | 历史与子模块状态；外发源码通常不需要 |
| `.opencode/` | 本地 skills/子模块脏状态，与业务无关 |
| `.open-design/` · `.mimocode/` | 本机设计器状态 |
| `${APPDATA}/` 或误检入的本机路径目录 | 环境噪音，禁止进 zip |
| `.env` · `.env.*` · `*.pem` · `*.key` | 密钥与私密配置 |
| `scripts/visual-out/` | 视觉回归 actual 输出（基线在 `visual-baselines/`） |
| `.visual-harness-*.html` · `.interact-harness-*.html` | 临时 harness |
| `*.artifact.json` | Open Design 宿主元数据 |
| `git-out.txt` · `git-err.txt` · `*.log` | 本地日志 |
| `.DS_Store` · `Thumbs.db` · `desktop.ini` | OS 垃圾 |
| `.vscode/` · `.idea/` · `*.swp` | IDE 个人配置（可选保留团队统一配置时再改策略） |
| `**/__pycache__/` · `*.pyc` · `.venv/` · `venv/` | Python 缓存（若目标站混用） |
| `vendor/`（Composer，可选） | PHP 依赖；对方 `composer install`（见 §4 开关） |

---

## 3. 建议 **保留**（完整源码交付）

| 路径 | 原因 |
|------|------|
| `src/` | Web React 权威实现 |
| `packages/` | Vue / RN / Flutter / 小程序 / 原生等跨端 |
| `docs/`（含 OPENCLAW 提示词、LLM、API 契约） | agent 路由与契约 |
| `demo.html` · `preview.html` | 视觉基准 |
| `scripts/*.ps1` · `scripts/*-targets.json` · `scripts/labels.zh.json` | 本机 QA |
| `visual-baselines/**/*.png` | `pnpm visual` 基线（体积约数十 MB，值得保留） |
| `package.json` · `pnpm-lock.yaml` · `tsconfig.json` · 各类 `*config*` | 可复现安装与构建 |
| `OPENCLAW.md` · `AGENTS.md` · `README.md` · `DEVELOPMENT-HANDOFF.md` | 上手与协作约定 |
| `component-index.md` | 组件索引（agent 可查） |

**可砍体积（可选排除）** — 脚本用 `-Slim`：

| 路径 | 何时可砍 |
|------|----------|
| `visual-baselines/` | 不要求对方跑 `pnpm visual` 时 |
| `component-library-plan.md` | 超长规划文；agent 应以 `docs/LLM.md` 为准 |
| `packages/android` · `packages/ios` · `packages/flutter` · `packages/react-native` · `packages/miniapp` | 目标仅为 WordPress/Web 时（**完整融合跨端则勿砍**） |

完整源码默认 **不** 使用 `-Slim`。

---

## 4. 目标程序（target-app）打包建议

与 UI 库同样原则，**只换表现层所需源码**：

| 栈 | 必带 | 建议排除 |
|----|------|----------|
| WordPress | `wp-content/themes/*`、自研插件、`wp-config-sample.php` 说明 | `wp-content/uploads` 大媒体（可抽样）、`wp-content/cache`、`node_modules`、完整 `wp-includes` 若对方已有 WP 环境可只交主题/插件 |
| React/Vue/Node | 源码 + lockfile + `.env.example` | `node_modules`、`dist`、`.next` |
| 静态站 | 全部 HTML/CSS/JS/资源 | 备份 zip、`.git` |
| 小程序 | 源码与 `project.config` | 本地私有 key、上传缓存 |

密钥：只给 `.env.example`，真实 `.env` **禁止**进 zip。

---

## 5. 体积与验收

打包脚本结束后会打印：

- zip 路径与大小  
- 已排除条目计数  
- 抽检：zip 内是否含 `OPENCLAW.md`、`docs/OPENCLAW-UI-UNIFY-PROMPT.md`、`src/tokens`、`demo.html`  
- 抽检：zip 内是否 **不含** `node_modules`、`.git`、`.opencode`

人工再确认 30 秒：

1. 解压后根目录或 `ui-lib/` 能看到 `OPENCLAW.md`  
2. 无 `node_modules`  
3. `pnpm install` + 打开 `demo.html` 可建立视觉基准（由接收方执行）

---

## 6. 命令速查

```powershell
# 默认：完整源码（含 visual-baselines，排除 node_modules/.git/.opencode 等）
pnpm pack:openclaw

# 或
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/pack-for-openclaw.ps1

# 精简：去掉 visual-baselines 与超长 plan 文档
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/pack-for-openclaw.ps1 -Slim

# 指定输出目录 / 文件名
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/pack-for-openclaw.ps1 `
  -OutDir "D:\dist" `
  -Name "any-to-done-ui-lib"

# 打包后仅列出将排除的路径（不写 zip）— DryRun
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/pack-for-openclaw.ps1 -DryRun
```

产物默认：`dist-handoff/any-to-done-ui-lib-YYYYMMDD-HHmm.zip`

---

## 7. 与 OpenClaw 提示词的关系

| 文件 | 角色 |
|------|------|
| `OPENCLAW.md` | 三行入口 |
| `docs/OPENCLAW-UI-UNIFY-PROMPT.md` | 无人值守主任务（START→END） |
| **本文件 + `scripts/pack-for-openclaw.ps1`** | 你怎么把库干净地塞进 zip |

打包 **不替代** 提示词；只保证 agent 拿到的是可安装、无密钥、无本机垃圾的源码树。
