package com.uilib.components.advanced

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 分栏 - advanced industry (Compose) */
@Composable
fun SplitPane(
    orientation: String = "",
    primarySize: String = "",
    minSize: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "分栏",
        status = null,
        fields = listOf(
            "方向" to orientation,
            "主区尺寸" to primarySize,
            "最小尺寸" to minSize,
        ),
        modifier = modifier,
    )
}