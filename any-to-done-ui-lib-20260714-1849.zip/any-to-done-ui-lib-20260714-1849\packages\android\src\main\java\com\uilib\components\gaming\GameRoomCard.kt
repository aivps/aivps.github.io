package com.uilib.components.gaming

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 游戏房 - field-deep aligned shell (Compose) */
@Composable
fun GameRoomCard(
    id: String = "",
    roomNumber: String = "",
    gameName: String = "",
    playerCount: String = "",
    maxPlayers: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "游戏房",
        status = status.ifBlank { null },
        fields = listOf(
            "ID" to id,
            "房间号" to roomNumber,
            "游戏" to gameName,
            "玩家数" to playerCount,
            "人数上限" to maxPlayers,
        ),
        modifier = modifier,
    )
}
