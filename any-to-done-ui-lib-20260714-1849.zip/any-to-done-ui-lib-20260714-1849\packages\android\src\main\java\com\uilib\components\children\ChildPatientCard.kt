package com.uilib.components.children

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 患儿 - children industry (Compose) */
@Composable
fun ChildPatientCard(
    name: String = "",
    age: String = "",
    department: String = "",
    guardian: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "患儿",
        status = status.ifBlank { null },
        fields = listOf(
            "名称" to name,
            "年龄" to age,
            "科室" to department,
            "监护人" to guardian,
        ),
        modifier = modifier,
    )
}