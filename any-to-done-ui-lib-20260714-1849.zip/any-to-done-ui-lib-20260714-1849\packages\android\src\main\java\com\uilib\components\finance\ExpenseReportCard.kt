package com.uilib.components.finance

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.uilib.atoms.IndustryCardShell

/** 报销单 - field-deep aligned shell (Compose) */
@Composable
fun ExpenseReportCard(
    reportId: String = "",
    reportName: String = "",
    applicant: String = "",
    department: String = "",
    submitDate: String = "",
    totalAmount: String = "",
    status: String = "",
    modifier: Modifier = Modifier,
) {
    IndustryCardShell(
        title = "报销单",
        status = status.ifBlank { null },
        fields = listOf(
            "单号" to reportId,
            "名称" to reportName,
            "申请人" to applicant,
            "部门" to department,
            "提交日期" to submitDate,
            "金额" to totalAmount,
        ),
        modifier = modifier,
    )
}