Component({
  properties: {
    src: { type: String, value: '' },
    size: { type: String, value: 'md' },
    shape: { type: String, value: 'circle' },
    name: { type: String, value: '' },
  },
  data: {
    avatarText: '',
  },
  lifetimes: {
    attached() {
      if (!this.data.src && this.data.name) {
        this.setData({ avatarText: this.data.name.charAt(0) });
      }
    },
  },
  methods: {},
});
