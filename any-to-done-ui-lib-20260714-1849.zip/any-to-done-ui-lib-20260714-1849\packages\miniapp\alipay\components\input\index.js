/**
 * Input — shallow API aligned to React atoms.
 * Canonical: variant outlined|filled|borderless; status; errorMessage; loading.
 */
Component({
  options: {
    addGlobalClass: true,
    multipleSlots: true,
  },

  properties: {
    type: {
      type: String,
      value: 'text',
    },
    variant: {
      type: String,
      value: 'outlined', // outlined, filled, borderless
    },
    size: {
      type: String,
      value: 'md',
    },
    label: {
      type: String,
      value: '',
    },
    placeholder: {
      type: String,
      value: '',
    },
    helperText: {
      type: String,
      value: '',
    },
    errorMessage: {
      type: String,
      value: '',
    },
    status: {
      type: String,
      value: 'default', // default, error, success, warning
    },
    clearable: {
      type: Boolean,
      value: false,
    },
    disabled: {
      type: Boolean,
      value: false,
    },
    /** React-aligned */
    readOnly: {
      type: Boolean,
      value: false,
    },
    /** @deprecated use readOnly */
    readonly: {
      type: Boolean,
      value: false,
    },
    loading: {
      type: Boolean,
      value: false,
    },
    value: {
      type: String,
      value: '',
    },
    maxlength: {
      type: Number,
      value: -1,
    },
    prefix: {
      type: Boolean,
      value: false,
    },
    suffix: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    focused: false,
    effectiveStatus: 'default',
    displayMessage: '',
    isReadOnly: false,
  },

  observers: {
    'status, errorMessage, helperText, readOnly, readonly': function (
      status,
      errorMessage,
      helperText,
      readOnly,
      readonly
    ) {
      const effectiveStatus = errorMessage ? 'error' : status || 'default';
      this.setData({
        effectiveStatus,
        displayMessage: errorMessage || helperText || '',
        isReadOnly: readOnly || readonly,
      });
    },
  },

  lifetimes: {
    attached() {
      const { status, errorMessage, helperText, readOnly, readonly } = this.properties;
      const effectiveStatus = errorMessage ? 'error' : status || 'default';
      this.setData({
        effectiveStatus,
        displayMessage: errorMessage || helperText || '',
        isReadOnly: readOnly || readonly,
      });
    },
  },

  methods: {
    onInput(e) {
      this.setData({ value: e.detail.value });
      this.triggerEvent('change', { value: e.detail.value });
    },

    onFocus() {
      this.setData({ focused: true });
      this.triggerEvent('focus');
    },

    onBlur() {
      this.setData({ focused: false });
      this.triggerEvent('blur');
    },

    onClear() {
      this.setData({ value: '' });
      this.triggerEvent('change', { value: '' });
      this.triggerEvent('clear');
    },
  },
});
