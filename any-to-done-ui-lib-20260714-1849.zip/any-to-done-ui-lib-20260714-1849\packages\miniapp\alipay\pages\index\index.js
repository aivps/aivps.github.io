Page({
  data: {
    lastEvent: '',
  },
  onCardTap(e) {
    const detail = (e && e.detail) || {};
    this.setData({ lastEvent: JSON.stringify(detail).slice(0, 180) });
  },
});
